hi! 

I'm moreReese, a jiraffe on the internet. 

This is my (d)Garden, the joint.

