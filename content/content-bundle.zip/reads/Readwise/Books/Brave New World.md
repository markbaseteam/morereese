# Brave New World

![rw-book-cover](https://images-na.ssl-images-amazon.com/images/I/51Cj3fsiwdL._SL200_.jpg)

## Metadata
- Author: [[Aldous Huxley]]
- Full Title: Brave New World
- Category: #books

## Highlights
- “And that,” put in the Director sententiously, “that is the secret of happiness and virtue—liking what you’ve got to do. All conditioning aims at that: making people like their unescapable social destiny.” ([Location 201](https://readwise.io/to_kindle?action=open&asin=B00JTYQJ3K&location=201))
- In brief, hypnopædia. “The greatest moralizing and socializing force of all time.” ([Location 348](https://readwise.io/to_kindle?action=open&asin=B00JTYQJ3K&location=348))
- “All the advantages of Christianity and alcohol; none of their defects.” ([Location 648](https://readwise.io/to_kindle?action=open&asin=B00JTYQJ3K&location=648))
- I’m thinking of a queer feeling I sometimes get, a feeling that I’ve got something important to say and the power to say it—only I don’t know what it is, and I can’t make any use of the power. ([Location 823](https://readwise.io/to_kindle?action=open&asin=B00JTYQJ3K&location=823))
- “Yes, that’s just it.” The young man nodded. “If one’s different, one’s bound to be lonely. ([Location 1650](https://readwise.io/to_kindle?action=open&asin=B00JTYQJ3K&location=1650))
- A pity, he thought, as he signed his name. It was a masterly piece of work. But once you began admitting explanations in terms of purpose—well, you didn’t know what the result might be. It was the sort of idea that might easily decondition the more unsettled minds among the higher castes—make them lose their faith in happiness as the Sovereign Good and take to believing, instead, that the goal was somewhere beyond, somewhere outside the present human sphere; that the purpose of life was not the maintenance of well-being, but some intensification and refining of consciousness, some enlargement of knowledge. ([Location 2128](https://readwise.io/to_kindle?action=open&asin=B00JTYQJ3K&location=2128))
- One of the principal functions of a friend is to suffer (in a milder and symbolic form) the punishments that we should like, but are unable, to inflict upon our enemies. ([Location 2157](https://readwise.io/to_kindle?action=open&asin=B00JTYQJ3K&location=2157))
    - Tags: [[broadcast2hightlights]] 
- world. You can’t make flivvers without steel—and you can’t make tragedies without social instability. The world’s stable now. People are happy; they get what they want, and they never want what they can’t get. They’re well off; they’re safe; they’re never ill; they’re not afraid of death; they’re blissfully ignorant of passion and old age; they’re plagued with no mothers or fathers; they’ve got no wives, or children, or lovers to feel strongly about; they’re so conditioned that they practically can’t help behaving as they ought to behave. And if anything should go wrong, there’s soma. ([Location 2670](https://readwise.io/to_kindle?action=open&asin=B00JTYQJ3K&location=2670))
- Happiness is never grand.” ([Location 2688](https://readwise.io/to_kindle?action=open&asin=B00JTYQJ3K&location=2688))
- Happiness is a hard master—particularly other people’s happiness. A much harder master, if one isn’t conditioned to accept it unquestioningly, ([Location 2764](https://readwise.io/to_kindle?action=open&asin=B00JTYQJ3K&location=2764))
- “One of Aldous’s major preoccupations was how to achieve self-transcendence while yet remaining a committed social being—how to escape from the prison bars of self and the pressures of here and now into realms of pure goodness and pure enjoyment.” ([Location 3225](https://readwise.io/to_kindle?action=open&asin=B00JTYQJ3K&location=3225))
