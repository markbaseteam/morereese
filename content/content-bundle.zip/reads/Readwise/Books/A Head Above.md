# A Head Above

![rw-book-cover](https://images-na.ssl-images-amazon.com/images/I/51WNToW6AaL._SL200_.jpg)

## Metadata
- Author: [[Mansal Denton]]
- Full Title: A Head Above
- Category: #books

## Highlights
- Peculiar Potions, ([Location 944](https://readwise.io/to_kindle?action=open&asin=B074WC8DKH&location=944))
- Yerkes-Dodson Law. ([Location 1166](https://readwise.io/to_kindle?action=open&asin=B074WC8DKH&location=1166))
