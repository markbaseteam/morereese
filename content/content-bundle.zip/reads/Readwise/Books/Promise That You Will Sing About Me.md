# Promise That You Will Sing About Me

![rw-book-cover](https://m.media-amazon.com/images/I/81+PKQya7kS._SY160.jpg)

## Metadata
- Author: [[Miles Marshall Lewis]]
- Full Title: Promise That You Will Sing About Me
- Category: #books

## Highlights
- presents himself as a feminist ally in this way, but the pose ([Location 953](https://readwise.io/to_kindle?action=open&asin=B08FZBK6F4&location=953))
