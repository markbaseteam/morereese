# Inner Work

![rw-book-cover](https://images-na.ssl-images-amazon.com/images/I/510rVoVOwbL._SL200_.jpg)

## Metadata
- Author: [[Robert A. Johnson]]
- Full Title: Inner Work
- Category: #books

## Highlights
- Each of us is building a life, building an edifice. Within each person the plan and the basic structure are established in a deep place in the unconscious. But we need to consult the unconscious and cooperate with it in order to realize the full potential that is built into us. And we have to face the challenges and painful changes that the process of inner growth always brings. ([Location 164](https://readwise.io/to_kindle?action=open&asin=B002SVQCUG&location=164))
    - Tags: [[pink]] 
- The purpose of learning to work with the unconscious is not just to resolve our conflicts or deal with our neuroses. We find there a deep source of renewal, growth, strength, and wisdom. We connect with the source of our evolving character; we cooperate with the process whereby we bring the total self together; we learn to tap that rich lode of energy and intelligence that waits within. ([Location 190](https://readwise.io/to_kindle?action=open&asin=B002SVQCUG&location=190))
    - Tags: [[pink]] 
- Jung observed that most of the neurosis, the feeling of fragmentation, the vacuum of meaning, in modern lives, results from this isolation of the ego-mind from the unconscious. ([Location 204](https://readwise.io/to_kindle?action=open&asin=B002SVQCUG&location=204))
    - Tags: [[pink]] 
- if we don’t go to the spirit, the spirit comes to us as neurosis. ([Location 214](https://readwise.io/to_kindle?action=open&asin=B002SVQCUG&location=214))
    - Tags: [[pink]] 
- Each person has a distinct psychological structure. It is only by living that inherent structure that one discovers what it means to be an individual. ([Location 236](https://readwise.io/to_kindle?action=open&asin=B002SVQCUG&location=236))
    - Tags: [[pink]] 
- In the world of psyche, it is your work, rather than your theoretical ideas, that builds consciousness. ([Location 253](https://readwise.io/to_kindle?action=open&asin=B002SVQCUG&location=253))
    - Tags: [[pink]] 
