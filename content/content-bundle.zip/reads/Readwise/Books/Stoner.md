# Stoner

![rw-book-cover](https://images-na.ssl-images-amazon.com/images/I/41ScPtga3QL._SL200_.jpg)

## Metadata
- Author: [[John Williams and John McGahern]]
- Full Title: Stoner
- Category: #books

## Highlights
- “You must remember what you are and what you have chosen to become, and the significance of what you are doing. There are wars and defeats and victories of the human race that are not military and that are not recorded in the annals of history. Remember that while you’re trying to decide what to do.” ([Location 597](https://readwise.io/to_kindle?action=open&asin=B003K15IF8&location=597))
- In his forty-third year William Stoner learned what others, much younger, had learned before him: that the person one loves at first is not the person one loves at last, and that love is not an end but a process through which one person attempts to know another. ([Location 2689](https://readwise.io/to_kindle?action=open&asin=B003K15IF8&location=2689))
- In his extreme youth Stoner had thought of love as an absolute state of being to which, if one were lucky, one might find access; in his maturity he had decided it was the heaven of a false religion, toward which one ought to gaze with an amused disbelief, a gently familiar contempt, and an embarrassed nostalgia. Now in his middle age he began to know that it was neither a state of grace nor an illusion; he saw it as a human act of becoming, a condition that was invented and modified moment by moment and day by day, by the will and the intelligence and the heart. ([Location 2698](https://readwise.io/to_kindle?action=open&asin=B003K15IF8&location=2698))
