# Finite and Infinite Games

![rw-book-cover](https://images-na.ssl-images-amazon.com/images/I/51PRkV8AbDL._SL200_.jpg)

## Metadata
- Author: [[James Carse]]
- Full Title: Finite and Infinite Games
- Category: #books

## Highlights
- It is, in fact, by knowing what the rules are that we know what the game is. ([Location 90](https://readwise.io/to_kindle?action=open&asin=B004W3FM4A&location=90))
- If the rules of a finite game are the contractual terms by which the players can agree who has won, the rules of an infinite game are the contractual terms by which the players agree to continue playing. ([Location 106](https://readwise.io/to_kindle?action=open&asin=B004W3FM4A&location=106))
- Finite players play within boundaries; infinite players play with boundaries. ([Location 120](https://readwise.io/to_kindle?action=open&asin=B004W3FM4A&location=120))
