# Deadlift Dynamite

![rw-book-cover](https://images-na.ssl-images-amazon.com/images/I/61chOyL5MTL._SL200_.jpg)

## Metadata
- Author: [[Andy Bolton, Pavel Tsatsouline]]
- Full Title: Deadlift Dynamite
- Category: #books

## Highlights
- strength training (and wish to gain some muscle ([Location 1227](https://readwise.io/to_kindle?action=open&asin=B00C4YONDU&location=1227))
- time for the lifter to start a new cycle. You may also like to experiment with shorter, more aggressive cycles or longer, more drawn out cycles. ([Location 1245](https://readwise.io/to_kindle?action=open&asin=B00C4YONDU&location=1245))
