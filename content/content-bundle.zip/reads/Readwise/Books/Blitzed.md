# Blitzed

![rw-book-cover](https://is4-ssl.mzstatic.com/image/thumb/Publication128/v4/2f/b3/f4/2fb3f4e1-af53-d39b-67f1-1f70bd4b9ade/9781328664099_marketingimage.jpg/1400x0w.jpg)

## Metadata
- Author: [[Norman Ohler]]
- Full Title: Blitzed
- Category: #books

## Highlights
- Nuremberg Race Laws of 1935 and the introduction of the Ahnenpass (Proof of Aryan Ancestry) manifested the demand for purity of the blood
- The Nazi Party’s Office of Racial Policy claimed that the Jewish character was essentially drug-dependent: the intellectual urban Jew preferred cocaine or morphine to calm his constantly “excited nerves” and give himself a feeling of peace and inner security.
- spaghetti with nutmeg, tomato sauce on the side, green salad—the favorite dish of Adolf Hitler
- While the Nazis’ war on drugs brought down the consumption of heroin and cocaine, the development of synthetic stimulants was accelerated and led to a new blossoming within the pharmaceutical companies.
- Pervitin became a symptom of the developing performance society. Boxed chocolates spiked with methamphetamine were even put on the market.
- the attack on Poland, which began on September 1, 1939, and sparked the Second World War,
- As coffee had hardly been available since the start of the war, methamphetamine was often added as a substitute to pep up ersatz versions of the drink.
- The Wehrmacht was thus the first army in the world to rely on a chemical drug. And Ranke, the Pervitin-addicted army physiologist, was responsible for its regulated use. A new kind of war was on the way.
- the Wehrmacht had ordered an enormous quantity for the army and the Luftwaffe: 35 million in all.
- Blitzkrieg was guided by methamphetamine. If not to say that Blitzkrieg was founded on methamphetamine.
  —Dr. Peter Steinkamp, medical historian
- were no
- In Germany the use of the substance now ran to over a million doses per month.*138 In February 1941 Conti again delivered a warning, this time in an internal memo to the Party: “I am following up with mounting concern the terrible abuse being practiced in the widest circles of the population. . . . This is an immediate danger to the health and future of our people.”
- The Wehrmacht High Command, along with the Reich Ministry for Arms and Ammunition, endorsed by Göring, had even classified Pervitin as “decisive for the outcome of the war
- In July 1942 the geographical reach of the Third Reich extended from the North Cape in Norway to North Africa and the Middle East. The plateau of the National Socialist expansion trip had been achieved—while the signs were already pointing to defeat. That summer saw the beginning of “Operation Reinhard,” the systematic killing of over 2 million Jews and 50,000 Sinti and Roma in occupied Poland.
- Eukodol [sic] is like a combination of junk and C [cocaine]. Trust the Germans to concoct some truly awful shit.
  —William Burroughs
- Studies show that two thirds of those who take crystal meth excessively suffer from psychosis after three years.3 Since Pervitin and crystal meth have the same active ingredient, and countless soldiers had been taking it more or less regularly since the invasion of Poland, the Blitzkrieg on France, or the attack on the Soviet Union, we must assume psychotic side-effects, as well as the need to keep increasing the dosage to achieve a noticeable effect.
- D IX was the front-runner: a mixture of 5 milligrams of Eukodal, 5 milligrams of cocaine, and 3 milligrams of methamphetamine—a brutal combination that might even have been to Hitler’s taste.
- Just as the victorious United States appropriated the Third Reich’s discoveries in rocket science and the exploration of outer space, the Nazi drug experiments were imported to explore inner worlds.41 The secret U.S. program MKUltra, based on Plötner’s initial work, took “Mind Kontrol” as its goal—the spelling with a “K” could be read as a nod to its German origins.
- The higher a man rises the more he has to be able to abstain. . . . If a street-sweeper is unwilling to sacrifice his tobacco or his beer, then I think, “Very well, my good man, that’s precisely why you’re a street-sweeper and not one of the ruling personalities of the State!”
  —Adolf Hitler42
- the last quarter of 1944 Hitler had become addicted to Eukodal—and now yearned for the narcotic.
- It is as if Hitler were less concerned with the loss of the world war than with the physical torments that he himself was going through, and which would not stop until his suicide.
