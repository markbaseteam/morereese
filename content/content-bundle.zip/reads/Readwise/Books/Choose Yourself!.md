# Choose Yourself!

![rw-book-cover](https://images-na.ssl-images-amazon.com/images/I/51htpzlPNQL._SL200_.jpg)

## Metadata
- Author: [[James Altucher]]
- Full Title: Choose Yourself!
- Category: #books

## Highlights
- to be ([Location 796](https://readwise.io/to_kindle?action=open&asin=B00CO8D3G4&location=796))
    - Tags: [[pink]] 
- the ([Location 1143](https://readwise.io/to_kindle?action=open&asin=B00CO8D3G4&location=1143))
    - Tags: [[pink]] 
- and Warren Buffett, have crashed and burned buying airlines. Warren ([Location 1551](https://readwise.io/to_kindle?action=open&asin=B00CO8D3G4&location=1551))
    - Tags: [[pink]] 
- We’re taught when we transition from childhood to adulthood to leave behind the stories of our youth. Don’t listen to that advice. ([Location 2378](https://readwise.io/to_kindle?action=open&asin=B00CO8D3G4&location=2378))
    - Tags: [[pink]] 
- The only superpower you really need is the one to constantly cultivate the attitude that forces you to ask, from the minute you wake up, to the minute you fall asleep, “What life can I save today?” ([Location 2393](https://readwise.io/to_kindle?action=open&asin=B00CO8D3G4&location=2393))
    - Tags: [[pink]] 
- Nobody can tell you what to do. ([Location 2430](https://readwise.io/to_kindle?action=open&asin=B00CO8D3G4&location=2430))
    - Tags: [[pink]] 
- It is through silence that sound, activity, and action erupts. ([Location 2434](https://readwise.io/to_kindle?action=open&asin=B00CO8D3G4&location=2434))
    - Tags: [[pink]] 
- Nothing is more important than the cultivation of yourself. ([Location 2444](https://readwise.io/to_kindle?action=open&asin=B00CO8D3G4&location=2444))
    - Tags: [[pink]] 
- “You must first be the change you want to see in this World.” ([Location 2453](https://readwise.io/to_kindle?action=open&asin=B00CO8D3G4&location=2453))
    - Tags: [[pink]] 
- Try this exercise: pretend everyone was sent to this planet to teach you. Famous people, dead people, your neighbors, your relatives, your co-workers. This will give you a strong feeling of humility. And guess what, you will learn from people, you will appreciate them more, and they will actually ([Location 2456](https://readwise.io/to_kindle?action=open&asin=B00CO8D3G4&location=2456))
    - Tags: [[pink]] 
- appreciate you more. Because everyone loves to teach. ([Location 2458](https://readwise.io/to_kindle?action=open&asin=B00CO8D3G4&location=2458))
    - Tags: [[pink]] 
- Study the history of the form you want to master. ([Location 2555](https://readwise.io/to_kindle?action=open&asin=B00CO8D3G4&location=2555))
    - Tags: [[pink]] 
- Wake up early. Avoid distractions. Work three to five hours a day and then enjoy the rest of the day. Be as perfectionist as you can, knowing that imperfection will still rule. Have the confidence to be magical and stretch the boundaries of your medium. Combine the tools of the medium itself with the message you want to convey. Don’t get stuck in the same rut—move ([Location 2561](https://readwise.io/to_kindle?action=open&asin=B00CO8D3G4&location=2561))
    - Tags: [[pink]] 
- forward, experiment, but with the confidence built up over experience. Change the rules but learn them first. ([Location 2566](https://readwise.io/to_kindle?action=open&asin=B00CO8D3G4&location=2566))
    - Tags: [[pink]] 
- Competent ([Location 2606](https://readwise.io/to_kindle?action=open&asin=B00CO8D3G4&location=2606))
    - Tags: [[pink]] 
- people move forward and do what they do. ([Location 2607](https://readwise.io/to_kindle?action=open&asin=B00CO8D3G4&location=2607))
    - Tags: [[pink]] 
- In every way, you can choose yourself now to succeed, to improve, to communicate, to extend your reach to the individuals who need your message. Don’t give up on this opportunity. ([Location 2651](https://readwise.io/to_kindle?action=open&asin=B00CO8D3G4&location=2651))
    - Tags: [[pink]] 
- Give something for free so people immediately see value in your approach immediately. ([Location 2659](https://readwise.io/to_kindle?action=open&asin=B00CO8D3G4&location=2659))
    - Tags: [[pink]] 
- You keep cold-calling customers and they hang ([Location 2660](https://readwise.io/to_kindle?action=open&asin=B00CO8D3G4&location=2660))
    - Tags: [[pink]] 
- “How do you get past this?” Diversification is everything. You get past “this” by having lots of “that”s. ([Location 2713](https://readwise.io/to_kindle?action=open&asin=B00CO8D3G4&location=2713))
    - Tags: [[pink]] 
- When you’re a kid, everything has a question mark at the end of it. Only later do they turn into periods. Or even exclamation points. ([Location 2741](https://readwise.io/to_kindle?action=open&asin=B00CO8D3G4&location=2741))
    - Tags: [[pink]] 
- Some will fall into the abyss created when the earth quakes. Some will not be able to master the tools of keeping healthy and building the platform of self-sufficiency that is necessary to choose yourself. But many will. I hope the readers of this book will. ([Location 2753](https://readwise.io/to_kindle?action=open&asin=B00CO8D3G4&location=2753))
    - Tags: [[pink]] 
- I want you to take out a pen and a piece of paper and do something for me. ([Location 2758](https://readwise.io/to_kindle?action=open&asin=B00CO8D3G4&location=2758))
    - Tags: [[pink]] 
- Too many people, in the rush of their lives, ([Location 2785](https://readwise.io/to_kindle?action=open&asin=B00CO8D3G4&location=2785))
    - Tags: [[pink]] 
- stop at just the second ([Location 2785](https://readwise.io/to_kindle?action=open&asin=B00CO8D3G4&location=2785))
    - Tags: [[pink]] 
- circle, the ones they immediately impact. ([Location 2786](https://readwise.io/to_kindle?action=open&asin=B00CO8D3G4&location=2786))
    - Tags: [[pink]] 
