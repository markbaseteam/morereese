# The Soul of an Octopus

![rw-book-cover](https://images-na.ssl-images-amazon.com/images/I/51NMDC1jFWL._SL200_.jpg)

## Metadata
- Author: [[Sy Montgomery]]
- Full Title: The Soul of an Octopus
- Category: #books

## Highlights
- Alfred Tennyson ([Location 128](https://readwise.io/to_kindle?action=open&asin=B00LD1RZX0&location=128))
- an octopus is put together completely differently, with three hearts, a brain that wraps around its throat, and a covering of slime instead of hair. Even their blood is a different color from ours; it’s blue, because copper, not iron, carries its oxygen. ([Location 217](https://readwise.io/to_kindle?action=open&asin=B00LD1RZX0&location=217))
- Three fifths of octopuses’ neurons are not in the brain but in the arms. ([Location 232](https://readwise.io/to_kindle?action=open&asin=B00LD1RZX0&location=232))
- Hatching from an egg the size of a grain of rice weighing three-tenths of a gram, a baby giant Pacific octopus doubles its weight every eighty days until it reaches about 44 pounds, then doubles its weight every four months until maturity. ([Location 598](https://readwise.io/to_kindle?action=open&asin=B00LD1RZX0&location=598))
- hydrostatic muscles. ([Location 602](https://readwise.io/to_kindle?action=open&asin=B00LD1RZX0&location=602))
- electric skin. ([Location 676](https://readwise.io/to_kindle?action=open&asin=B00LD1RZX0&location=676))
- “cephalopods are the only example outside of vertebrates of how to build a complex, clever brain.” ([Location 733](https://readwise.io/to_kindle?action=open&asin=B00LD1RZX0&location=733))
- New evidence suggests cephalopods might be able to see with their skin. ([Location 750](https://readwise.io/to_kindle?action=open&asin=B00LD1RZX0&location=750))
- “theory of mind.” ([Location 1205](https://readwise.io/to_kindle?action=open&asin=B00LD1RZX0&location=1205))
- Theory of mind is considered an important component of consciousness, because it implies self-awareness. ([Location 1210](https://readwise.io/to_kindle?action=open&asin=B00LD1RZX0&location=1210))
- In the wild, over the course of about three weeks, a female giant Pacific octopus might lay between 67,000 and 100,000 eggs. ([Location 1377](https://readwise.io/to_kindle?action=open&asin=B00LD1RZX0&location=1377))
- In fact, octopuses have a hormone so like oxytocin that scientists named it cephalotocin. ([Location 1653](https://readwise.io/to_kindle?action=open&asin=B00LD1RZX0&location=1653))
- The ocean, for me, is what LSD was to Timothy Leary. He claimed the hallucinogen is to reality what a microscope is to biology, affording a perception of reality that was not before accessible. ([Location 2055](https://readwise.io/to_kindle?action=open&asin=B00LD1RZX0&location=2055))
- Lévy distribution. ([Location 2731](https://readwise.io/to_kindle?action=open&asin=B00LD1RZX0&location=2731))
