# Letters to a Young Poet

![rw-book-cover](https://images-na.ssl-images-amazon.com/images/I/51-MR2YbBUL._SL200_.jpg)

## Metadata
- Author: [[Rainer Maria Rilke]]
- Full Title: Letters to a Young Poet
- Category: #books

## Highlights
- No one can advise and assist you, no one. There is only one way: go into yourself. Seek out the reason that commands you to write; discover if it has stretched out its roots into the deepest part of your heart, admit to yourself whether you would have to die if it were forbidden you to write. ([Location 46](https://readwise.io/to_kindle?action=open&asin=B00NF0MGZO&location=46))
- go into yourself and to examine the depths from which your life springs; at its source you will find the answer to the question—whether you must create. ([Location 68](https://readwise.io/to_kindle?action=open&asin=B00NF0MGZO&location=68))
- Live for a while in these books, learn from them whatever seems to you worth learning, but above all love them. This love will be repaid a thousand times a thousand, ([Location 109](https://readwise.io/to_kindle?action=open&asin=B00NF0MGZO&location=109))
- Works of art are of an unlimited solitude, and can be reached by nothing so little as criticism. Only love can grasp and hold them, and can face them justly.—Consider ([Location 139](https://readwise.io/to_kindle?action=open&asin=B00NF0MGZO&location=139))
- And in fact artistic experience lies so incredibly close to sexuality, to its grief and its bliss, that both phenomena are really just different forms of the same longing and delight. ([Location 154](https://readwise.io/to_kindle?action=open&asin=B00NF0MGZO&location=154))
- If you adhere to nature, to what is simple in it, to what is small and overlooked, but can so unexpectedly become great and immeasurable; if you have this love for things that are most small and wholly simple, striving like a servant to gain their trust, even though they are obviously poor: ([Location 189](https://readwise.io/to_kindle?action=open&asin=B00NF0MGZO&location=189))
- then everything will become easier, more harmonious, and at some level reconciled, maybe not in the sense of explicit understanding, which stands back amazed, but in your innermost consciousness, in wakefulness and knowledge. ([Location 191](https://readwise.io/to_kindle?action=open&asin=B00NF0MGZO&location=191))
- fecundity, ([Location 213](https://readwise.io/to_kindle?action=open&asin=B00NF0MGZO&location=213))
- In one creative thought a thousand forgotten nights of love revive, filling it with majesty and exaltation. ([Location 217](https://readwise.io/to_kindle?action=open&asin=B00NF0MGZO&location=217))
- love your solitude, accept the pain ([Location 232](https://readwise.io/to_kindle?action=open&asin=B00NF0MGZO&location=232))
- it causes you, and make a melody with it. ([Location 232](https://readwise.io/to_kindle?action=open&asin=B00NF0MGZO&location=232))
- Those who are close to you are far off, and so you write, and this shows that the space around you is broadening. And if what is near you is far off, then your distance is already among the stars and is very large; take joy in your growth, on which indeed you can take no companion, and be kind to those who stay behind, be steadfast and at peace before them, and do not torment them with your doubts and do not frighten them with your confidence or joy, which they could not understand. ([Location 232](https://readwise.io/to_kindle?action=open&asin=B00NF0MGZO&location=232))
- there is only one solitude, and it is vast and not easy to carry, ([Location 393](https://readwise.io/to_kindle?action=open&asin=B00NF0MGZO&location=393))
- What occurs in your deepest interior is worthy of all your love, ([Location 405](https://readwise.io/to_kindle?action=open&asin=B00NF0MGZO&location=405))
- If only it were possible for us to see farther than our knowledge reaches, and even a little past the far reaches of our foresight, perhaps we would endure our sorrows with greater trust than our joys. ([Location 543](https://readwise.io/to_kindle?action=open&asin=B00NF0MGZO&location=543))
- we also must gradually learn to recognize that what we call destiny, steps forth from people from the inside out, not from the outside in. ([Location 559](https://readwise.io/to_kindle?action=open&asin=B00NF0MGZO&location=559))
- perhaps all the dragons of our lives are princesses who are only waiting to see us just once as beautiful and brave. Perhaps everything terrifying is, in its deepest essence, something helpless that wants help from us. ([Location 593](https://readwise.io/to_kindle?action=open&asin=B00NF0MGZO&location=593))
    - Tags: [[dragon]] 
- If some of your transitions are sickly, then keep in mind that sickness is the means for an organism to free itself from what is alien; one must help it to be sick, to run the whole course of its sickness and break through, for that is its progress. ([Location 599](https://readwise.io/to_kindle?action=open&asin=B00NF0MGZO&location=599))
- do not believe that he who is seeking to comfort you lives effortlessly among the simple and quiet words that sometimes do you good. His life has much trouble and sadness and remains far behind you. But were it otherwise, he could never have found those words. ([Location 616](https://readwise.io/to_kindle?action=open&asin=B00NF0MGZO&location=616))
- let life happen to you. Believe me: life is right, every time. ([Location 632](https://readwise.io/to_kindle?action=open&asin=B00NF0MGZO&location=632))
- And to be in situations that work upon us, that from time to time set us before great, natural ([Location 664](https://readwise.io/to_kindle?action=open&asin=B00NF0MGZO&location=664))
- objects, ([Location 665](https://readwise.io/to_kindle?action=open&asin=B00NF0MGZO&location=665))
