# The Value Chain of the Open Metaverse

![rw-book-cover](https://readwise-assets.s3.amazonaws.com/static/images/article1.be68295a7e40.png)

## Metadata
- Author: [[NFTS]]
- Full Title: The Value Chain of the Open Metaverse
- Category: #articles
- Document Tags: [[>unread]] 
- URL: https://www.notboring.co/p/the-value-chain-of-the-open-metaverse

## Highlights
- the Metaverse as an open platform could ultimately be an order of magnitude larger than any one company, including Epic, built entirely on our own as our own proprietary piping.
- The reason big new things sneak by incumbents is that the next big thing always starts out being dismissed as a “toy.” Disruptive technologies are dismissed as toys because when they are first launched they “undershoot” user needs.
- Web3, then, isn’t as much an idealistic repudiation of Web 2.0 (although that’s a good marketing tool) as much as it is a natural evolution of the market made possible by new technology
- The early internet in the 1980s through the early 2000s, Web 1.0, was decentralized. It was built on top of a series of open protocols that anyone could build directly on top of, like HTTP for websites, SMTP for email, SMS for messaging, IRC for chat, and FTP for file transfer
- By dematerializing the supply chain and selling directly to the end user, as represented by the Avatar, the D2A value chain removes entire steps - manufacturing, logistics, and support - and integrates R&D, Retail, and Marketing
- Web3 is the next version of the internet, built on top of crypto-economic networks
- APIs All the Way Down
- “attract” to “extract.”
- At the heart of Web3 is the idea of consensus protocols and standards with money baked in
- “Competitive advantage cannot be understood by looking at a firm as a whole. It stems from the many discrete activities a firm performs in designing, producing, marketing, delivering, and supporting its product."
- State aggregators became the dominant players of the internet and one surprising result of Internet 2.0 is that many of the original open protocols have been replaced by state aggregators.
- The Open Metaverse is one built from the connection and interoperability of a series of different platforms, worlds, sites, stores, experiences and more.
- Web 1.0 didn’t have standard protocols for many of the things that power the internet today: payments, search, apps, social media, commerce, credit, and more.
- Proponents of the Metaverse predict that it will be a multi-trillion-dollar digital economy that replaces the internet with shared virtual worlds.
- “Just as Direct-to-Consumer dematerialized the supply chain by 40% and enabled new business models to flourish,” Gill says “Direct-to-Avatar will, dematerialize the rest of the supply chain, allowing brands and creators to sell direct to Avatar.” He expects D2A to reach at least $1 trillion in the next decade
- Losers [meaning people who lose the economic game, not being mean] are the people who are set in roles or stations in life where the output of their effort is wholly realized by someone else. As they learn throughout their careers, their skill or engagement might lead to incremental career progress, but no real leverage of any kind.
- Non-Fungible Tokens (NFTs) are cryptographic tokens that prove authenticity, ownership, and scarcity of digital assets.
- A closed Metaverse is controlled by one or more large companies and lacks interoperability between platforms.
- If done correctly, the Metaverse becomes more than the escape from a bleak reality that it is in Ready Player One, but a new way to earn a middle class income while pursuing your passions with ever-growing and more profitable niches of your people, around the globe.
- Web 1.0 protocols were stateless, meaning that they didn’t capture state, or user data. “Capturing user data” has negative connotations today, but stateless protocols meant that website owners didn’t even know whether I’d visited a site before, and couldn’t tailor experiences accordingly
- Instead of building siloed products, Web3 is built for interoperability
- An NFT serves as a digital certificate of authenticity, backed by math, on a public ledger, that incontrovertibly proves that the holder owns a one-of-a-kind digital (and sometimes physical) asset.
