# Digital Gardens Let You Cultivate Your Own Little Bit of the Internet

![rw-book-cover](https://wp.technologyreview.com/wp-content/uploads/2020/08/digital-garden_web.jpg?resize=1200,600)

## Metadata
- Author: [[Tanya Basu]]
- Full Title: Digital Gardens Let You Cultivate Your Own Little Bit of the Internet
- Category: #articles
- URL: https://www.technologyreview.com/2020/09/03/1007716/digital-gardens-let-you-cultivate-your-own-little-bit-of-the-internet/

## Highlights
- Digital gardens explore a wide variety of topics and are frequently adjusted and changed to show growth and learning, particularly among people with niche interests. Through them, people are creating an internet that is less about connections and feedback, and more about quiet spaces they can call their own. ([View Highlight](https://read.readwise.io/read/01grjc3bdtec5t8c2rtmhsctjd))
    - Tags: [[digital-gardening]] 
- The movement might be gaining steam now, but its roots date back to 1998, when Mark Bernstein introduced the idea of the “[hypertext garden](http://www.eastgate.com/garden/Enter.html),” arguing for spaces on the internet that let a person wade into the unknown. “Gardens … lie between farmland and wilderness,” he [wrote](http://www.eastgate.com/garden/Gardens.html). “The garden is farmland that delights the senses, designed for delight rather than commodity.” (His [digital garden](https://www.markbernstein.org/) includes a recent review of a Bay Area carbonara dish and reflections on his favorite essays.) ([View Highlight](https://read.readwise.io/read/01grjc4pyh5v9zvzk5v18jwtq8))
    - Tags: [[digital-gardening]] [[history-of]] 
- Tom Critchlow, a consultant who has been cultivating [his digital garden](https://tomcritchlow.com/wiki/) for years, spells out the main difference between old-school blogging and digital gardening. “With blogging, you’re talking to a large audience,” he says. “With digital gardening, you’re talking to yourself. You focus on what you want to cultivate over time.” ([View Highlight](https://read.readwise.io/read/01grjcd4jcxz631d70ay2dvqje))
    - Tags: [[digital-gardening]] 
