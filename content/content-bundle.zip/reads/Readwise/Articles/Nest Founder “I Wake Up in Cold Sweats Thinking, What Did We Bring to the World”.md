# Nest Founder: “I Wake Up in Cold Sweats Thinking, What Did We Bring to the World?”

![rw-book-cover](https://readwise-assets.s3.amazonaws.com/static/images/article3.5c705a01b476.png)

## Metadata
- Author: [[fastcompany.com]]
- Full Title: Nest Founder: “I Wake Up in Cold Sweats Thinking, What Did We Bring to the World?”
- Category: #articles
- URL: https://www.fastcompany.com/90132364/nest-founder-i-wake-up-in-cold-sweats-thinking-what-did-we-bring-to-the-world

## Highlights
- “I wake up in cold sweats every so often thinking, what did we bring to the world?” he says. “Did we really bring a nuclear bomb with information that can–like we see with fake news–blow up people’s brains and reprogram them? Or did we bring light to people who never had information, who can now be empowered?”
