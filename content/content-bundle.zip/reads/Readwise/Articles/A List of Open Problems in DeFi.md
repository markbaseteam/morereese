# A List of Open Problems in DeFi

![rw-book-cover](https://readwise-assets.s3.amazonaws.com/static/images/article2.74d541386bbf.png)

## Metadata
- Author: [[Soulbound and Hard Problems in Cryptocurrency: Five years later]]
- Full Title: A List of Open Problems in DeFi
- Category: #articles
- URL: https://mirror.xyz/0xemperor.eth/0guEj0CYt5V8J5AKur2_UNKyOhONr1QJaG4NGDF0YoQ

## Highlights
- The stick of measure will be solving problems that either extend the ethos of decentralization to every real-world product or rectify the errors that current systems possess or fill the gaps to make the system seamlessly functional, all of this leads to more adoption or reduces the friction/inefficiencies in the ecosystem.
