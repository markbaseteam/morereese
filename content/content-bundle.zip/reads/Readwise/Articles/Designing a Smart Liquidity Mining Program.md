# Designing a Smart Liquidity Mining Program

![rw-book-cover](https://readwise-assets.s3.amazonaws.com/static/images/article0.00998d930354.png)

## Metadata
- Author: [[Kevin Chan]]
- Full Title: Designing a Smart Liquidity Mining Program
- Category: #articles
- URL: https://medium.com/uma-project/designing-a-smart-liquidity-mining-program-lm-2-0-d46072a11cfd

## Highlights
- Designing a smart liquidity mining program can be as simple or complex as a DAO wishes to make it. However, the general idea is very straightforward — the project chooses a metric to target and defines a payout of tokens dependent on the performance of that metric.
