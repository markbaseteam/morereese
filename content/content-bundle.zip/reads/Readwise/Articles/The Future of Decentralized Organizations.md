# The Future of Decentralized Organizations

![rw-book-cover](https://readwise-assets.s3.amazonaws.com/static/images/article1.be68295a7e40.png)

## Metadata
- Author: [[Rob Solomon]]
- Full Title: The Future of Decentralized Organizations
- Category: #articles
- Document Tags: [[dao]] [[rob-solomon]] [[the-rise-of-dao-culture]] 
- URL: https://media.consensys.net/cone-the-future-of-decentralized-organizations-f0f2851de46f

## Highlights
- The traditional hierarchical corporate structure works, but it has debilitating limits when it comes to information processing. By this, I’m not referring to the typical financial and operating metrics used by data engineers to construct dashboards, but rather information such as unique ideas, employee morale, the objective value of a specific output, how one outcome impacts others, and so on.
- The global economy is actually just an incredibly big, decentralized company
- Friedrich Hayek’s 1945 article “The Use of Knowledge in Society”
- In an organization of five million, however, the “chief” cannot easily understand all of the important internal information and cannot manage the company effectively. Creating currencies and internal markets, where teams behave like distinct businesses, is essential.
- Cone, a future-of-work focused software development and consulting firm, seeks to create the best of both worlds by turning large companies into networks of autonomous company-like teams.
- In the Cone framework, budgeting becomes more like fundraising, and budget approvers become more like venture capitalists
