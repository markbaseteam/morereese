# Principles-and-Models-of-Decentralization_miles-Jennings_a16zcrypto

![rw-book-cover](https://readwise-assets.s3.amazonaws.com/static/images/article1.be68295a7e40.png)

## Metadata
- Author: [[Miles Jennings]]
- Full Title: Principles-and-Models-of-Decentralization_miles-Jennings_a16zcrypto
- Category: #articles
- URL: https://readwise.io/reader/document_raw_content/31891148

## Highlights
- nfrastructure that can generate and be supported by robust decentralized economies. Upon this decentralized and shared infrastructure, products and services can be built that rival and surpass the products and services of today’s centralized systems and that could ultimately secure our fundamental freedoms. It began with a single decentralized blockchain network, grew into the decentralized products and ([View Highlight](https://read.readwise.io/read/01grdacbnmzp2rwnez2rcm1gc1))
