# API Gateway

![rw-book-cover](https://readwise-assets.s3.amazonaws.com/static/images/article0.00998d930354.png)

## Metadata
- Author: [[Image Source:]]
- Full Title: API Gateway
- Category: #articles
- URL: https://www.solo.io/solutions/api-gateway/

## Highlights
- An API gateway is a piece of software infrastructure that sits between the outside world (clients or end users) and the backend services in your datacenter or cloud.
- An API gateway functions to accept incoming requests (traffic), routes them to the appropriate backend service based on a set of rules and policies defined by the organization, and then returns the appropriate result to the end user or client.
    - Tags: [[api]] [[explainer]] 
- An API gateway is part of the overall API management system and although it is not new, the role of the API gateway is going through an identity crisis as we adopt newer platforms like Kubernetes, containers, and public cloud. API management is a broader discipline that includes the process of creating, publishing, managing, reporting, and sometimes monetizing APIs.
- The API gateway acts to intercept all your incoming traffic and route it to the appropriate backend service in compliance with the rules and policies implemented by your administrator.
- APIs are the interface by which your application services communicate and the gateway is the control point for routing, shaping, and securing that traffic.
