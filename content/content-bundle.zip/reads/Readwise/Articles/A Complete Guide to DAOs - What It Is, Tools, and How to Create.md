# A Complete Guide to DAOs - What It Is, Tools, and How to Create

![rw-book-cover](https://readwise-assets.s3.amazonaws.com/static/images/article2.74d541386bbf.png)

## Metadata
- Author: [[Arweave Transaction]]
- Full Title: A Complete Guide to DAOs - What It Is, Tools, and How to Create
- Category: #articles
- Document Tags: [[dao]] [[guide]] [[how-to]] 
- URL: https://mirror.xyz/pedoispe.eth/fS2SYfDhDXq34COXhTWmtLZsEuW8J7mkZMemKUvOkOs

## Highlights
- A kind of Digital Cooperative. It’s a structure that brings innovative properties to an organization, like transparent and digital management, self-executed rules, seamless revenue sharing, open balance sheet, long-term alignment incentives with all stakeholders; that are virtually impossible to implement in the current organizational structures (analog organizations).
- Today, the two main social structures that we know are Companies and Governments.
- DAOs are a merge between both in a native digital structure.
- Companies are for-profit legal entities incorporated through a social contract. Roughly speaking, the shareholders in the cap-table are the equity owners and make the company’s strategic decisions, and also have the right to receive yield based on their shareholding.
- although the top layer of this structure may be digital - i.e buying stocks online, digitally signing contracts, etc. - the entire infrastructure foundation is analog: countless contracts based on human language signed by stakeholders.
- Governments** are also legal structures but non-profit. The citizens are taxed to create a budget that will be used for public management. This administration is democratic, where each person votes for representatives who then influence policy initiatives and budget allocation.
- Like companies, the government works with a few digital interfaces but all the operational infrastructure is analog, with signed contracts or implicit social agreements (you never signed a contract agreeing to pay taxes, for example).
- The main 3 features to highlight are the Rules, the Balance Sheet, and the Ownership Token
- The Rules are not social contracts enforced by a legal body. On DAOs the main rules are self-executing code in a blockchain (smart contracts)
- The Balance Sheet is not composed of fiat money. The balance sheet is on a blockchain composed of cryptocurrencies and belongs to the organization, with many possible access restrictions
- The Ownership Token is not a legal document as social security number or company stock. In DAOs, tokens are digital (crypto assets) and issued by the organization, working similarly to a cryptocurrency
