# What Comprises an Ethereum Fullnode Implementation?

![rw-book-cover](https://readwise-assets.s3.amazonaws.com/static/images/article0.00998d930354.png)

## Metadata
- Author: [[Steven McKie]]
- Full Title: What Comprises an Ethereum Fullnode Implementation?
- Category: #articles
- URL: https://medium.com/amentum/what-comprises-an-ethereum-fullnode-implementation-a9113ce3fe3a

## Highlights
- For Ethereum, a “fullnode” is a copy of the entire chains’ history of state changes, from one account to another. By default, all intermediary states of contract transactions and contract calls are computed on the fly during your initial sync (unless you adjust this setting specifically before you sync), and what is unneeded (older state transitions) are pruned away (removed to save storage).
    - Tags: [[node]] [[ethereum]] 
- As we stated above, by default all intermediary states of all contracts that interact on chain are computed by default, but not all of them are stored.
- In Bitcoin, the transition from one unspent output (UTXO model) to a new input when you send from one address to another, is the state update itself.
- fullnodes have to be able to: validate transactions that are being mined (if mining); apply the block reward (which is now 3 ETH/block at time of this writing based on recent EIPs); and, the most important task for the majority of users, verifying that state and the resulting state changes are applied properly and follow the consensus rules (which are checked against the state trie in each new block header).
- Here’s each of the various types of clients you can configure on Ethereum:
  Light Clients: Requires no validation, requests the current state from the P2P network to verify current state (fine for processing payments and simple contract calls), but your validation is out-sourced to other fullnodes with the necessary information.
  Fast Node (Fast Sync/Warp Sync): Will not validate intermediate states during the initial sync, will validate everything else after that, however. This allows older data to be pruned that likely has nothing to do with your transactions
  Full Node: As described above, validates everything, and will prune old intermediate states from memory, and will keep an archive of future state trie updates.
  Archive Node (Historical Node): Validates and stores all intermediate states, nothing is pruned, all state transitions for accounts are retrievable. Future state trie updates and full intermediate states are stored.
- We are in the firm belief that Ethereum’s capability to have so much flexibility with how it stores and updates its state root gives it a real strategic advantage to platforms following UTXO models.
- We see a future of many clients, all acting as independent economic agents, with different data availability requirements.
