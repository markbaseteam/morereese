# The Dao of DAOs

![rw-book-cover](https://readwise-assets.s3.amazonaws.com/static/images/article3.5c705a01b476.png)

## Metadata
- Author: [[notboring.co]]
- Full Title: The Dao of DAOs
- Category: #articles
- URL: https://www.notboring.co/p/the-dao-of-daos

## Highlights
- The Ether (ETH) that hackers stole from The DAO on June 17, 2016 would be worth $6.6 billion today if it weren’t for the fork.
- An NFT is a piece of digital media; a DAO could be a whole media company
- A DAO is “decentralized” in that it runs on a blockchain and gives decision-making power to stakeholders instead of executives or board members, and “autonomous” in that it uses smart contracts, which are essentially applications or programs that run on a publicly accessible blockchain and trigger an action if certain conditions are met, without the need for human intervention.
- ifBitcoin is like Artificial Narrow Intelligence (ANI), DAOs are like Artificial General Intelligence (AGI).
