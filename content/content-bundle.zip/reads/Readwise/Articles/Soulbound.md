# Soulbound

![rw-book-cover](https://readwise-assets.s3.amazonaws.com/static/images/article2.74d541386bbf.png)

## Metadata
- Author: [[eth.limo]]
- Full Title: Soulbound
- Category: #articles
- Document Tags: [[learn-pod]] [[pubdao]] [[soulbound-tokens]] 
- URL: https://vitalik.eth.limo/general/2022/01/26/soulbound.html

## Highlights
- soulbound
- A soulbound item, once picked up, cannot be transferred or sold to another player.
- But what if we want to create NFTs that are not just about who has the most money, and that actually try to signal something else?
- there is also a large and underexplored design space of what non-transferable NFTs could become
- If the goal is for governance power to be widely distributed, then transferability is counterproductive as concentrated interests are more likely to buy the governance rights up from everyone else
- If the goal is for governance power to go to the competent, then transferability is counterproductive because nothing stops the governance rights from being bought up by the determined but incompetent.
- What if DAO governance of blockchain protocols could somehow make governance power conditional on participation?
- Perhaps the one NFT that is the most robustly non-transferable today is the proof-of-humanity attestation.
- Proof-of-humanity profiles are de-facto soulbound, and infrastructure built on top of them could allow for on-chain items in general to be soulbound to particular humans.
- Making more items in the crypto space "soulbound" can be one path toward an alternative, where NFTs can represent much more of who you are and not just what you can afford.
- If we can, this opens a much wider door to blockchains being at the center of ecosystems that are collaborative and fun, and not just about money.
