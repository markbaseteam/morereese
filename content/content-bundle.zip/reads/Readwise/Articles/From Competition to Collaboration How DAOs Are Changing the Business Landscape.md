# From Competition to Collaboration: How DAOs Are Changing the Business Landscape

![rw-book-cover](https://readwise-assets.s3.amazonaws.com/static/images/article4.6bc1851654a0.png)

## Metadata
- Author: [[ROSO]]
- Full Title: From Competition to Collaboration: How DAOs Are Changing the Business Landscape
- Category: #articles
- URL: https://medium.com/p/fc084b27bf5d

## Highlights
- as we’ve come to learn, this competition-based model has its downsides. Despite the belief that competition drives innovation and progress, it also often leads to a culture of unhappiness and stress. Employees may feel overworked and undervalued, and the company as a whole may struggle to foster a sense of cohesion and shared purpose.
