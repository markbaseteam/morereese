# Re-Thinking Creative Agency: An Interview With Wassim Alsindi

![rw-book-cover](https://readwise-assets.s3.amazonaws.com/static/images/article4.6bc1851654a0.png)

## Metadata
- Author: [[William Kherbek]]
- Full Title: Re-Thinking Creative Agency: An Interview With Wassim Alsindi
- Category: #articles
- URL: https://www.berlinartlink.com/2022/01/07/wassim-alsindi-interview-digital-culture-0xsalon/

## Highlights
- It’s more a matter of having a machine and feeding it inputs.
