# Token Safe Harbor Proposal 2.0

![rw-book-cover](https://readwise-assets.s3.amazonaws.com/static/images/article1.be68295a7e40.png)

## Metadata
- Author: [[(ii)]]
- Full Title: Token Safe Harbor Proposal 2.0
- Category: #articles
- URL: https://www.sec.gov/news/public-statement/peirce-statement-token-safe-harbor-proposal-2.0

## Highlights
- his safe harbor is intended to provide Initial Development Teams with a three-year time period within which they can facilitate participation in, and the continued development of, a functional or decentralized network, exempt from the registration provisions of the federal securities laws so long as certain conditions are met.
- By the conclusion of the three-year period, the Initial Development Team must determine whether Token transactions involve the offer or sale of a security.
