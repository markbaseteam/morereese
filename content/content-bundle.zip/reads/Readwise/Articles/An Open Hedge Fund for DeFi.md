# An Open Hedge Fund for DeFi

![rw-book-cover](https://readwise-assets.s3.amazonaws.com/static/images/article1.be68295a7e40.png)

## Metadata
- Author: [[Force]]
- Full Title: An Open Hedge Fund for DeFi
- Category: #articles
- URL: https://medium.com/p/231002d7c4f5

## Highlights
- Core Vaults
- Edge Vaults
- Edge Vaults are next-gen automated yield strategies proposed by community members.
- Profit Sharing Vaults
- Profit Sharing Vaults are staking contracts that distribute profits generated from across all vaults and products in the ecosystem, pro rata.
- 80% to investors, 17% profit sharing and 3% to the individual(s) who designed/deployed the strategy. Core Vaults are distributed 80% to investors and 20% to profit sharing
- Force Prize is a large-scale global incentive competition to crowdsource DeFi’s highest performing investment strategies
- Force Prize
- Force’s governance token is Force.
- Symbol: FORCE
- Supply: 100,000,000
- Type: ERC-20 (Aragon minime)
