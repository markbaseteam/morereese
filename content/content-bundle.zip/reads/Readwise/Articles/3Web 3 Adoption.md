# 3Web 3 Adoption

![rw-book-cover](https://readwise-assets.s3.amazonaws.com/static/images/article1.be68295a7e40.png)

## Metadata
- Author: [[Moses Sam Paul]]
- Full Title: 3Web 3 Adoption
- Category: #articles
- URL: https://blog.cryptostars.is/web-3-adoption-10-million-a-system-dynamic-model-exploration-d1d8a71e243c

## Highlights
- the field of System Dynamics
