# Web3 Security: Attack Types and Lessons Learned

![rw-book-cover](https://readwise-assets.s3.amazonaws.com/static/images/article4.6bc1851654a0.png)

## Metadata
- Author: [[a16z.com]]
- Full Title: Web3 Security: Attack Types and Lessons Learned
- Category: #articles
- URL: https://a16z.com/2022/04/23/web3-security-crypto-hack-attack-lessons/

## Highlights
- as blockchains – the distributed computer networks that are the foundation of web3 – and their accompanying technologies and applications accrue value, they become increasingly coveted targets for attackers.
- Expert adversaries, often called Advanced Persistent Threats (APTs), are the boogeymen of security.
- Once a theoretical concern, governance attacks have now been demonstrated in the wild. Attackers can take out massive “flash loans” to swing votes, as recently happened to the decentralized finance, or DeFi, project Beanstalk.
