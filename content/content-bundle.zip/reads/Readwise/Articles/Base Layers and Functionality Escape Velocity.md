# Base Layers and Functionality Escape Velocity

![rw-book-cover](https://readwise-assets.s3.amazonaws.com/static/images/article1.be68295a7e40.png)

## Metadata
- Author: [[vitalik.ca]]
- Full Title: Base Layers and Functionality Escape Velocity
- Category: #articles
- Document Tags: [[ethereum]] [[vitalik]] [[web3]] 
- URL: https://vitalik.ca/general/2019/12/26/mvb.html

## Highlights
- Once a layer 1 protocol has achieved a certain level of functionality, which I will term "functionality escape velocity", then yes, you can do everything else on top without further changing the base.
- This ability to authorize state changes without completely setting all coins in an account free, is what I mean by "rich statefulness".
- "Keep layer 1 simple, make up for it on layer 2" is NOT a universal answer to blockchain scalability and functionality problems, because it fails to take into account that layer 1 blockchains themselves must have a sufficient level of scalability and functionality for this "building on top" to actually be possible (unless your so-called "layer 2 protocols" are just trusted intermediaries). However, it is true that beyond a certain point, any layer 1 functionality can be replicated on layer 2, and in many cases it's a good idea to do this to improve upgradeability. Hence, we need layer 1 development in parallel with layer 2 development in the short term, and more focus on layer 2 in the long term.
