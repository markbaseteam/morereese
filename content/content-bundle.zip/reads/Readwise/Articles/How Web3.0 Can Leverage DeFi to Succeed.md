# How Web3.0 Can Leverage DeFi to Succeed

![rw-book-cover](https://readwise-assets.s3.amazonaws.com/static/images/article3.5c705a01b476.png)

## Metadata
- Author: [[Suzanne Leigh]]
- Full Title: How Web3.0 Can Leverage DeFi to Succeed
- Category: #articles
- URL: https://medium.com/oct-network/how-web3-0-can-leverage-defi-to-succeed-ad8e189009cb

## Highlights
- Web3 — the decentralized digital economy — encompasses a vast space with many diverse protocols, such as GameFi, Decentralized Social Networks, DAOs, Decentralized Advertising, IoT Networks, Creator Economy, and more.
- Decentralized Finance, or Open Finance, in the final analysis, is still finance. Lest we forget, the function of finance isn’t solely to provide speculative assets but also to allocate capital efficiently for social production.
- The processing power of the public blockchain is limited by The Blockchain Trilemma, which describes blockchain’s challenges to harmoniously incorporate the three essentials — security, scalability, and decentralization.
- Web 3.0 applications need to use tokens to coordinate the interests of protocol participants and reward contributors with tokens.
- By design, both Polkadot and Cosmos pursue Hub Minimalism. The tenants of Hub minimalism are that the features of the hub of the multi-chain network, except for those that coordinate interoperability and shared security, should be as few as possible.
- The core of the cross-chain in the Octopus network is a set of smart contracts on the NEAR public chain. This group of smart contracts can be directly aggregated with other DeFi protocols on NEAR. To put it another way, the cross-chain hub of Octopus Network is NEAR.
- DeFi on Layer2 will face the dilemma of having only engines and no cars for a long time.
- Perhaps the trend in the blockchain world will be more similar to the history of urban development. Markets and cities gradually develop in places with convenient transportation and abundant water resources.
