# The Internet as Religion

![rw-book-cover](https://readwise-assets.s3.amazonaws.com/static/images/article3.5c705a01b476.png)

## Metadata
- Author: [[davidphelps.substack.com]]
- Full Title: The Internet as Religion
- Category: #articles
- URL: https://davidphelps.substack.com/p/the-internet-as-religion

## Highlights
- The fundamental polytheism of the internet might, in that sense, reflect our own promiscuous desires for the divine.
- Dust to dust; empire to DAO.
- The more attention you put towards Ethereum, the more financial rewards you tend to find, which makes “taking a break” have a significant amount of opportunity cost, and hence why this industry is generally a one-way street.
- The internet, in other words, is not just a way to raze, flatten, and cross-pollinate centuries of historical religion-building. It is also, in its own way, a religion itself. To worship at the internet’s
