# Innovating Towards Quality Jobs

![rw-book-cover](https://readwise-assets.s3.amazonaws.com/static/images/article1.be68295a7e40.png)

## Metadata
- Author: [[Griffith University Yunus Centre]]
- Full Title: Innovating Towards Quality Jobs
- Category: #articles
- URL: https://medium.com/p/62355e8003a1

## Highlights
- “Job Quality …is a fundamental dimension of human welfare in modern societies, since working conditions directly affect people’s quality of life”
