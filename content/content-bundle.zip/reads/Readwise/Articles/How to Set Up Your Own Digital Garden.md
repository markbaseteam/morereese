# How to Set Up Your Own Digital Garden

![rw-book-cover](https://nesslabs.com/wp-content/uploads/2020/09/digital-garden-tutorials-banner-mental-nodes.png)

## Metadata
- Author: [[Anne-Laure Le Cunff]]
- Full Title: How to Set Up Your Own Digital Garden
- Category: #articles
- URL: https://nesslabs.com/digital-garden-set-up

## Highlights
- A digital garden is an online space at the intersection of a notebook and a blog, where digital gardeners share seeds of thoughts to be cultivated in public. ([View Highlight](https://read.readwise.io/read/01grjdba5g9waendnnssqjk5bc))
    - Tags: [[digital-gardening]] [[definition-of]] 
