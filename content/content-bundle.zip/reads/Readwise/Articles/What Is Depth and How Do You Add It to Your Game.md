# What Is Depth and How Do You Add It to Your Game?

![rw-book-cover](https://readwise-assets.s3.amazonaws.com/static/images/article2.74d541386bbf.png)

## Metadata
- Author: [[gamedeveloper.com]]
- Full Title: What Is Depth and How Do You Add It to Your Game?
- Category: #articles
- URL: https://www.gamedeveloper.com/blogs/what-is-depth-and-how-do-you-add-it-to-your-game-

## Highlights
- The unfortunate side effect of metas is that it prevents players from expressing their own creativity
- Ultimately, a game with infinite depth has no meta, because no singular strategy is applicable to all the challenges in the game.
- Micro
- Mastery here comes from reading the situation.
- Build
- Mastery here comes from knowledge of the games systems.
- Investment
- Mastery here comes from pre-empting challenges.
