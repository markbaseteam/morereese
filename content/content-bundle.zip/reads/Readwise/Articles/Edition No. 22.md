# Edition No. 22

![rw-book-cover](https://readwise-assets.s3.amazonaws.com/static/images/article2.74d541386bbf.png)

## Metadata
- Author: [[Kyler Wandler]]
- Full Title: Edition No. 22
- Category: #articles
- URL: https://aroundtheblockchain.substack.com/p/edition-no-22

## Highlights
- The CFTC is asking the court to allow using chatbots and forum posts as a proper way to deliver lawsuit documents to the defendants
- DeFi Defense Attorney, Carlo D’Angelo
