# What Are Flash Loans and Why Are They Such a Hype in the DeFi Ecosystem

![rw-book-cover](https://readwise-assets.s3.amazonaws.com/static/images/article1.be68295a7e40.png)

## Metadata
- Author: [[Harman Puri]]
- Full Title: What Are Flash Loans and Why Are They Such a Hype in the DeFi Ecosystem
- Category: #articles
- URL: https://medium.com/p/2a55ef8356dd

## Highlights
- At the very core, flash loans are a type of unsecured loan that allows a user to borrow any amount without providing any sort of collateral or passing any credit check
- a user can borrow as much amount as they want through a flash loan. However, the user must pay it back within the same transaction.
