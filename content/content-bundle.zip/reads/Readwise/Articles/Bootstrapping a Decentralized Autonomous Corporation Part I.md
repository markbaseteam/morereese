# Bootstrapping a Decentralized Autonomous Corporation: Part I

![rw-book-cover](https://readwise-assets.s3.amazonaws.com/static/images/article1.be68295a7e40.png)

## Metadata
- Author: [[bitcoinmagazine.com]]
- Full Title: Bootstrapping a Decentralized Autonomous Corporation: Part I
- Category: #articles
- Document Tags: [[dao]] [[definition-of-dao]] [[foundations]] [[the-rise-of-dao-culture]] [[vitalik]] 
- URL: https://bitcoinmagazine.com/technical/bootstrapping-a-decentralized-autonomous-corporation-part-i-1379644274

## Highlights
- However, here a very interesting question arises: do we really need the people? On the one hand, the answer is yes: although in some post-Singularity future machines will be able to survive all on their own, for the forseeable future some kind of human action will simply be necessary to interact with the physical world. On the other hand, however, over the past two hundred years the answer has been increasingly no. The industrial revolution allowed us, for the first time, to start replacing human labor with machines on a large scale, and now we have advanced digitized factories and robotic arms that produce complex goods like automobiles all on their own.
- what if, with the power of modern information technology, we can encode the mission statement into code; that is, create an inviolable contract that generates revenue, pays people to perform some function, and finds hardware for itself to run on, all without any need for top-down human direction?
- in a sense Bitcoin itself can be thought of as a very early prototype of exactly such a thing.
