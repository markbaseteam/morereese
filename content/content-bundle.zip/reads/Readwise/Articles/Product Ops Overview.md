# Product Ops Overview

![rw-book-cover](https://www.svpg.com/wp-content/themes/svpg2022/app/img/svpg-social.png)

## Metadata
- Author: [[Marty Cagan]]
- Full Title: Product Ops Overview
- Category: #articles
- Document Tags: [[product]] 
- URL: https://www.svpg.com/product-ops-overview/

## Highlights
- ***“****At our company, Product Ops facilitates planning activities – long range planning, roadmap planning, and portfolio planning. We also facilitate the execution by coordinating and tracking activities across the organization from launch to sunsetting. We are responsible for putting standard operating procedures and governance in place around our unified lifecycle. We are the first point of engagement for stakeholder requests, and we manage timelines and deliverables.” – VP Product Ops for large hardware appliance company* ([View Highlight](https://read.readwise.io/read/01grdd38j5f3afeqstvfwv7crc))
    - Tags: [[product-operations]] [[product-management]] [[product]] 
- *While a Product Manager owns the development of the product (aka, the person who Builds The Thing) a Product Operations Manager handles the day to day tasks involved with development (aka, the person who Makes It Easier to Build The Thing).”* – [Product School](https://productschool.com/blog/product-management-2/product-ops-operations-manager/) ([View Highlight](https://read.readwise.io/read/01grdd5brn29zy6hqt2bebskzt))
    - Tags: [[product]] [[product-operations]] [[product-management]] 
- Very related to the *Two-in-a-Box PM* model (and in my view the major root cause of weak product managers) is the situation where the product leaders are not willing or able to do their job, especially when it comes to coaching and product strategy. ([View Highlight](https://read.readwise.io/read/01grdd9v1kv2d26bz54crtza0t))
    - Tags: [[product]] 
    - Note: This describes Joe
