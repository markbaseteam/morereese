# May 2021 Newsletter: Fiscal-Driven Inflation

![rw-book-cover](https://readwise-assets.s3.amazonaws.com/static/images/article1.be68295a7e40.png)

## Metadata
- Author: [[lynalden.com]]
- Full Title: May 2021 Newsletter: Fiscal-Driven Inflation
- Category: #articles
- URL: https://www.lynalden.com/may-2021-newsletter/

## Highlights
- consumer price index
- current situation is more comparable to the 1940s than the 1970s
- long-term debt cycle
