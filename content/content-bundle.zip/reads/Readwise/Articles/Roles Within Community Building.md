# Roles Within Community Building

![rw-book-cover](https://readwise-assets.s3.amazonaws.com/static/images/article4.6bc1851654a0.png)

## Metadata
- Author: [[medium.com]]
- Full Title: Roles Within Community Building
- Category: #articles
- Document Tags: [[community]] [[community-building]] [[dao]] [[pet3rpan]] 
- URL: https://medium.com/1kxnetwork/roles-within-community-building-3e3be23f3b13

## Highlights
- The Settlers (operates, focused on steady state growth and maintenance)
- The Town planners (strategizes, focused on optimizing efforts)
- The explorers (community growth)
- Explorers are experimenters and drive growth for a community.
- Settlers as the operational backbone of communities.
- The town planners (community strategy)
- Community is a creative process. At the core of community building is relationship building, a process that rarely can be forced
