# Wet Code and Dry

![rw-book-cover](https://readwise-assets.s3.amazonaws.com/static/images/article4.6bc1851654a0.png)

## Metadata
- Author: [[Nick Szabo]]
- Full Title: Wet Code and Dry
- Category: #articles
- URL: http://unenumerated.blogspot.com/2006/11/wet-code-and-dry.html

## Highlights
- There's a strong distinction to be made between "wet code," interpreted by the brain, and "dry code," interpreted by computers.
- As computers become "smarter" dry code is (very slowly) coming to do more that was formerly only done by wet code. Once it successfully emulates wet code it soon surpasses it in many respects; for example by now dry code can do simple arithmetic billions of times faster than the typical human.
- Human-read media is wet code whereas computer code and computer-readable files (to the extent a computer deals meaningfully with them) are "dry code."
- Traditional contracts are wet code whereas smart contracts are mostly dry code
- cognitive channels
