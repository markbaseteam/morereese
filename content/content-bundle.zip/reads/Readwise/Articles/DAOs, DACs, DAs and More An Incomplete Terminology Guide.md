# DAOs, DACs, DAs and More: An Incomplete Terminology Guide

![rw-book-cover](https://readwise-assets.s3.amazonaws.com/static/images/article2.74d541386bbf.png)

## Metadata
- Author: [[Vitalik Buterin]]
- Full Title: DAOs, DACs, DAs and More: An Incomplete Terminology Guide
- Category: #articles
- Document Tags: [[dao]] [[definition-of-dao]] [[vitalik]] 
- URL: https://blog.ethereum.org/2014/05/06/daos-dacs-das-and-more-an-incomplete-terminology-guide/

## Highlights
- DAOs == automation at the center, humans at the edges.
- in an autonomous agent, there is no necessary specific human involvement at all; that is to say, while some degree of human effort might be necessary to build the hardware that the agent runs on, there is no need for any humans to exist that are aware of the agent’s existence
- full autonomous agent
- a decentralized application has an unbounded number of participants on all sides of the market
- a decentralized application need not be necessarily financial
- Generally, decentralized applications fall into two classes
- The first class is a fully anonymous decentralized application
- The second class is a reputation-based decentralized application, where the system (or at least nodes in the system) keep track of nodes, and nodes maintain status inside of the application with a mechanism that is purely maintained for the purpose of ensuring trust
- a human organization can be defined as combination of two things: a set of property, and a protocol for a set of individuals, which may or may not be divided into certain classes with different conditions for entering or leaving the set, to interact with each other including rules for under what circumstances the individuals may use certain parts of the property.
- a decentralized organization involves a set of humans interacting with each other according to a protocol specified in code, and enforced on the blockchain
- A DO may or may not make use of the legal system for some protection of its physical property
- The ideal of a decentralized autonomous organization is easy to describe: it is an entity that lives on the internet and exists autonomously, but also heavily relies on hiring individuals to perform certain tasks that the automaton itself cannot do
- The main difference between a DA and a DAO is that a DAO has internal capital; that is, a DAO contains some kind of internal property that is valuable in some way, and it has the ability to use that property as a mechanism for rewarding certain activities
- The obvious difference between a DO and a DAO, and the one inherent in the language, is the word “autonomous”; that is, in a DO the humans are the ones making the decisions, and a DAO is something that, in some fashion, makes decisions for itself
- in a DAO collusion attacks are treated as a bug, whereas in a DO they are a feature
- a DAO without internal capital is a DA and an organization without internal capital is a forum
- Decentralized autonomous corporations/companies are a smaller topic, because they are basically a subclass of DAOs
