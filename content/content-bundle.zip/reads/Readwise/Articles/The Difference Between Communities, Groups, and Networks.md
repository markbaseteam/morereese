# The Difference Between Communities, Groups, and Networks

![rw-book-cover](https://readwise-assets.s3.amazonaws.com/static/images/article4.6bc1851654a0.png)

## Metadata
- Author: [[Daniel Ospina]]
- Full Title: The Difference Between Communities, Groups, and Networks
- Category: #articles
- URL: https://medium.com/p/179ac2052f25

## Highlights
- Contrarily, a mailing list is a “channel” as it only allows for communication in one/two directions.
- Groups are the result of a constant negotiation of identity between the individual differences and the common identity.
