# DeepDAO 2022: Discovery Engine for DAOs and People

![rw-book-cover](https://readwise-assets.s3.amazonaws.com/static/images/article2.74d541386bbf.png)

## Metadata
- Author: [[DeepDAO.io]]
- Full Title: DeepDAO 2022: Discovery Engine for DAOs and People
- Category: #articles
- Document Tags: [[aragon]] [[dao]] [[daohaus]] [[daostack]] [[deep-dao]] [[gnosis]] [[snapshot]] 
- URL: https://deepdao.substack.com/p/deepdao-2022-discovery-engine-for

## Highlights
- DeepDAO allows you to search for detailed information on over 4000 organizations.
- To fully understand the ecosystem it is imperative to go beyond the organizations, and consider the people within them as well as their mutual interactions.
- In order to help users investigate DAOs based on their core purposes, we have assigned them into several categories as follows: Investors: Invest in crypto or tangible assets and projects via Web3 tooling Venture: Seed-fund, incubate, network early-stage blockchain projects DeFi: Run Web3 protocols, assets or tools for decentralized non-custodial trading NFT: Serve NFT technology, communities and markets, NFTs as DeFi instruments Social: Build and organize communities and their ecosystems, as a main trade Greater Good: Work for set goals beyond membership boundaries and financial interests Art & Culture: Promote creators, their communities and markets, digital meme’ing and ideation Gaming: BUIDL games as a technological frontier; serve game communities & markets Product Creator: Focus attention and resources on product-building and curation Freelance & Hire: Run Web3 work marketplace, ongoing grants, BUIDLing guilds Media & Comms.: Produce & run Web3 media channels, PR, journalism and communication platforms DAO Tool: BUIDL for DAO governance, treasury, or other typical capabilities Tangible Assets: Produce, manage or trade things that are not online Undefined
- Our Governance Feed brings all of these decisions and votes to one place.
- DAO Tools are categorized in the following manner: DAO Guide: Learn about DAOs and DAO ecosystems Launcher: Set up a working DAO with governance and treasury, often extended Governance: Set and operate DAO institutions, rules, procedures, decisions & regulatory context Legal: Apply real-life legal structures to smart contracts Treasury: Manage blockchain assets, financial interactions & reports Identity: Verify Web3 identification before humans and applications Art & Culture: Promote creators, their communities and markets, digital ideation and meme’ing Analytics: Make meaning of DAOs and their ecosystems based on data and research DeFi: Utilize tokenized assets trading tools towards designated DAO missions NFTs: Serve NFT technology, communities and markets; NFTs as DeFi instruments Security & Privacy: Keep DAO and members’ software & data from harm’s way Media & Comms.: Engage in DAO-designated channels, journalism, PR, (human) communication platforms Dispute Resolution: Apply network algorithm solutions to smart contracts disputes Infrastructure: Leverage Web3 technologies to facilitate on-chain communal coordination.
