# Jump-Starting the Fund: Introducing the Early Contributor Program

![rw-book-cover](https://readwise-assets.s3.amazonaws.com/static/images/article1.be68295a7e40.png)

## Metadata
- Author: [[Force]]
- Full Title: Jump-Starting the Fund: Introducing the Early Contributor Program
- Category: #articles
- URL: https://medium.com/p/44bc58db6992

## Highlights
- The DAO treasury has allocated 5% of the total supply to reward Early Contributors.
