# What Is the Funding Rate for Perpetual Swaps?

![rw-book-cover](https://readwise-assets.s3.amazonaws.com/static/images/article4.6bc1851654a0.png)

## Metadata
- Author: [[Aditya Palepu]]
- Full Title: What Is the Funding Rate for Perpetual Swaps?
- Category: #articles
- URL: https://medium.com/p/a0335c4228a9

## Highlights
- The funding rate is similar to either a fee or a rebate, that traders pay or are paid to hold their positions, depending on which side of the market they are on.
- if perpetual_swap_price > underlying_price => funding_rate is positive
- if perpetual_swap_price < underlying_price => funding_rate is negative
- The funding rate is paid directly from long traders to short traders, or vice versa; the exchange itself doesn’t take a cut.
- Funding rates are defined by fixed intervals (e.g. BitMEX and Binance both use 8-hour intervals). At a high level, a funding rate is computed by assessing the average difference between a perpetual swap’s price and its underlying’s price during a specific interval of time
