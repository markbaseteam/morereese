# Anticapture

![rw-book-cover](https://readwise-assets.s3.amazonaws.com/static/images/article2.74d541386bbf.png)

## Metadata
- Author: [[mirror.xyz]]
- Full Title: Anticapture
- Category: #articles
- Document Tags: [[anticapture]] [[dao]] [[definition-of-dao]] [[spengrah]] [[the-rise-of-dao-culture]] 
- URL: https://mirror.xyz/hq.spengrah.eth/f6bZ6cPxJpP-4K_NB7JcjbU0XblJcaf7kVLD75dOYRQ

## Highlights
- If humanity is to solve challenges like climate change and public goods infrastructure, we must come up with methods of managing shared resources with significantly lower risk of capture
- Blockchains and smart contracts have revealed a new trust model for governance over shared resources that relies instead on a combination of cryptography and wide distribution of power. This model makes possible a new category of governance, called capture-resistant governance
- This article introduces Anticapture, a framework for understanding capture-resistant governance. Anticapture seeks to understand the fundamentals of capture-resistant governance by examining how organizations – modeled as networks of agents – take actions to manage resources in service of their objectives
- Agents are individual entities that have the ability to take actions. Agents can be individual humans, software acting on behalf of an individual or group (e.g., an Ethereum client), or a group of multiple agents
- Anticapture models any group, community, or organization of agents as a network
- When a resource is under the power of a single agent, we consider it a private resource
- When a resource is under the power of a network of agents, we consider it a shared resource
- Some resources can only be shared. Power over such resources is distributed and cannot be privatized. We call these distributed resources
- Anticapture framework treats resources as recursive concepts
- All governance over shared resources is conducted via actions
- In the Anticapture framework, actions have four phases. Propose: delineate the options on the table Decide: select the preferred option Execute: put the selected option into action Evaluate: analyze the impact of the executed action
- fundamental power is power over a resource itself, while soft power is the ability to influence those with fundamental power
- Participation in the Decide phase spans from centralized to decentralized, describing the proportion of agents in the network having a voice in the decision-making process.
- Participation in the Propose phase within a network spans from centralized to decentralized, describing how widely distributed the power to add options to the network’s agenda is.
- Participation in this phase spans from centralized to decentralized, describing the proportion of agents in the network sharing the power to execute actions selected in the Decide phase.
- Separation between decision-making and executive power is uniquely possible within capture-resistant structures.
- Due to its property of changing the state of the world, Execution has a second dimension. This occurs on a spectrum from dependent to autonomous, describing the extent to which execution can be stopped, altered, or otherwise interfered with by an external agent
- Participation in the Evaluate phase spans from centralized to decentralized. The degree of decentralization is often determined by the transparency of the network’s operations. If the network is organized on a public blockchain and communicates in public, even external agents can participate in evaluating its actions.
- With the Anticapture framework in hand, we can conceptualize DAOs as a strong form of capture-resistant governance.
- DAOs are networks of agents, they manage shared resources, and they have a purpose
- A DAO is a network of agents who share common purpose, and are the only ones who hold the power to execute actions that manage a set of shared resources.
- Conflating decentralization with permissionlessness is one of the most common mistakes in the DAO space.
