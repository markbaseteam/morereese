# Web Architecture 101

![rw-book-cover](https://readwise-assets.s3.amazonaws.com/static/images/article1.be68295a7e40.png)

## Metadata
- Author: [[Jonathan Fulton]]
- Full Title: Web Architecture 101
- Category: #articles
- URL: https://medium.com/p/a3224e126947

## Highlights
- you can think of DNS as the phone book for the internet.
