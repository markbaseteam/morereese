# Of Digital Streams, Campfires and Gardens

![rw-book-cover](https://tomcritchlow.com/images/green.png)

## Metadata
- Author: [[TOM CRITCHLOW]]
- Full Title: Of Digital Streams, Campfires and Gardens
- Category: #articles
- URL: https://tomcritchlow.com/2018/10/10/of-gardens-and-wikis/

## Highlights
- Loosely speaking - streams are for fast twitch thinking and acting. Participating in the stream is a fast feedback loop, with a slightly longer undercurrent of connection building. ([View Highlight](https://read.readwise.io/read/01grz9sqyh4d7f8tyytkc9vs11))
    - Tags: [[digital-gardening]] 
- > The Garden is the web as topology. The web as space. It’s the integrative web, the iterative web, the web as an arrangement and rearrangement of things to one another.
  > Things in the Garden don’t collapse to a single set of relations or canonical sequence, and that’s part of what we mean when we say “the web as topology” or the “web as space”. Every walk through the garden creates new paths, new meanings, and when we add things to the garden we add them in a way that allows many future, unpredicted relationships ([View Highlight](https://read.readwise.io/read/01grz9vdgj5jdpxwhhnh289n09))
    - Tags: [[digital-gardening]] [[mike-caufield]] 
