# When Do You Need Blockchain? Decision Models.

![rw-book-cover](https://readwise-assets.s3.amazonaws.com/static/images/article4.6bc1851654a0.png)

## Metadata
- Author: [[Sebastien Meunier]]
- Full Title: When Do You Need Blockchain? Decision Models.
- Category: #articles
- URL: https://medium.com/p/a5c40e7c9ba1

## Highlights
- The reason why so many sophisticated models got it wrong is because they assumed blockchain was a technology, when in fact it’s not a technology but a design pattern:
- Blockchain, or Distributed Ledger, means “not controlled by a single or small group of entities”
