# Why You Should Care About the Philosophy Behind DAOs

![rw-book-cover](https://readwise-assets.s3.amazonaws.com/static/images/article1.be68295a7e40.png)

## Metadata
- Author: [[Bobby Bola]]
- Full Title: Why You Should Care About the Philosophy Behind DAOs
- Category: #articles
- URL: https://medium.com/p/6096bc74acaf

## Highlights
- Moral philosophy is a branch of philosophy that contemplates the difference between right and wrong
- DAO-ntology (yes, I will coin this term) stems from the moral philosophy of deontology, which says actions are bad or good according to a clear set of rules, rather than judging the action based on the outcome.
- Even though we wish for DAOs to be built on social reputation, it will take a while for governance mechanisms to truly allow this to happen.
