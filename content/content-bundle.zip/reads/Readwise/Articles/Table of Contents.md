# Table of Contents

![rw-book-cover](https://readwise-assets.s3.amazonaws.com/static/images/article0.00998d930354.png)

## Metadata
- Author: [[foambubble.github.io]]
- Full Title: Table of Contents
- Category: #articles
- URL: https://foambubble.github.io/foam/

## Highlights
- **Foam** is a personal knowledge management and sharing system inspired by [Roam Research](https://roamresearch.com/), built on [Visual Studio Code](https://code.visualstudio.com/) and [GitHub](https://github.com/). ([View Highlight](https://read.readwise.io/read/01gs33m9rj7nsjvrjkywagqran))
    - Tags: [[knowledge-management]] [[digital-gardening]] [[tools]] 
