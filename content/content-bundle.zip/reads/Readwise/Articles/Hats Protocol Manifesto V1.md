# Hats Protocol Manifesto V1

![rw-book-cover](https://readwise-assets.s3.amazonaws.com/static/images/article3.5c705a01b476.png)

## Metadata
- Author: [[Arweave Transaction]]
- Full Title: Hats Protocol Manifesto V1
- Category: #articles
- URL: https://hats.mirror.xyz/7kumvVAJDw0DIc8Mt9MA3rBLn_z44mXn4nYx9caUMJM

## Highlights
- We envision a future where coordinating is less costly than competing; where we are able to work together effectively to address the complex issues of our time; and where everyone is able to contribute to their fullest ability while sharing in the governance over and upside of collective endeavors.
- We believe that DAOs can get things done at scale without resorting to the hierarchical power structures of traditional organizations.
- We are dreamers. We seek to help humanity transition to the post-scarcity economy that facilitates a safe, fair, and healthy world for all.
    - Tags: [[broadcast2hightlights]] [[hats]] 
- We know the power of collective action and collective intelligence.
- We uphold that DAOs are the most capture-resistant form of governance to-date,
- We believe that sovereignty and autonomy are foundational to the future we want to live in. We see this as a precondition to self-actualization, fulfillment, and thriving for individuals, and also as a prerequisite for a sustainable collective.
- We believe in a future that is fun. We live into joy and play in all aspects of our life, including our work.
- At Hats, we see that DAOs are changing the world.
