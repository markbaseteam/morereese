# What Are Full Archive Nodes?

![rw-book-cover](https://readwise-assets.s3.amazonaws.com/static/images/article2.74d541386bbf.png)

## Metadata
- Author: [[Speedy Nodes]]
- Full Title: What Are Full Archive Nodes?
- Category: #articles
- URL: https://moralis.io/what-are-full-archive-nodes/

## Highlights
- full archive nodes contain everything that can be found in a full node, along with the history of the relevant blockchain. These nodes are, therefore, essentially nodes that include all previous states of a given blockchain. This means that they contain a snapshot of the blockchain’s ecosystem, at each block since its origin.
- we can use an archive node to examine past states of the chain and use this historical information when developing applications. Furthermore, one of the greatest benefits of a full archive node is that we are able to query information at great speed, something that is great for development
- the most prominent characteristic of an archive node is that it contains the historical data of a chain. This means that the use cases for these nodes are those where we need access to past states of a chain in a fast manner.
