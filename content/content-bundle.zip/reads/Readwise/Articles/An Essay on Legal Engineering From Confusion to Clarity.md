# An Essay on Legal Engineering: From Confusion to Clarity

![rw-book-cover](https://readwise-assets.s3.amazonaws.com/static/images/article4.6bc1851654a0.png)

## Metadata
- Author: [[Esen Esener]]
- Full Title: An Essay on Legal Engineering: From Confusion to Clarity
- Category: #articles
- URL: https://medium.com/p/908c8e731df7

## Highlights
- it would be wrong to say that blockchain and legal tech are two different worlds. I believe blockchain itself is a legal technology.
- Susskind’s definition of legal engineering, “developing legal standards and procedures, and organizing and representing legal knowledge in computer systems”
