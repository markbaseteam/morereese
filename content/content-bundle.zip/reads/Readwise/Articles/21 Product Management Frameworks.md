# 21 Product Management Frameworks

![rw-book-cover](https://readwise-assets.s3.amazonaws.com/static/images/article4.6bc1851654a0.png)

## Metadata
- Author: [[admin]]
- Full Title: 21 Product Management Frameworks
- Category: #articles
- Document Tags: [[product]] 
- URL: https://productfolio.com/21-product-management-frameworks/

## Highlights
- product managers must be methodical in their approach
- Minimal Viable Product (MVP)
- Working Backwards
- Northstar Framework
- Business Model Canvas
- JTBD, this framework for focuses on identifying customers’ needs, based on scenarios rather than personas.
- Jobs To Be Done
- Opportunity Solution Tree
- Weighted Impact Scoring
- RICE Prioritization
- Design Thinking
- Customer Journey Map
- Kano Model
- Spotify Squads
- GIST Planning
- GIST Planning
- 3 Pillars of Product Management
- d
- DACI framework
- Product Team Competencies
- Product Team Competencies
- Product Team Competencies.
- Circles Method
- Circles Method.
- Circles Method.
- Circles Method
- Circles Method.
- Innovation Adoption Curve.
