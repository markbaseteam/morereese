# Chapter 1: The Big Cycles in a Tiny Nutshell

![rw-book-cover](https://readwise-assets.s3.amazonaws.com/static/images/article3.5c705a01b476.png)

## Metadata
- Author: [[linkedin.com]]
- Full Title: Chapter 1: The Big Cycles in a Tiny Nutshell
- Category: #articles
- Document Tags: [[>unread]] 
- URL: https://www.linkedin.com/pulse/chapter-1-big-picture-tiny-nutshell-ray-dalio

## Highlights
- the last three reserve currency empires (the Dutch, the British, and the American)
- throughout time and in all countries, the people who have the wealth are the people who own the means of wealth production. In order to maintain or increa
- I believe that we are now seeing an archetypical big shift in relative wealth and power and the world order that will affect everyone in all countries in profound ways.
- I have identified 18 important determinants that have explained almost all of the basic ebbs and flows through time that have caused ups and downs in empires.
- The most important three cycles are the ones I mentioned in the intro- duction: the long-term debt and capital markets cycle, the internal order and disorder cycle, and the external order and disorder cycle.
- Evolution is a relatively smooth and steady improvement because the gaining of knowledge is greater than the losing of knowledge. Cycles on the other hand move back and forth, producing excesses in one direction that lead to reversals and excesses in the other, like the swinging of a pendulum.
- Briefly, a credit collapse happens because there is too much debt. Typically, the central government has to spend a lot of money it doesn’t have and make it easier for debtors to pay their debts and the central bank always has to print money and liberally provide credit
- Principles for Navigating Big Debt Crises,
- Throughout History Wealth Was Gained by Either Making It, Taking It from Others, or Finding It in the Ground
- Most Everything Evolves in an Uptrend with Cycles Around It
- the formula for success has been a system in which educated people come up with innovations, receive funding through capital markets, and own the means by which their innovations are turned into the production and allocation of resources, allowing them to be rewarded by profit-making.
- Almost all debt busts, including the one we are now in, come about for basically the same reason of extrapolating the uptrend forward and over-borrowing to bet heavily on things going up and being hurt when they go down.
- In the 1930s US case, the stock market and the economy bottomed the day that newly elected President Roosevelt announced that he would default on the government’s promise to let people turn in their money for gold, and that the government would create enough money and credit so that people could get their money out of banks and others could get money and credit to buy things and invest
- Still, history has shown us that typically the majority of people stay employed in the depressions, are unharmed in the shooting wars, and survive the natural disasters.
