# The Role of Product Management

![rw-book-cover](https://readwise-assets.s3.amazonaws.com/static/images/article0.00998d930354.png)

## Metadata
- Author: [[Neal Cabage]]
- Full Title: The Role of Product Management
- Category: #articles
- Document Tags: [[product]] 
- URL: http://nealcabage.com/product-management/

## Highlights
- I define a Product as a solution offered to a market, to enable or make efficient a specific customer need or desire
- if you go back to the 1930s, Product Management began in the Brand Marketing department of Proctor & Gamble, as a way to vertically scale the Brand Marketing department, allowing individual “brand men” as they were called, to go deep and truly own every aspect of a product, from understanding their market, to production, and taking that product to market
- This new approach has its pros and cons but one notable change is that this shifted the person playing the product role from being a strategic Product Manager primarily looking at product-market fit, to a more tactical role that defines, supports, and clarifies requirements on a real-time basis.
- Because Product Management is a strategic and business-facing role, success should be measured in terms of driving a strategic outcome.
- Product Management is ideally situated as a standalone function, parallel to Marketing, Engineering, and Finance, that equally supports the Business strategy
- Organizations who are known for their products rather than their service or arbitrage (buy/sell) activities, naturally place Product Management at the tip of the proverbial strategic spear
- Product Management is fundamentally about understanding the needs and desires of the customer segment you’re serving, figuring out the right product to build to optimally address those needs, and working with a cross-functional team to continually build and refine that product, to ensure it is maximally successful in the market.
- Product Management is best positioned to create value, when the focus is placed upon driving an outcome, rather than merely delivering an output.
