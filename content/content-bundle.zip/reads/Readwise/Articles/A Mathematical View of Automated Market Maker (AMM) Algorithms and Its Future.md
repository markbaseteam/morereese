# A Mathematical View of Automated Market Maker (AMM) Algorithms and Its Future

![rw-book-cover](https://readwise-assets.s3.amazonaws.com/static/images/article3.5c705a01b476.png)

## Metadata
- Author: [[Leo Liu]]
- Full Title: A Mathematical View of Automated Market Maker (AMM) Algorithms and Its Future
- Category: #articles
- Document Tags: [[Favorites]] 
- URL: https://medium.com/anchordao-lab/automated-market-maker-amm-algorithms-and-its-future-f2d5e6cc624a

## Highlights
- Bonding curve is the relation between the price of a token and its total supply.
- liquidity. If the transaction fee does not fully compensate impermanent loss, Bancor will mint BNT to make sure impermanent loss is zero. As a result, liquidity providers can enjoy a stable income if they have deposited liquidity for a certain time (100 days to be fully compensated).
- Bancor protocol also compensates impermanent loss (will be discussed later) in the form of transaction fee earned on the BNT part when users deposit single-sided liquidity.
- merges
- Curve merges Constant Sum Market Maker (CSMM) and Constant Product Market Maker (CPMM) together to achieve lower price slippage
- Clipper¹³ uses an AMM algorithm that best suits the need of small trades
- Time Weighted Automated Market Maker, pronounced as “tee-wham
- DEX aggregators are protocols that aggregates existing AMM protocols to achieve better swap result
- Curve merges Constant Sum Market Maker (CSMM) and Constant Product Market Maker (CPMM) together to achieve lower price slippage.
- Uniswap V2 and V3 introduce CPMM and liquidity distribution in their AMM algorithms. Providing liquidity in price ranges essentially enables Uniswap V3 to be a universal AMM, with the ability to become any possible AMM by changing its liquidity distribution.
- Uniswap V3 introduces the concept of liquidity distribution, by allowing its users to deposit liquidity in price ranges
- By adding CSMM and CPMM together with dynamic weight, Curve’s StableSwap achieves very small slippage, ideal for stablecoins.
- Balancer also introduces the Smart Order Router (SOR⁹) algorithm
- Balancer also introduces the Smart Order Router (SOR⁹) algorithm.
- Balancer generalizes 2-token pools to multi-token pools, and introduces the SOR algorithm to achieve better prices for its users.
- DEX aggregators are protocols that aggregates existing AMM protocols to achieve better swap results.
- Balancer is a multi-token portfolio management tool that allows flexible token value distributions, with a price optimization algorithm.
- Time Weighted Automated Market Maker, pronounced as “tee-wham
- Curve merges Constant Sum Market Maker (CSMM) and Constant Product Market Maker (CPMM) together to achieve lower price slippage.
- merges Constant Sum Market Maker (CSMM) and Constant Product Market Maker (CPMM) together to achieve lower price slippage.
- Impermanent loss is defined as the difference in value between the current value of liquidity provider’s tokens in the pool after trading and the current value of liquidity provider’s tokens if he simply holds onto his tokens and does not use them for liquidity provision
- Curve
- Curve’s StableSwap and dynamic peg V2 are here to make the trading slippage as small as possible. StableSwap always pegs at 1 while V2 makes the pegs follow the market price.
- Curve merges Constant Sum Market Maker (CSMM) and Constant Product Market Maker (CPMM) together to achieve lower price slippage.
- DEX aggregators are protocols that aggregates existing AMM protocols to achieve better swap
- Bancor introduces the idea of network token BNT which is connected to all tokens with different connect weights, corresponding to different price-determining bonding curves.
- Curve merges
- DEX aggregators are protocols that aggregates existing AMM protocols to achieve better swap results.
- the core of AMM algorithms is basically about the design of market maker functions and manipulation of their curvature distributions
- the core of AMM algorithms is basically about the design of market maker functions and manipulation of their curvature distributions
- To summarize, the core of AMM algorithms is basically about the design of market maker functions and manipulation of their curvature distributions
