# Solana Summer

![rw-book-cover](https://readwise-assets.s3.amazonaws.com/static/images/article0.00998d930354.png)

## Metadata
- Author: [[Packy McCormick]]
- Full Title: Solana Summer
- Category: #articles
- Document Tags: [[packy-mccormick]] [[solana]] [[solana-ecosystem]] 
- URL: https://www.notboring.co/p/solana-summer

## Highlights
- Ultimately, Solana’s success or failure comes down to two questions…
- Can Solana convince developers to build on Solana? Can those developers attract users to their product?
- in the long-term, it all comes down to attracting developers who attract customers
- Solana’s goal is “for a decentralized network of nodes to match the performance of a single node”
- Vitalik Buterin wrote, “The scalability trilemma says that there are three properties that a blockchain try to have (scalability, security, and decentralization), and that, if you stick to ‘simple’ techniques, you can only get two of those three.”
- There’s game theory at play here: the amount of tokens each validator has at stake is greater than what they should be able to steal by misbehaving.
- Solana uses PoS, specifically “Bonded Proof-of-Stake” (BPoS)
- Utilizing Proof of History creates a historical record that proves that an event has occurred at a specific moment in time. Whereas other blockchains require validators to talk to one another in order to agree that time has passed, each Solana validator maintains its own clock by encoding the passage of time in a simple SHA-256, sequential-hashing verifiable delay function (VDF)
- Because PoH enables predictability -- there won’t be delays waiting for other validators -- validators can take turns in a pre-scheduled “leader rotation.”
- Proof of History is one of the “8 innovations that make Solana the first web-scale blockchain,” all eight of which are: Proof of History (POH)— a clock before consensus; Tower BFT — a PoH-optimized version of PBFT; Turbine — a block propagation protocol; Gulf Stream— Mempool-less transaction forwarding protocol; Sealevel — Parallel smart contracts run-time; Pipelining — a Transaction Processing Unit for validation optimization Cloudbreak— Horizontally-Scaled Accounts Database; and Archivers — Distributed ledger storage
- The generally-accepted way to measure decentralization is what Balaji Srinivasan coined the “Nakamoto Coefficient.”
- “we define the Nakamoto coefficient as the minimum number of entities in a given subsystem required to get to 51% of the total capacity.”
- for PoS blockchains, you only need 33% to halt the network
- Solana has a higher Nakamoto coefficient than Ethereum or Bitcoin
- The reason is that while there are a larger number of Bitcoin and Ethereum miners than Solana validators, those miners operate in “pools” that behave as one, and often run software managed by the pool. As blocks get harder to mine, miners are more likely to pool resources. Bitcoin’s current Nakamoto Coefficient is somewhere around 4. Ethereum’s is 3 or 4. Solana’s is 19
