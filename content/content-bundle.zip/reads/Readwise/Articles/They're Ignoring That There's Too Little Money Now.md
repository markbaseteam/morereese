# They're Ignoring That There's Too Little Money Now

![rw-book-cover](https://readwise-assets.s3.amazonaws.com/static/images/article1.be68295a7e40.png)

## Metadata
- Author: [[Jeffrey Snider]]
- Full Title: They're Ignoring That There's Too Little Money Now
- Category: #articles
- URL: https://www.realclearmarkets.com/articles/2021/09/17/theyre_ignoring_that_theres_too_little_money_now_794895.html

## Highlights
- Keynes wrote in his General Theory: “At periods when gold is available at suitable depths experience shows that the real wealth of the world increases rapidly; and when but little of it is so available our wealth suffers stagnation or decline.”
- As Keynes had written more than a decade before, in the early twenties, the greatest monetary evil is this: the shortage of money and its deflation which quite vigorously savages labor most of all.
    - Tags: [[macroeconomics]] [[keynes]] 
