# Issue #46: Owning the Infrastructure

![rw-book-cover](https://readwise-assets.s3.amazonaws.com/static/images/article0.00998d930354.png)

## Metadata
- Author: [[Andrew Beal]]
- Full Title: Issue #46: Owning the Infrastructure
- Category: #articles
- URL: https://30000feet.substack.com/p/issue-46-owning-the-infrastructure

## Highlights
- the fact that blockchains and DeFi protocols are public infrastructure means ownership is up for grabs
