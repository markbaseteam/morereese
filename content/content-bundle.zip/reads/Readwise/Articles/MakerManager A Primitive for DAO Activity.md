# Maker<>Manager: A Primitive for DAO Activity

![rw-book-cover](https://miro.medium.com/max/1200/1*EeHwkKr_pZP2H5HfciJkIw.png)

## Metadata
- Author: [[moreReese]]
- Full Title: Maker<>Manager: A Primitive for DAO Activity
- Category: #articles
- URL: https://blog.tally.xyz/maker-manager-a-primitive-for-dao-activity-9a55014014cc

## Highlights
- Makers and Managers: An introduction
  An organization’s survival can be distilled into two activities: maintaining the organization and evolving the organization. *Managing* organizational activities is mostly associated with maintenance while *making* activities are mostly associated with evolution. Organizations live and die by the value it delivers so it’s vi ([View Highlight](https://read.readwise.io/read/01graszxhpj50we9gfcxfesqzf))
