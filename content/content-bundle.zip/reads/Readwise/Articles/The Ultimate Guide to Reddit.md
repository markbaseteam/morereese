# The Ultimate Guide to Reddit

![rw-book-cover](https://readwise-assets.s3.amazonaws.com/static/images/article4.6bc1851654a0.png)

## Metadata
- Author: [[Greg Isenberg]]
- Full Title: The Ultimate Guide to Reddit
- Category: #articles
- URL: https://latecheckout.studio/articles/the-ultimate-guide-to-reddit

## Highlights
- unbundling opportunities
- pro-tip: some of the best posts have lots of comments but not a lot of upvotes
- The subreddit format has low bandwidth for communication. Interactions are almost never real-time and rarely one-on-one.
