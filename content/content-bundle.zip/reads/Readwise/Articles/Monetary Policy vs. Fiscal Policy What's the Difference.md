# Monetary Policy vs. Fiscal Policy: What's the Difference?

![rw-book-cover](https://readwise-assets.s3.amazonaws.com/static/images/article2.74d541386bbf.png)

## Metadata
- Author: [[Troy Segal]]
- Full Title: Monetary Policy vs. Fiscal Policy: What's the Difference?
- Category: #articles
- URL: https://www.investopedia.com/ask/answers/100314/whats-difference-between-monetary-policy-and-fiscal-policy.asp

## Highlights
- Monetary policy is primarily concerned with the management of interest rates and the total supply of money in circulation and is generally carried out by central banks, such as the U.S. Federal Reserve.
- Fiscal policy is a collective term for the taxing and spending actions of governments. In the United States, the national fiscal policy is determined by the executive and legislative branches of the government.
