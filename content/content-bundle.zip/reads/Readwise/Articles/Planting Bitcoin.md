# Planting Bitcoin

![rw-book-cover](https://readwise-assets.s3.amazonaws.com/static/images/article0.00998d930354.png)

## Metadata
- Author: [[Dan Held]]
- Full Title: Planting Bitcoin
- Category: #articles
- Document Tags: [[bitcoin]] [[educational]] [[long-read]] 
- URL: https://medium.com/@danhedl/planting-bitcoin-56bd1459cb23

## Highlights
- We can think of Bitcoin’s genetic code as representing instructions that have been written to incentivize the organization and coordination of cellular function.
- the Lindy effect suggests that the longer Bitcoin remains in existence the greater society’s confidence that it will continue to exist long into the future
- According to a study of 775 fiat currencies by DollarDaze.org the average life expectancy of a fiat currency is 27 years.
- “In the absence of the gold standard, there is no way to protect savings from confiscation through inflation. There is no safe store of value.” — Alan Greenspan(Former Chairman of the Federal Reserve)
- ideally we want to be able to state with certainty that at some point the payment has been made, the debt has been cleared, and the funds are secure.
- Importantly, Satoshi didn’t premine any Bitcoins. Satoshi gave the Cypherpunks a two month heads up before mining the Genesis block. To prove fairness, he included a proof of no premine timestamp in the Genesis Block of the Bitcoin blockchain.
- As a subtle jab to central banks, and as a nod to his admiration of the gold standard, he chose his birthday (on his p2p foundation website profile) as the date the US made gold ownership illegal through Executive Order 6102, April 5th. And he chose 1975 as his year of birth which is the year when the US citizens were allowed to own gold again.
    - Tags: [[satoshi]] 
- Bitcoin was specially architected to be trust minimized. Satoshi set it up so that there is no one person or group whose power can be coveted, usurped, or broken.
- “Protocols die when they run out of believers.” — Naval
- Money is a winner-take-all technology, driven by network effects. The crypto with the most HODLers, therefore, is the most demanded by consumers and will be the ultimate winner.
