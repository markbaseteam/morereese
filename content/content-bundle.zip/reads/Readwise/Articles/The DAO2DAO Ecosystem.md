# The DAO2DAO Ecosystem

![rw-book-cover](https://miro.medium.com/max/1200/1*f-PBzuMog0Af-H4O-bkJmQ.png)

## Metadata
- Author: [[Emma Kwan]]
- Full Title: The DAO2DAO Ecosystem
- Category: #articles
- URL: https://medium.com/m/global-identity-2?redirectUrl=https://blog.tally.xyz/the-dao2dao-ecosystem-71b1cba5177d?utm_medium=email&utm_source=substack

## Highlights
- There’s the ‘mature and advanced DAO’, represented by the [10% of DAOs who are responsible for 65% of total proposals](https://twitter.com/n4motto/status/1534642577160523779). ([View Highlight](https://read.readwise.io/read/01gs32409nj2n515xs0qe9r3ay))
    - Tags: [[dao]] [[governance]] 
