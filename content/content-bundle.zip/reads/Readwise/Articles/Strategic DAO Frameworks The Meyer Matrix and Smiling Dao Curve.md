# Strategic DAO Frameworks: The Meyer Matrix and Smiling Dao Curve

![rw-book-cover](https://readwise-assets.s3.amazonaws.com/static/images/article3.5c705a01b476.png)

## Metadata
- Author: [[ed3.mirror.xyz]]
- Full Title: Strategic DAO Frameworks: The Meyer Matrix and Smiling Dao Curve
- Category: #articles
- Document Tags: [[dao]] [[framework]] [[scribe-dao-queue]] [[shiny-dao]] 
- URL: https://ed3.mirror.xyz/-ko2xt89AlznNaEtnwE5WvyOnsMdetFc33H8WtslMNo

## Highlights
- the twoplus blog notes
- Good design of DAO tools should start with our brains and body cycles in mind
- Good design of DAO environments and cultures should start with our deepest psychological needs at the core
- People are DAOs first and last differentiator
- People are the most important element of a DAO
- The k20 DAO
- The Meyer Matrix highlights opportunities in the DAO landscape
- We can label these four quadrants based on their characteristics: DAOs with niche audiences and niche topics are subject matter experts DAOs with a broad audience and niche topics are subject matter aggregators DAOs with a niche audience and broad topics are industry matter experts DAOs with a broad audience and broad topics are industry matter aggregators
- experience from other industries show that the greatest value will accrue towards subject matter experts and industry matter aggregators. This is known as the Smiling DAO Curve.
- value accrues to the edges. This is what is known as The Smiling Curve
- The Smiling Curve was coined by Acer founder Stan Shih to explain where the profits were in technological manufacturing
- Subject matter expert (SME) DAOs will attract the expert members who want to work with the best and become masters at their craft.
- DAOs that are industry aggregators (IA) will reduce the friction for members to get what they want
- These IA DAOs are the content discovery platforms on the right end of the smiling curve
- Over time, then, DAOs will be pulled towards these two poles.
- DAOs are much more fluid than a traditional business. This advantage could help them straddle the matrix and ride the smiling curve, acting as both an aggregator and expert with the right strategy
- If the goal is to become an aggregator or an expert, DAOs can get there in three different ways
- 1. Seasonal Focus
- 2. SubDAOs
- 3. DAO Partnerships
