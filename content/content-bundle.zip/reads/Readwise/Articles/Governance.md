# Governance

![rw-book-cover](https://daocollective.xyz/wp-content/uploads/2022/10/TT-Post-Governance.png)

## Metadata
- Author: [[DAO Research Collective]]
- Full Title: Governance
- Category: #articles
- URL: https://daocollective.xyz/governance/?utm_source=substack&utm_medium=email

## Highlights
- The term *governance*, like *government*, originally stems from the [Greek verb *kubernaein*](https://ethical.net/glossary/what-is-governance/) *[kubernáo]*, meaning to steer. ([View Highlight](https://read.readwise.io/read/01gs32b0f2be8szxeh0nfanqnm))
    - Tags: [[governance]] [[etymology]] 
- Governance refers to the decision-making activities and processes, formal or informal, carried out by organizations including states, corporations, non-profits, partnerships and unincorporated associations. Each of these types of organizations share the need to establish decision rights, specifically: what decisions need to be made, who is responsible for making decisions, who will be held accountable for the impact of decisions, and how decisions are communicated to relevant stakeholders. ([View Highlight](https://read.readwise.io/read/01gs32cy9m2acrvyc6x3qbj05x))
    - Tags: [[definition-of]] [[governance]] 
- [The three types of decentralization](https://thedefiant.io/decentralization-upends-governance), aptly described by a16z’s Miles Jennings in his piece titled [*Principles and Models of Web3 Decentralization*](https://a16z.com/wp-content/uploads/2022/04/principles-and-models-of-decentralization_miles-jennings_a16zcrypto.pdf) – namely (1) Technical, (2) Economic, and (3) Legal Decentralization – must all be considered when deciding on an appropriate governance system ([View Highlight](https://read.readwise.io/read/01gs32ftv4191d9x8gx23qmb01))
    - Tags: [[governance]] [[types-of]] 
- Although economically efficient and common practice, off-chain governance ultimately acts as a hindrance to the benefits of blockchain. An inescapable reality of off-chain governance is that it requires a trusted third party to accurately record and/or execute on community decisions which take place without an on-chain vote. An acute deficiency in these systems are situations in which token holders signal their views and preferences on proposals using tools like Snapshot, but the decision is ultimately executed through the multi-sig wallet (which requires multiple signatures to execute a transaction on the blockchain) by a small committee or group of people who, to some degree or another, utilize their own judgment when making changes to the the DAO. ([View Highlight](https://read.readwise.io/read/01gs32zmress40vn4pcnkhrdqs))
    - Tags: [[governance]] [[off-chain-governance]] 
- Whether a DAO succeeds in decentralizing its governance structure is often a function of its voting system, and the willingness of the original development team to relinquish power through this instrument. ([View Highlight](https://read.readwise.io/read/01gs331cjc5e8ypsttgdpa9fhp))
    - Tags: [[exit-to-community]] [[governance]] [[voting]] 
- Quorum-based token voting was one of the first systems to be adopted by DAOs, primarily because it is easy to understand and simple to execute. The only prerequisite to pass a proposal is that a minimum threshold (or quorum) of token holders participate in voting. Once this quorum has been met, the proposal is accepted or rejected based on the recorded results of the token holder voting process. ([View Highlight](https://read.readwise.io/read/01gs332pm7g5bzw04h0av9exrs))
    - Tags: [[governance]] [[quorum-based-voting]] 
- Ranked Choice Voting
  Also known as the ‘first-past-the-post’ system in traditional political voting, each voter can choose from the different choices available to them. If one of the choices receives more than half of the votes, that choice wins. If not, the least preferred choice is eliminated, and another round of voting takes place. This process goes on for multiple rounds until a choice has received more than half the votes. ([View Highlight](https://read.readwise.io/read/01gs335pasf51aa1k5sj0gr9r8))
    - Tags: [[definition-of]] [[rank-based-voting]] 
- conviction voting. Under this method, voters are allowed to change their vote at any point before the predetermined time limit but the impact of a token holder’s vote increases with the time that it remains unchanged. ([View Highlight](https://read.readwise.io/read/01gs338weje6rnxae37y17en82))
    - Tags: [[conviction-voting]] [[governance]] 
- Delegated Voting
  This refers to token holders delegating their votes to a representative of their choice, who they believe might be well-equipped to make decisions on their behalf. ([View Highlight](https://read.readwise.io/read/01gs33a46dw7ghk8apdmxhb2n1))
    - Tags: [[governance]] [[delegated-voting]] 
- [Reputation-weighted voting](https://medium.com/@orangeprotocol/why-portable-reputation-is-the-next-superpower-for-daos-and-web3-f46a53f80e6a) has emerged as a potential solution where the power of each vote is linked to the token holder’s ‘reputation’.
  Token holders can earn reputation in various ways, including membership history and past contributions to the DAO. ([View Highlight](https://read.readwise.io/read/01gs33c70w29xe454gf3yhrshj))
    - Tags: [[reputation-weighted-voting]] [[governance]] 
- The [holographic consensus voting](https://www.semanticscholar.org/paper/A-Scalable-Voting-System%3A-Validation-of-Holographic-Faqir-Arroyo/91b72f1b6517ea404527ab3ac99dc82716341068) method acts as a screening mechanism to ensure that a DAO community prioritizes important governance decisions, such as those relating to the security or resiliency of the DAO. This is done by creating a prediction market for governance proposals on the DAO. The predictors can wager tokens on the proposals they believe will succeed. If the forecast is accurate, the predictor earns tokens as a reward. If not, they lose those tokens. ([View Highlight](https://read.readwise.io/read/01gs33ffnmr6jvmk9er6f10ymx))
    - Tags: [[definition-of]] [[governance]] [[holographic-consensus-voting]] 
