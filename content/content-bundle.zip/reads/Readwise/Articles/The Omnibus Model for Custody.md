# The Omnibus Model for Custody

![rw-book-cover](https://readwise-assets.s3.amazonaws.com/static/images/article1.be68295a7e40.png)

## Metadata
- Author: [[Ria Bhutoria]]
- Full Title: The Omnibus Model for Custody
- Category: #articles
- Document Tags: [[fidelity]] [[omnibus]] 
- URL: https://www.fidelitydigitalassets.com/articles/the-omnibus-model-for-custody

## Highlights
- We describe the origins of the omnibus custody model in traditional finance and explore how and why digital asset custodians apply the omnibus model to securing customer assets.
- Key management determines how digital assets like bitcoin are held and secured. The two most prominent models are omnibus1 and segregated.
- A custodian that uses the omnibus model combines clients’ assets and spreads the assets across multiple digital asset private and public key pair groups. The custodian establishes client by client segregation at the books and records level.
- the “Paperwork Crisis” of the 1960s
- The assets deposited by DTC participants are held in the name of the DTC nominee, Cede & Co., in the records of the security issuer. Therefore, Cede & Co. essentially owns all publicly listed stock in the U.S. while investors hold contractual rights as part of a chain of contractual rights involving Cede.
- The onus on digital asset custodians to implement robust storage processes is heightened as digital assets are bearer instruments (like hard cash) — they cannot be recovered if lost or stolen.
- The onus on digital asset custodians to implement robust storage processes is heightened as digital assets are bearer instruments (like hard cash) — they cannot be recovered if lost or stolen
- Custodians employing the omnibus model may use the hierarchical deterministic (HD) protocol to generate key pairs17 and addresses that are maintained by the custodian in its name. The HD protocol was introduced in BIP3218 to simplify the process of generating, backing up and organizing private and public key pairs in a tree-like structure.19
- Under the HD structure, master private keys and master public keys are used to generate a near infinite number of child keys that can generate their own child keys (see Figure 1). A master private key can generate child private and public keys. A master public key can only generate child public keys (and corresponding addresses).
- In order to generate a new master key pair, custodians likely conduct a key ceremony. Key ceremonies are highly orchestrated processes that involve multiple stakeholders. Key ceremony preparations could begin months in advance. Internal and independent external auditors may serve as witnesses during the ceremony to ensure a custodian follows a secure, tamper-proof, rules-based process for generating master key pairs that will be used to store client funds.
- In order to generate a new master key pair, custodians likely conduct a key ceremony. Key ceremonies are highly orchestrated processes that involve multiple stakeholders. Key ceremony preparations could begin months in advance. Internal and independent external auditors may serve as witnesses during the ceremony to ensure a custodian follows a secure, tamper-proof, rules-based process for generating master key pairs that will be used to store client funds.
- Once a client is onboarded and transfers assets to the custodian, the custodian is at liberty to move the assets around within and between key pairs and across storage environments to maintain their ratio of total assets in online (hot) and offline (cold) storage20 or to limit the portion of funds within a key pair and/or address.
- The custodian establishes segregation at the books and records level on its systems to track assets held by each client
- By using an omnibus structure, custodians can control the number of key pairings they manage. The custodian can also establish a threshold of funds stored within each pairing.
- Proof of solvency, or a cryptographic audit, has been discussed as a way to build trust and hold third-party service providers that manage customer funds accountable. A proof of solvency consists of comparing a proof of reserve (funds controlled by a third party) to a proof of liability (funds owed by a third party).
- Clients evaluating digital asset custodians should investigate the extent to which a custody solution is “omnibus” or “segregated” to get an accurate idea of the advantages and shortcomings of the respective structures.
