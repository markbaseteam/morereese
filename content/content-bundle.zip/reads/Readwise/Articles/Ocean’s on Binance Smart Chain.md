# Ocean’s on Binance Smart Chain

![rw-book-cover](https://readwise-assets.s3.amazonaws.com/static/images/article4.6bc1851654a0.png)

## Metadata
- Author: [[Ocean Protocol Team]]
- Full Title: Ocean’s on Binance Smart Chain
- Category: #articles
- URL: https://blog.oceanprotocol.com/oceans-on-binance-smart-chain-6bfe715a492c

## Highlights
- BSC is EVM-compatible, which allows it to run Ethereum smart contracts and use Ethereum-style tokens. It’s a Proof-of-Authority (federated) chain with a small number of nodes, which allows it to have low gas fees and low latency compared to Ethereum mainnet.
