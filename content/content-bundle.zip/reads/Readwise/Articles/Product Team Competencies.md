# Product Team Competencies

![rw-book-cover](https://readwise-assets.s3.amazonaws.com/static/images/article4.6bc1851654a0.png)

## Metadata
- Author: [[Neal Cabage]]
- Full Title: Product Team Competencies
- Category: #articles
- Document Tags: [[product]] 
- URL: http://nealcabage.com/framework/product-team-competencies/

## Highlights
- Perhaps the most common orthogonal skill Product Managers must pick up, is that of the Project Manager
- Product tends to act as the “glue” for their teams since we own the outcome of our product and to that end, we tend to fill the gaps of our organization and that often means taking on additional roles and responsibilities beyond what is truly Product Management.
