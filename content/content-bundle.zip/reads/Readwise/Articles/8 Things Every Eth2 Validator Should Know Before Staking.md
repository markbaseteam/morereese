# 8 Things Every Eth2 Validator Should Know Before Staking

![rw-book-cover](https://readwise-assets.s3.amazonaws.com/static/images/article1.be68295a7e40.png)

## Metadata
- Author: [[Cayman Nava]]
- Full Title: 8 Things Every Eth2 Validator Should Know Before Staking
- Category: #articles
- URL: https://medium.com/p/94df41701487

## Highlights
- the protocol level, time is broken up into 6.4 minute increments, called epochs,
- After the chain has not been finalized for more than 4 epochs (25.6 min), inactivity penalties will be doled out, and get worse every epoch the longer the chain isn’t finalized. If your validator is still performing its duties during these times, it will not be penalized.
- One subtlety to this exit process is that once a validator goes active, it can’t exit until after at least 256 epochs later.
