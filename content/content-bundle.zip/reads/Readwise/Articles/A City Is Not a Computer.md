# A City Is Not a Computer

![rw-book-cover](https://readwise-assets.s3.amazonaws.com/static/images/article1.be68295a7e40.png)

## Metadata
- Author: [[placesjournal.org]]
- Full Title: A City Is Not a Computer
- Category: #articles
- URL: https://placesjournal.org/article/a-city-is-not-a-computer/

## Highlights
- Dan Doctoroff, the Michael Bloomberg associate who founded Sidewalk Labs, wonders, “What would a city look like if you started from scratch in the internet era — if you built a city ‘from the internet up?’”
- The city is a computer, the streetscape is the interface, you are the cursor, and your smartphone is the input device. This is the user-based, bottom-up version of the city-as-computer idea, but there’s also a top-down version, which is systems-based. It looks at urban systems such as transit, garbage, and water and wonders whether the city could be more efficient and better organized if these systems were ‘smart.’
