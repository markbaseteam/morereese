# What Really Predicts Happiness?

![rw-book-cover](https://readwise-assets.s3.amazonaws.com/static/images/article3.5c705a01b476.png)

## Metadata
- Author: [[Nick Maggiulli]]
- Full Title: What Really Predicts Happiness?
- Category: #articles
- URL: https://ofdollarsanddata.com/what-really-predicts-happiness/

## Highlights
- Harvard Study of Adult Development
- Close relationships, more than money or fame, are what keep people happy throughout their lives.
