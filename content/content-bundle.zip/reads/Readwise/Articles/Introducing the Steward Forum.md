# Introducing the Steward Forum

![rw-book-cover](https://readwise-assets.s3.amazonaws.com/static/images/article3.5c705a01b476.png)

## Metadata
- Author: [[Engagement Cards]]
- Full Title: Introducing the Steward Forum
- Category: #articles
- URL: https://gov.gitcoin.co/t/introducing-the-steward-forum/9485

## Highlights
- there needs to be a way to not only keep track of it all but enable engagement through simple, non overly taxing yet highly valuable engagement flows. This is a first step towards that.
- We have found that it is important to more actively involve not just those Stewards who are participating in Gitcoin day to day, but also those who can offer more of an outsiders’ perspective.
