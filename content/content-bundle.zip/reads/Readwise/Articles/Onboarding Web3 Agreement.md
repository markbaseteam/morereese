# Onboarding Web3 Agreement

![rw-book-cover](https://readwise-assets.s3.amazonaws.com/static/images/article0.00998d930354.png)

## Metadata
- Author: [[A Beautiful Mind]]
- Full Title: Onboarding Web3 Agreement
- Category: #articles
- Document Tags: [[mental-health]] [[web3]] 
- URL: https://mirror.xyz/bhau.eth/AOo4N6gcHPhJSGluCTSpJ9meC0PbghLv0HGcBUo4R-s

## Highlights
- this agreement: reviews ethics and morality in the context of Web3. clarifies expectations. outlines the nature of your investment pertaining to time and attention. specifies educational scope and outcome measures geared towards understanding “Web3.”
- As Web3 progressively disintermediates rent-seeking behavior (removes middlemen), power and responsibility ultimately begin to fall upon the community. These communities are comprised of individuals like you and I, and in many ways resemble the ethos of the Founding Fathers who rejected tyranny to create a new world for everyone in the great nation where we find ourselves today. They felt their freedoms and liberties were restricted in Great Britain, much like most people today find themselves gated out of access to essentially… a better life.
- Community is Layer Zero
- We will primarily focus on investing Attention and Time, as that is the prerequisite to investing Value
- If you cannot invest your Attention, you cannot invest Value; only invest in what you understand
- Time is a “deflationary asset,” and its supply is fixed
