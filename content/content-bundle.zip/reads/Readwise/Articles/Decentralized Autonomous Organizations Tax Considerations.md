# Decentralized Autonomous Organizations: Tax Considerations

![rw-book-cover](https://readwise-assets.s3.amazonaws.com/static/images/article1.be68295a7e40.png)

## Metadata
- Author: [[Guest Authors]]
- Full Title: Decentralized Autonomous Organizations: Tax Considerations
- Category: #articles
- Document Tags: [[dao]] [[legal]] [[regulation]] [[tax]] 
- URL: https://cointelegraph.com/news/decentralized-autonomous-organizations-tax-considerations

## Highlights
- In the United States, for example, the tax regulations provide that a joint venture or other contractual arrangement may create a separate entity if the participants “carry on a trade, business, financial operation, or venture and divide the profits therefrom.” (By contrast, mere co-ownership of property that is maintained, kept in repair, and rented or leased does not constitute a separate entity for tax purposes.)
- Once a DAO is determined to be a separate tax entity, the next question is: How should this DAO be classified for tax purposes? The two general types of classifications are corporation or partnership.
- A DAO could potentially be classified as a foreign publicly traded partnership (PTP) if the DAO’s tokens are traded on “a secondary market (or the substantial equivalent thereof).”
- Aside from tax, investors have had growing concerns about the legal liability resulting from their investments in DAOs (i.e., their personal assets could be put at risk for any lawsuits or debts of the DAO). As a result, two states Vermont and Wyoming, have allowed DAOs to register in their states as DAO LLCs which, like regular LLCs, provide the benefit of limited liability for the DAO members.
- From a tax perspective, a DAO LLC, because it is registered under state law, may be treated as a domestic partnership for tax purposes.
