# Real Humans Need to Shape DAOs So They Don’t Become a Rich Kid Club

![rw-book-cover](https://readwise-assets.s3.amazonaws.com/static/images/article1.be68295a7e40.png)

## Metadata
- Author: [[beincrypto.com]]
- Full Title: Real Humans Need to Shape DAOs So They Don’t Become a Rich Kid Club
- Category: #articles
- URL: https://beincrypto.com/real-humans-need-to-shape-daos-so-they-dont-become-a-rich-kid-club/

## Highlights
- Legendary systems theorist, Donella Meadows,
- Contributing to a DAO is a great way to leave a legacy.
- A DAO is, in its most simple form, a community of like-minded, good-hearted, people who work on impactful projects together and also have fun.
