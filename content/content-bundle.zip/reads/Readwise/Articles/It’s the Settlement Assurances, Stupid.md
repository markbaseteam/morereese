# It’s the Settlement Assurances, Stupid

![rw-book-cover](https://readwise-assets.s3.amazonaws.com/static/images/article1.be68295a7e40.png)

## Metadata
- Author: [[Nic Carter]]
- Full Title: It’s the Settlement Assurances, Stupid
- Category: #articles
- URL: https://medium.com/@nic__carter/its-the-settlement-assurances-stupid-5dcd1c3f4e41

## Highlights
- I think settlement assurances are the primary thing worth contemplating about any public blockchain
- Bitcoin is understood very differently by two major tribes: the investors and the entrepreneurs.
- I think that Bitcoin is a novel institutional technology — high-assurance wealth storage and transfer without reliance on the State or a financial system — which will unlock new modes of human organization and will enable productive commerce in places where property rights are poorly enforced.
- So what are settlement assurances exactly? They refer to a system’s ability to grant recipients confidence that an inbound transaction will not be reversed.
- Ledger costliness
- In reality, Bitcoin pays its private army of miners far better, and as a consequence, they produce far more security per minute in the form of hashes.
- The Anatomy of Proof-of-Work
- Your Exchange Needs More Confirmations: The BitConf Measure
- The point here is that settlement in a blockchain system is a flow. Block time is largely irrelevant. Ethereum has many more blocks per hour than Bitcoin does, but settlement should be compared between the two based on ledger cost, rather than number of confirmations.
- Yield from reversal: transaction size
- two of the most important quantitative variables in blockchain settlement: ledger cost and yield from reversal
- here are a few takeaways:
- I. Block time is arbitrary, and changes little
- II. Bitcoin is either providing massive security overkill, or other blockchains are critically at risk
- If you measure blockchains purely based on the salary paid to transaction selectors (miners and validators) per unit of time, for the most part, they look devastatingly weak compared to Bitcoin
- III. Settlement is always probabilistic
- IV. By being open about its security model, Bitcoin’s PoW is usefully transparent
- If there’s anything I could have you take away from this piece, it’s the following. Instead of viewing settlement as a function of some preconceived number of confirmations, think of settling a transaction in a proof of work system as the process of wood petrifying slowly. It happens at a given rate and can’t be accelerated. The rate is determined by the variables enumerated above: chiefly, ledger costliness, transaction size, and the availability of addressable hardware. Once completed, the wood has been replaced by minerals and is rock solid, no longer soft and malleable. The features of the wood are forever frozen in time.
