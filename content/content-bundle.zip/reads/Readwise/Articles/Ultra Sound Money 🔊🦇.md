# Ultra Sound Money 🔊🦇

![rw-book-cover](https://readwise-assets.s3.amazonaws.com/static/images/article0.00998d930354.png)

## Metadata
- Author: [[newsletter.banklesshq.com]]
- Full Title: Ultra Sound Money 🔊🦇
- Category: #articles
- URL: https://newsletter.banklesshq.com/p/ultra-sound-money-

## Highlights
- Crypto-economics represents a paradigm shift in how humans are able to engage as economic agents.
- Hyperinflation occurs when the expenditures of the Coordinating Body are so large that it enters into a state of perpetual currency issuance to fund these expenditures. This perpetual issuance generally still works, so long as the people using the money aren’t bothered by the devaluation. But, once they wake up to the rampant discharging of the monetary battery, they tend to quickly flee away from the unit.
- monetary units are charged by buying and discharged by selling. The net outcome of this design is that the value of Bitcoin’s native economy won’t be able to be fully expressed by BTC the asset. BTC the asset leaks its value due to significant power-draw placed on it by the Bitcoin Proof-of-Work security engine.
- Good crypto-economic systems optimize both cryptography and economics. The optimization of one without the other leaves an inefficient imbalance in the system and can lead to long-term wear on the system. This is the fundamental critique that crypto-economic researchers have of the bitcoin system: an optimized economic asset but powered by an inefficient economic engine.
- Having money leftover after costs and expenditures means that good businesses are net-buyers of money.
- When these three parts of an economic system are composed together, they create a ‘Nation-State’, a composed integrated body of productive internal organs (the economy), a central nervous system for coordination and long-term planning (the government), and teeth, claws, and weapons for protection (the protective force)
- when these crypto-economies grow larger, the cryptocurrency assets that power these systems grow in value instead of supply.
- Crypto-economic systems, on the other hand, are solely focused on powering defense, and nothing else.
- ‘Buying’ money charges it with power. ‘Selling’ money discharges its power.
- The act of minting new money does not increase the total value of all outstanding money. Rather, the existing supply of money becomes diluted, and power is drawn out of the circulating supply of money, and funneled into the newly minted coin.
- Gresham's law is an observation in economics that “bad money drives out good.”
- Crypto-economic systems protect the economic engines, but they do not tinker or manipulate them.
- Growth in economic output charges the monetary unit with economic power.
- As the margins for PoW miners get slimmer and slimmer, more and more BTC must be sold to pay for the operational costs. Selling the unit discharges the energy, and Bitcoin security is fundamentally designed to instigate a race to consume as much energy as possible.
- Economic engines don’t need money, they need power. Money is only a vehicle; it must also be backed by power.
- In contrast to nation-state economies, crypto-economic systems are inside their own plane of existence. Bitcoin’s Proof of Work exists in the SHA-256 world, and only responds to other SHA-256 competitors (Bitcoin Cash being the only other force-of-power in this plane, and not a very strong one).
- Bitcoin is secured by long-term perpetual selling pressure on the economic unit.
- Proof of Stake operates on the assumption that there is a sufficient supply of interested parties who will hold ETH in order to access ETH-denominated rewards.
- Ethereum Proof-of-Stake secures the system by erecting a ‘wall-of-value’ that a potential attacker must overcome in order to attack the system.
- What’s more important, however, is that Proof of Stake systems do not consume economic resources. All that is needed to secure Ethereum under PoS is a Raspberry Pi, an internet connection, and 32 ETH. Stakers are not required to sell their ETH rewards to pay for the economic costs of providing security. The ‘economic costs’ of Ethereum are the opportunity costs of holding ETH.
- Proof of Stake is an alternative to Proof of Work that leverages the value of the native asset of a crypto-economic system to provide security to the economy.
- PoW generates a rat-race of energy consumption that leads to long-term persistent selling of the asset by miners. PoS surgically targets the party of people who are most bullish on the asset, and provides them with a transaction validation system that allows them to not have to sell any ETH to express their belief in the growth of the Ethereum economy.
