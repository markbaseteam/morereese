# A Product Manager’s Guide to Web3

![rw-book-cover](https://readwise-assets.s3.amazonaws.com/static/images/article3.5c705a01b476.png)

## Metadata
- Author: [[Lenny Rachitsky]]
- Full Title: A Product Manager’s Guide to Web3
- Category: #articles
- Document Tags: [[alchemy]] [[product]] [[product-management]] [[web3]] 
- URL: https://www.lennysnewsletter.com/p/a-product-managers-guide-to-web3

## Highlights
- Alchemy is essentially AWS for web3, and has quickly become a fundamental infra layer in the web3 startup stack
- Web3 product managers are still cross-functional leaders driving outcomes
- Web3 product managers are still cross-functional leaders driving outcomes, but web3 product management is different in three primary ways: It’s more versatile It’s more art than science It’s more public
- web3 PMs have to think about protocol design, tokenomics, user safety, security, growth marketing, community engagement, and much more that encompasses the interconnected people, technology, and economics of web3 products.
- The most important things a web3 team needs usually don’t have that much to do with product managers
- today the best web3 PMs spend 95/5 on execution/vision, not 70/30.
- In web2, the founder or early product manager can be crucial in deciding what and how to build, which helps get to the holy grail of product-market fit. In web3 the product experience, such as features and perceptible user experience, doesn’t actually matter as much to the success of the project relative to the token incentives (Staking and AMMs), trading pairs (DEX), artwork (NFTs), network design (L1s/L2s), transaction speed (L1s/L2s), security (L1s/L2s), or other attributes. These are areas where PMs are secondary, if relevant at all.
- Web3 PMs need to understand different blockchains so they can select which chains to support and design accordingly, whereas in web2, PMs today rarely need to be involved with technical infrastructure decisions because it may not directly impact the end-user experience being created.
- persuasion and coordination have been core to the web2 PM job. Those skills don’t matter as much here. Web3 PM is more focused on execution and community
- web3 PMs have to think about protocol design, tokenomics, user safety, security, growth marketing, community engagement, and much more that encompasses the interconnected people, technology, and economics of web3 products
- Web3 PM emphasizes building, marketing, and iterating rather than planning, managing, and measuring
- listen to the community on Discord and Crypto Twitter (user researcher), run some on-chain analysis through a tool like Dune Analytics (data scientist), sketch out the token swapping UX and the AMM’s proposed liquidity incentives (designer and tech lead), form partnerships with stablecoin protocols (BD manager), write the launch blog post (product marketing manager), and make the memes and virality happen on Twitter (social media manager
- Web3 requires one person to do all of this right now, because the tasks above are uniquely technical and interdependent such that they can’t be easily unbundled
- The UI is a commodity in part because of open-source and composability where teams fork each other’s products.
- web3 products are largely subject to the behavior of the Layer 1/Layer 2 protocol they’re built on top of, like the fast transactions on Solana or high gas fees on Ethereum Layer 1
- Web3 PMs need to understand different blockchains so they can select which chains to support and design accordingly, whereas in web2, PMs today rarely need to be involved with technical infrastructure decisions because it may not directly impact the end-user experience being created
- Communities structured as DAOs govern most protocols; product leadership must happen through them
- You must prioritize user security, because with every transaction there are funds at stake
- given how web3 wallets work, there is no real separation between funds and user engagement
