# Introducing Flow, a New Blockchain From the Creators of CryptoKitties

![rw-book-cover](https://readwise-assets.s3.amazonaws.com/static/images/article1.be68295a7e40.png)

## Metadata
- Author: [[Roham Gharegozlou]]
- Full Title: Introducing Flow, a New Blockchain From the Creators of CryptoKitties
- Category: #articles
- URL: https://medium.com/p/d291282732f5

## Highlights
- Flow, a fast and developer-friendly blockchain built to support entire ecosystems of apps, games, and the digital assets that power them.
- inancing from Andreessen Horowitz’s crypto fund and Accomplice as well as leading players in entertainment and crypto including Warner Music Group, Union Square Ventures, Venrock, AppWorks, Digital Currency Group, Autonomous Partners, Fenbushi Digital, Animoca Brands, SV Angel, Version One, CMT, and CoinFund, among others
