# Decentralized Autonomous Organizations – DAO

![rw-book-cover](https://readwise-assets.s3.amazonaws.com/static/images/article0.00998d930354.png)

## Metadata
- Author: [[wyomingcompany.com]]
- Full Title: Decentralized Autonomous Organizations – DAO
- Category: #articles
- Document Tags: [[dao]] [[legal]] [[the-rise-of-dao-culture]] [[wyoming]] 
- URL: https://wyomingcompany.com/decentralized-autonomous-organizations-dao/

## Highlights
- DAOs are digital organizations that provide a fresh way to fund ventures, democratize decisions, and split proceeds
- “If blockchains, NFTs, smart contracts, DeFi protocols, and DApps are tools, DAOs are the groups that use them to create new things,” Packy McCormick explained in his Not Boring newsletter last year. “If they’re the what, DAOs are the how.”
    - Tags: [[dao]] 
- A decentralized autonomous organization is a limited liability company whose articles of organization contain a statement that the company is a decentralized autonomous organization and certain other statements.  They must include the words DAO or LAO or DAO LLC, in the name.
  Decentralized autonomous organizations can be either Member Managed or Algorithmically Managed.
