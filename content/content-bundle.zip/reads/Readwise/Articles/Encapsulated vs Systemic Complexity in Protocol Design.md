# Encapsulated vs Systemic Complexity in Protocol Design

![rw-book-cover](https://readwise-assets.s3.amazonaws.com/static/images/article4.6bc1851654a0.png)

## Metadata
- Author: [[vitalik.ca]]
- Full Title: Encapsulated vs Systemic Complexity in Protocol Design
- Category: #articles
- Document Tags: [[design]] [[protocol]] [[vitalik]] 
- URL: https://vitalik.ca/general/2022/02/28/complexity.html

## Highlights
- encapsulated complexity and systemic complexity
- Encapsulated complexity occurs when there is a system with sub-systems that are internally complex, but that present a simple "interface" to the outside
- Systemic complexity occurs when the different parts of a system can't even be cleanly separated, and have complex interactions with each other.
    - Tags: [[systems]] [[org-design]] 
- One important design choice that appears in many blockchain designs is that of cryptography versus cryptoeconomics. Often (eg. in rollups) this comes in the form of a choice between validity proofs (aka. ZK-SNARKs) and fraud proofs.
- while ZK-SNARKs are complex, their complexity is encapsulated complexity.
- The relatively light complexity of fraud proofs, on the other hand, is systemic
- complexity is less dangerous if it is encapsulated
