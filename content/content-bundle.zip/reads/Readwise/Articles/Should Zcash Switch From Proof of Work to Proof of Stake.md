# Should Zcash Switch From Proof of Work to Proof of Stake?

![rw-book-cover](https://readwise-assets.s3.amazonaws.com/static/images/article3.5c705a01b476.png)

## Metadata
- Author: [[Zooko Wilcox]]
- Full Title: Should Zcash Switch From Proof of Work to Proof of Stake?
- Category: #articles
- URL: https://electriccoin.co/blog/should-zcash-switch-from-proof-of-work-to-proof-of-stake/

## Highlights
- With PoW, miners must sell the coins they’ve earned to pay their costs (electricity and ASICs). This means there is a constant downward pressure on the price of ZEC and a matching upward pressure on the price of electricity and ASICs
- in PoW mining, the community has to overpay for security, because they can’t credibly threaten to punish defecting miners. So, instead they have to promise large future rewards to the miners to keep them loyal. In PoS, the community can get better security — including economic finality in which you can be sure that a payment you’ve received won’t be forked away — and performance at much lower cost.
- Zcash Shielded Assets.
- The bottom line for me is that switching Zcash from PoW to PoS offers many huge improvements to the utility, security, and decentralization of the Zcash network and to the utility and demand for the ZEC coin.
