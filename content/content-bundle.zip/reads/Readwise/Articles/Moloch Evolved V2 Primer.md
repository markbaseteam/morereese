# Moloch Evolved: V2 Primer

![rw-book-cover](https://readwise-assets.s3.amazonaws.com/static/images/article0.00998d930354.png)

## Metadata
- Author: [[medium.com]]
- Full Title: Moloch Evolved: V2 Primer
- Category: #articles
- Document Tags: [[moloch]] [[molochv2]] 
- URL: https://medium.com/raid-guild/moloch-evolved-v2-primer-25c9cdeab455

## Highlights
- Moloch v2 was designed to enhance coordination on a technical level.
- here’s how grants were (and are) issued in v1:Proposals must be submitted by an existing member of the DAO, and processed onchain by another member of that DAO.Following the proposal being passed, the grantee received “shares” equivalent to a pro-rata claim on ETH in the underlying guild bank. These shares are then “ragequit” and returned as wETH.Seeing as proposals take roughly two weeks to process from start to finish, this means that the value of the “shares” was likely to change due to the underlying volatility of ETH.
- Moloch v2 DAOs can now hold up to 200 different assets, as opposed to just one.
- Instead of receiving shares for proposals, those wishing to receive funding can do so in any of the DAOs assets — such as ETH or DAI — without having to ragequit shares.
- GuildKick allows members to force a ragequit upon someone else through a unique type of proposal.
- Anyone, including those who are not members of the DAO, can now submit proposals on their own, as opposed to relying on a DAO member to submit it for them.
- With trade proposals, DAOs can swap their underlying collateral, for example turning Dai into a transferrable, interest-earning asset like Chai.
