# Your DAO Still Needs an Operating System

![rw-book-cover](https://readwise-assets.s3.amazonaws.com/static/images/article1.be68295a7e40.png)

## Metadata
- Author: [[jaredcohe Crypto  Operating System]]
- Full Title: Your DAO Still Needs an Operating System
- Category: #articles
- Document Tags: [[aragon]] [[colony]] [[dao]] [[daostack]] [[definition-of-dao]] [[moloch]] [[operating-system]] [[operations]] 
- URL: https://nycoo.org/2021/06/24/your-dao-still-needs-an-operating-system/

## Highlights
- A decentralized autonomous organization (DAO) is an organization that makes decisions either automatically by computers based on pre-written, public code or by a member vote.
- The first Operating System is the cool, new, autonomous, blockchain-based Operating System that runs on computers and tells the computers what to do.
- The second Operating System is the boring, old-fashioned, off-chain Operating System that runs on people and gives the people their rules and guidelines.
- Computer OS
- People OS
- By definition, a DAO reduces the need, in part, for that People OS.
- unless your DAO is completely autonomous on the blockchain and requires no human intervention ever, your DAO still needs some version of an old-fashioned, people Operating System.
- The absence of a People OS becomes most obvious and problematic when something goes wrong (just like at non-DAOs organizations)
