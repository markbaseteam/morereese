# The Future of Search Is Boutique

![rw-book-cover](https://future.com/wp-content/uploads/2022/04/BoutiqueSearch-Linkedin.jpg)

## Metadata
- Author: [[Sari Azout]]
- Full Title: The Future of Search Is Boutique
- Category: #articles
- URL: https://future.com/the-future-of-search-is-boutique/

## Highlights
- **When you monetize via ads, curation takes a backseat to featuring advertisers** because there is just less digital real estate available to curate your own recommendations ([View Highlight](https://read.readwise.io/read/01grgx0s742xe5b4h0p5zxj064))
    - Tags: [[advertising]] [[curation]] 
- It has become popular to say we live in the information age, and we need “curation” to help us sort through the mess. But thus far, **the conversation around curation has been too focused on the content and not enough on the structure**. We seem to have accepted the job of the curator as providing a product review, a list of links, or a song recommendation — all inside linear structures and chronological feeds designed to surface the ideas of the last 24 hours, not to accumulate and surface knowledge as needed. ([View Highlight](https://read.readwise.io/read/01grgx43ce4xs80ejnb8q1awzz))
    - Tags: [[curation]] 
- The opportunity is in moving curated content feeds away from their never-ending-now orientation and toward more goal-oriented interfaces. ([View Highlight](https://read.readwise.io/read/01grgx6tbqzx6mepykdp2tajzx))
- *All curation grows until it requires search, and all search grows until it requires curation.*
  *—Ben Evans*
  Applying Ben Evans’ framework, it becomes clear that while the vertical search players have become too large and need curation, the curation feeds have become too long to browse and require search and structured data. The solution is better search and better curation, all wrapped in a better business model — a combination I call **boutique search engines**. ([View Highlight](https://read.readwise.io/read/01grgx7yeyrj7sqh0av7c3d9p6))
- Unlike vertical search aggregators, **boutique search engines feel less like the Yellow Pages and more like texting your friends to ask for a recommendation.** They have constrained supply, which is the foundation for their biggest moat: **trust**. Importantly, boutique search engines also introduce new business models that don’t rely on advertising. ([View Highlight](https://read.readwise.io/read/01grgxdk04afpvc0nc9j8q4scf))
- With today’s subscription models, customers have no real incentive to help the platform grow. **Nascent token-based business models show early signs of promise.** By giving ownership to stakeholders and allowing subscribers to benefit from future upside, startups can overcome the cold start problem. ([View Highlight](https://read.readwise.io/read/01grgxm9c4wwdbwxgdyhqt2eq5))
    - Tags: [[token-gating]] [[incentive-models]] [[subscription]] 
