# The Laws of Lorecore

![rw-book-cover](https://readwise-assets.s3.amazonaws.com/static/images/article4.6bc1851654a0.png)

## Metadata
- Author: [[ZORA ZINE]]
- Full Title: The Laws of Lorecore
- Category: #articles
- URL: https://zine.zora.co/the-laws-of-lorecore-shumon-basar

## Highlights
- Lore refers to our ubiquitous, obsessive reliance on narrative, meta-narrative, and myth.
- Cores are like screenshots as trends
- During Lorecore, we overshare our innermost psychological and emotional details to a world that’s already drowning in too much intimacy.
    - Tags: [[lorecore]] 
- Narrative Economics: How Stories Go Viral and Drive Major Economic Events
- But in Lorecore, pathologies are identity-forming powers; they’re divination tools to discover your atypical kin. We find community and definition through the process of (self) diagnosis.
- Tech is the ultimate modern magic. This makes Technologians the Magic Individuals of Lorecore.
- Another Law of Lorecore is that the dumbest plot line with maximum incredulity is what’s going to happen next.
- Lorecore (noun): An era, belonging to digital capitalism, characterized by people’s existential need to storify themselves at the very moment global narratives collapse in an unprecedented manner.
