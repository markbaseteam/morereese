# Measuring Community Health Through Community Tokens

![rw-book-cover](https://readwise-assets.s3.amazonaws.com/static/images/article4.6bc1851654a0.png)

## Metadata
- Author: [[Therefore, as I’ve argued]]
- Full Title: Measuring Community Health Through Community Tokens
- Category: #articles
- URL: https://mirror.xyz/itamarg.eth/cFCMTRNKRI1cl0A-Jm50jHqoO2Nio7VuglGi0l8hWag

## Highlights
- understanding the patterns of community ownership and how it evolves over time is critical to maintaining the health of the community in the long run.
