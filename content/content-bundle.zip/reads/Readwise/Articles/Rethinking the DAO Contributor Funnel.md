# Rethinking the DAO Contributor Funnel

![rw-book-cover](https://readwise-assets.s3.amazonaws.com/static/images/article4.6bc1851654a0.png)

## Metadata
- Author: [[mirror.xyz]]
- Full Title: Rethinking the DAO Contributor Funnel
- Category: #articles
- Document Tags: [[cal.com-tooling]] [[clarity-tooling]] [[collabland-tooling]] [[community]] [[dao]] [[dework-tooling]] [[Favorites]] [[framework]] [[incentive]] [[meritverse]] [[sobol-tooling]] [[tally-writing]] 
- URL: https://mirror.xyz/0xjustice.eth/iWSuHkhJt2M9W0rAzBwfUoyrYRtcJ6v7QI3SnHBlVvc

## Highlights
- Different levels of community engagement have different privileges and expectations, and to conflate them is a disservice to your community.
- Consider the following questions when thinking about the organization of a DAO: Does it segment groups with defined availability, responsibility, and expectation levels? Does it leverage tools and access rights that correspond to those segmentation levels?  Does the financial upside of each segment match the expected levels of commitment and responsibility?
- The very first layer of your community is your users. It encompasses anyone who uses the products or services of your community. There are no gates to enter, and all are encouraged to participate. This level also includes anyone who owns any amount of the community token.
    - Tags: [[dao-design]] [[dao-contributor]] [[dao]] [[community]] 
- Level 1: Users
- Level 2: Community Members
- In this scheme, users and community members are not the same. While public users benefit from the community's products, community members influence how those products and services are created and disseminated. They are the community's explorers, advocates, and evangelists.
- Level 3: Contributors
- The next level comprises contributors. These individuals have moved beyond just membership to become productive assets of the community. And because the people closest to work should be the ones making the decisions of what gets done, I argue this level is also the domain of governance
- Level 4: Teams
- Lastly, we arrive at teams which is the level of execution. Teams are a communities' engine, and their ongoing development will define the efficacy and sustainability of a community's product offering. A DAO can not produce sustainable revenue without them.
- You will notice that I have distinctly called out team leads, and that's to endorse a single point of responsibility approach to execution. These leads are the champions, workstream leaders, project managers, or of a team. They are not in charge per se, but they are a central and pivotal point of coordination with whom the buck stops.
- Now that we have our levels and gates mapped, the question becomes how to create them practically. The ideal way to do this is to center every tool and associated permission scheme around token possession.
    - Tags: [[dao-contributor]] [[hats]] 
- Starting with Discord, let's step through a possible setup. Use Colab Land to token-gate specific Discord channels; set Sobol to mirror those access levels.
- Cal.com, which addresses the need for token-gated scheduling.
