# What Are Zero Knowledge Proofs?

![rw-book-cover](https://readwise-assets.s3.amazonaws.com/static/images/article3.5c705a01b476.png)

## Metadata
- Author: [[Shaan Ray]]
- Full Title: What Are Zero Knowledge Proofs?
- Category: #articles
- URL: https://medium.com/p/7ef6aab955fc

## Highlights
- Zero-Knowledge Proofs (ZKPs) allow data to be verified without revealing that data.
- Each transaction has a ‘verifier’ and a ‘prover’.
- A true ZKP needs to prove 3 criteria:
- 1. Completeness: it should convince the verifier that the prover knows what they say they know
- 2. Soundness: if the information is false, it cannot convince the verifier that the prover’s information is true
- 3. Zero-knowledge-ness: it should reveal nothing else to the verifier
- There are two types of ZKPs: interactive and non-interactive.
- Interactive:
- Non-interactiv
- ve
- Zero-Knowledge Succinct Non-interactive ARguments of Knowledge (Zk-SNARKs, a type of non-interactive ZKP)
