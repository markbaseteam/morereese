# Beyond Follows: Trust in Computing

![rw-book-cover](https://readwise-assets.s3.amazonaws.com/static/images/article4.6bc1851654a0.png)

## Metadata
- Author: [[Sarah Friend]]
- Full Title: Beyond Follows: Trust in Computing
- Category: #articles
- URL: https://march.international/beyond-follows-trust-in-computing/

## Highlights
- We can think of the utility of shifting between global and local as a question about “how transitive we think trust is”
- there are other contexts where, if trust stops being personal, it becomes meaningless.
- Jennifer Golbeck, in her paper “Computing with Trust: Definition, Properties, and Algorithms,”
- One of the thorniest problems for decentralized protocols is content moderation. In the absence of a company to set policy, or a government to define hate speech legislation, who decides what is acceptable content?
- One interesting approach to this is found in Secure Scuttlebutt
