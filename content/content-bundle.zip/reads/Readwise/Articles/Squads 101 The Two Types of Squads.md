# Squads 101: The Two Types of Squads

![rw-book-cover](https://readwise-assets.s3.amazonaws.com/static/images/article4.6bc1851654a0.png)

## Metadata
- Author: [[Squads]]
- Full Title: Squads 101: The Two Types of Squads
- Category: #articles
- URL: https://medium.com/p/34b67d1a6641

## Highlights
- There are two types of Squads you can create: a multisig, or a “team.”
- Multisigs are used primarily for two reasons: co-ownership and increased security
- The average TradFi savings account offers 0.06% interest, with no features aside from storing money. Multi-signature wallets offer greater customizability by offering swaps, diversification, staking, & co-ownership all without relying on a centralized third party.
- Squads is far more than just a simple multisig. It combines collective treasury management, DeFi, and on chain governance all into one protocol.
