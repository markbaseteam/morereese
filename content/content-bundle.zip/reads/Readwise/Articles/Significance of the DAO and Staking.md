# Significance of the DAO and Staking

![rw-book-cover](https://readwise-assets.s3.amazonaws.com/static/images/article4.6bc1851654a0.png)

## Metadata
- Author: [[Burak Benligiray]]
- Full Title: Significance of the DAO and Staking
- Category: #articles
- URL: https://medium.com/api3/significance-of-the-dao-and-staking-b8feeaf93804

## Highlights
- Therefore, an oracle solution should be deliberately designed in a way that its off-chain (centrally governed) components submit to its on-chain (decentrally governed) components, and not the other way around.
- all APIs, all chains, all use-cases, public, permissioned, enterprise, etc.
- In the context of API3, staking rewards is primarily the price the project pays to achieve decentralized governance (which is not negotiable, as described above).
