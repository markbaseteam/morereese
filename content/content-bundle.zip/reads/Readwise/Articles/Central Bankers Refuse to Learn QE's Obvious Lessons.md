# Central Bankers Refuse to Learn QE's Obvious Lessons

![rw-book-cover](https://readwise-assets.s3.amazonaws.com/static/images/article4.6bc1851654a0.png)

## Metadata
- Author: [[Jeffrey Snider]]
- Full Title: Central Bankers Refuse to Learn QE's Obvious Lessons
- Category: #articles
- URL: https://www.realclearmarkets.com/articles/2021/09/24/central_bankers_refuse_to_learn_qes_obvious_lessons_795956.html

## Highlights
- Deflation is rightly considered a symptom of underachievement. It is a dastardly monetary disease that infects an economic system by robbing it of its vitality and potential. Money becomes so dear, too dear, that only the most liquid and safe instruments and opportunities are grasped.
- Credit risk is the risk of a missed payment – such as in China earlier this week when a troubled real estate developer by the name of Evergrande failed to produce on a scheduled coupon surprising absolutely no one.
- Liquidity risk, by contrast, is when you think you own a dependable security that makes you think it is dependable because it’ll be easy to sell should the need ever arise.
- And if the government bond yield yields for us this risk-free rate, we are meant to presume all other credit risks are priced upon that starting point. This is what Alan Greenspan had claimed during the middle 2000’s about all credit market rates not being independent. The central bank, he said, set the short run and then all the risk-free (series of one-year forwards) for the entire curve which then created the structure for all credit created and traded within it.
- This was the same guy who couldn’t figure out why bond yields and interest rates at that time were not behaving in the academic way (“conundrum”).
- What are liquidity risks, after all, except the too often appropriate concern from financial institutions that money conditions broadly speaking are insufficient or unreliable? They aren’t necessarily questioning credit characteristics, rather the dependability of being able to price any instrument not just today but should even a small spot of bother crop up unexpectedly.
- Inflation, it needs to be said again, never once came close to its target in Japan and to this day the “deflationary mindset” remains undefeated. And interest rates there are easily low, they’re still not easing.
