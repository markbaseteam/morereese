# 1/ Lemme Do a 1-Slide Presentation Since I'm Feeling Job...

![rw-book-cover](https://pbs.twimg.com/profile_images/1558999691672440837/j2u1Ypag.jpg)

## Metadata
- Author: [[Venkatesh Rao]]
- Full Title: 1/ Lemme Do a 1-Slide Presentation Since I'm Feeling Job...
- Category: #articles
- URL: https://twitter.com/vgr/status/1047925106423603200

## Highlights
- What the "unplug for self-care" crowd doesn't get is that you are part of a giant social computer computing the future. The level and latency at which you consume information and bet on it determines your "job" in the social computer. ([View Highlight](https://read.readwise.io/read/01gs33t822sdrm3q96hb8dkbxe))
