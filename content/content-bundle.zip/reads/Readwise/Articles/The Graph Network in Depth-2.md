# The Graph Network in Depth

![rw-book-cover](https://readwise-assets.s3.amazonaws.com/static/images/article2.74d541386bbf.png)

## Metadata
- Author: [[Cobb-Douglas production function]]
- Full Title: The Graph Network in Depth
- Category: #articles
- Document Tags: [[grt]] 
- URL: https://thegraph.com/blog/the-graph-network-in-depth-part-2

## Highlights
- Cobb-Douglas production function
- we should expect Indexers to stake a proportion of total GRT staked, equal to the proportion of work they have performed for the network
- An important choice staking protocols must make with respect to delegation is whether delegateed stake can be slashed due to Indexer misbehaviors. In The Graph, delegated stake will not be slashable, because this encourages a trust relationship between Delegators and Indexers that could lead to winner-take-all mechanics and hurt decentralization.
- “delegation capacity” ensures that an Indexer is always putting a minimum amount of their own funds at stake to participate in the network
- “delegation capacity” ensures that an Indexer is always putting a minimum amount of their own funds at stake to participate in the network
- “delegation capacity” ensures that an Indexer is always
- putting a minimum amount of their own funds at stake to
- participate in the network.
- Curator signaling is the process of depositing GRT into a bonding curve for a subgraph to indicate to Indexers that the subgraph should be indexed
- Using bonding curves—a type of algorithmic market maker where price is determined by a function—means that the more curation shares are minted, the higher the exchange rate between GRT and curation shares becomes. Thus, successful curators could take profits immediately if they feel that the value of future curation fees has been correctly priced in. Similarly, they should withdraw their GRT if they feel that the market has priced the value of curation shares too high
- Proofs of Indexing
- Subgraph Availability Oracle
- A subgraph is defined by a subgraph manifest, which is immutable and stored on IPFS.
- Graph Name Service (GNS), an on-chain registry of subgraphs
- WAVE stands for work, attestation, verification, expiration
- Work. A consumer sends a locked micropayment with a description of the work to be performed. This specification of the work acts as the lock on the micropayment
- Attestation. A service provider responds with the digital good or service being requested along with a signed attestation that the work was performed correctly. This unlocks the micropayment optimistically, on the assumption that the attestation is correct
- Verification. The attestation is verified using some method of verification. There may be penalties, such as slashing, for attesting to work which was incorrectly performed. Verification of the attestation happens out-of-channel.
- Expiration. The service provider must either receive a confirmation of receipt from the consumer or submit their attestation on-chain to receive their micropayment before the locked micropayment expires.
- We can think of state channels being to payment channels, what smart contract blockchains like Ethereum are to Bitcoin
- What payment and state channels have in common, however, is that in their most basic form they are a means of exchanging value or state updates between two participants, which are known ahead of time
