# The Digital Age of Securities

![rw-book-cover](https://readwise-assets.s3.amazonaws.com/static/images/article2.74d541386bbf.png)

## Metadata
- Author: [[Anthony Pompliano]]
- Full Title: The Digital Age of Securities
- Category: #articles
- URL: https://medium.com/@apompliano/the-digital-age-of-securities-e78950fd1b5d

## Highlights
- This switch from paper security certificates to electronic security certificates was previously referenced as a digital shift. I disagree.
- This Digital Age removes more middlemen, creates more efficiencies, and increases the amount of people who can participate. At the heart of this technological shift are two components: digital shares (Security Tokens) and decentralized exchanges.
- This Digital Age removes more middlemen, creates more efficiencies, and increases the amount of people who can participate. At the heart of this technological shift are two components: digital shares (Security Tokens) and decentralized exchanges.
- This Digital Age removes more middlemen, creates more efficiencies, and increases the amount of people who can participate. At the heart of this technological shift are two components: digital shares (Security Tokens) and decentralized exchanges.
- efficiencies, and increases the amount of people who can participate. At the heart of this technological shift
- Decentralized exchanges are a new technology that allow users on a distributed ledger to transact with each other, in a regulatory compliant manner, without reliance on a centralized authority (single point of failure).
