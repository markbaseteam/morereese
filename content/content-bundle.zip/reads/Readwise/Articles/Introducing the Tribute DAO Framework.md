# Introducing the Tribute DAO Framework

![rw-book-cover](https://readwise-assets.s3.amazonaws.com/static/images/article4.6bc1851654a0.png)

## Metadata
- Author: [[medium.com]]
- Full Title: Introducing the Tribute DAO Framework
- Category: #articles
- URL: https://medium.com/@OpenLawOfficial/introducing-the-tribute-dao-framework-3f2f0ed50d62

## Highlights
- With the Tribute DAO framework, building and managing DAOs is easier through a modular architecture
- For security and adaptability purposes, the Tribute DAO Framework draws from hexagonal architecture, explicitly separating out contracts to provide layered access to DAO state changes.
- The framework separates logic between core contracts and different external adapter and extension contracts that can be launched and added as DAOs grow and select new operations.
- The Tribute DAO Framework covers Moloch v2 features and is feature compatible with Moloch v2.
