# StrongBlock Flash Paper

![rw-book-cover](https://readwise-assets.s3.amazonaws.com/static/images/article1.be68295a7e40.png)

## Metadata
- Author: [[StrongBlock.io]]
- Full Title: StrongBlock Flash Paper
- Category: #articles
- URL: https://medium.com/p/e1eb9cd55f61

## Highlights
- Node Universal Basic Income (NUBI)
