# What Is Sweat Equity Distribution — and Why Should DAOs Care?

![rw-book-cover](https://readwise-assets.s3.amazonaws.com/static/images/article2.74d541386bbf.png)

## Metadata
- Author: [[Kyler Wandler]]
- Full Title: What Is Sweat Equity Distribution — and Why Should DAOs Care?
- Category: #articles
- URL: https://medium.com/p/2b885b9e5382

## Highlights
- “Sweat Equity” is equity that startups and emerging companies issue to employees and others to attract and incent them, and is almost always “earned” over time (the “Sweat” in Sweat Equity). It has been a defining feature of the high impact entrepreneurship and venture capital universe for more than 50 years.
- Without distinctions between capital contributions and labor contributions, a contributor’s proportional equity can be diluted once the business begins to take on funding.
- Sporos Sweat Equity Management Platform
- governance rights, and warrant rights. The governance rights entitle contributors to participate in the control and direction of the company they care for. The warrant rights represent the contributor’s share of the company’s equity, or ownership.
