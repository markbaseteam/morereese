# Introducing OpenZeppelin Governor

![rw-book-cover](https://readwise-assets.s3.amazonaws.com/static/images/article2.74d541386bbf.png)

## Metadata
- Author: [[Alex Behrens]]
- Full Title: Introducing OpenZeppelin Governor
- Category: #articles
- Document Tags: [[dao-framework]] [[governor]] [[openzeppelin]] 
- URL: https://blog.openzeppelin.com/governor-smart-contract/

## Highlights
- As the DeFi market grows and DAOs begin to influence traditional company structure, the architecture of crypto-first companies will become increasingly on-chain and therefore require secure, modular governance.
- As the DeFi market grows and DAOs begin to influence traditional company structure, the architecture of crypto-first companies will become increasingly on-chain and therefore require secure, modular governance.
- Thanks to our partnership with Tally, OpenZeppelin Governor offers a full-fledged user interface experience for proposers and stakeholders alike.
- we anticipate on-chain governance will become important for all IT infrastructure, not just the crypto economy
- Governance protocols are generally implemented in a special-purpose smart contract called “Governor,” designed to require minimal use of storage for more gas-efficient operations.
