# Disambiguating Autonomy

![rw-book-cover](https://readwise-assets.s3.amazonaws.com/static/images/article0.00998d930354.png)

## Metadata
- Author: [[BlockScience]]
- Full Title: Disambiguating Autonomy
- Category: #articles
- URL: https://medium.com/p/ca84ac87a0bf

## Highlights
- Autonomy is often defined as freedom from external control or influence.
- The concept of autonomy can be broken down into two categories: Functional Autonomy and Political Autonomy.
- Functional Autonomy is the concept of autonomy that relates to the internal operation of a system, drawn from engineering “autonomous” systems
- Political Autonomy is the concept of autonomy as freedom from external political influence, drawn from political science.
- Functional Autonomy refers to the degree of flexibility an individual or organization has to respond to complexity pursuant to its goal or function in an operational sense.
- Strategic Autonomy — the freedom to set goals — from Tactical Autonomy — the freedom of action required to achieve those goals.
- Political Autonomy refers to an individual or organization’s authority to make its own decisions without interference by external individuals or organizations, and can thus be considered autonomy from outside forces.
