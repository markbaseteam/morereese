# Web3’s Missing Killer Social Media App

![rw-book-cover](https://readwise-assets.s3.amazonaws.com/static/images/article4.6bc1851654a0.png)

## Metadata
- Author: [[Doug Petkanics]]
- Full Title: Web3’s Missing Killer Social Media App
- Category: #articles
- URL: https://medium.com/p/609292b3e882

## Highlights
- It is very unlikely that the breakthrough killer social platforms will emerge as the cloned “web3 version of X”, but instead, will introduce a paradigm shifting primitive or behavior, that is truly native to what blockchain coordinated decentralized networks can enable.
- Opportunity: Build a Web3-native video CMS for DAOs
