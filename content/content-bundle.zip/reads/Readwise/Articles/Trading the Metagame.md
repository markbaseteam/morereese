# Trading the Metagame

![rw-book-cover](https://readwise-assets.s3.amazonaws.com/static/images/article0.00998d930354.png)

## Metadata
- Author: [[cobie.substack.com]]
- Full Title: Trading the Metagame
- Category: #articles
- URL: https://cobie.substack.com/p/trading-the-metagame

## Highlights
- being “early” is not about buying the coin on the first possible day. Being “early” is about buying the coin at a valuation that is lower than its potential
- Perhaps every generation opts out of the previous generation’s ponzi and instead decides to create its own.
- Follow-trading certain VCs has had it’s moments of being meta. As long as you don’t follow Barry.
- Identifying the meta and the dynamics behind the meta are probably the most important skills of any shitcoin trader. If you understand the dynamics and incentives, you can figure out whether a metagame has some positive-feedback loop or sustained vector of growth.
- In general, the most successful altcoiners I’ve met have used the metagame to increase their value-holdings over time (ie. trade meta to stack BTC or ETH).
