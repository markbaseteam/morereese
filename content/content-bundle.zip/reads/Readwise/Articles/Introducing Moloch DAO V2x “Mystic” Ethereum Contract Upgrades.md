# Introducing Moloch DAO V2x “Mystic” Ethereum Contract Upgrades

![rw-book-cover](https://readwise-assets.s3.amazonaws.com/static/images/article0.00998d930354.png)

## Metadata
- Author: [[Ross Campbell]]
- Full Title: Introducing Moloch DAO V2x “Mystic” Ethereum Contract Upgrades
- Category: #articles
- URL: https://medium.com/lexdaoism/introducing-moloch-dao-v2x-mystic-ethereum-contract-upgrades-c7984801d4db

## Highlights
- Ethereum contract developers who want to build DAO patterns are well-cautioned to be conservative, and make minimal, easy-to-audit functions that even users themselves can understand. Moloch DAOs excel here.
- Moloch Mystics has emerged as a joint production effort between LexDAO and Raid Guild Ethereum contract developers to make it easier and less costly for Moloch DAO members to form guilds, collect capital, and access external contracts for liquidity and other blockchain-native investment opportunities, in a memetic effort dubbed “More Modular Moloch” (v3).
- The Moloch DAO framework began as a grassroots answer to coordination problems in funding eth2 and other community grants with a “Minimum Viable DAO” vision that was easy to get behind
