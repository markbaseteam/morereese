# Organization Legos: The State of DAO Tooling

![rw-book-cover](https://readwise-assets.s3.amazonaws.com/static/images/article1.be68295a7e40.png)

## Metadata
- Author: [[Nichanan Kesonpat]]
- Full Title: Organization Legos: The State of DAO Tooling
- Category: #articles
- URL: https://medium.com/1kxnetwork/organization-legos-the-state-of-dao-tooling-866b6879e93e

## Highlights
- DAO Operations is a budding crypto vertical that remains underserved.
- the ecosystem of “organisation legos” is still in its infancy
- Constrained delegation
- contributor journey is the process by which an individual goes from not knowing about the DAO, to lurking on social channels (e.g. Twitter, Discord), to establishing connections with other members, to making their first contribution, and beyond
- A member’s progress through the contributor journey could manifest itself as Discord Roles, which when leveraged well, serve as proxies for trust.
- “Movement Model”, in which the community assigns weight to different types of contributions depending on its priorities
- The next generation of governance tools will bridge the gap between off-chain voting and on-chain execution
- DAO Frameworks are a suite of smart contracts and interfaces that allow users to launch and operate an on-chain organization with a few clicks, providing out-of-the-box core features like fund management, membership management, and voting.
