# Product Ops Overview - Silicon Valley Product Group

![rw-book-cover](https://readwise-assets.s3.amazonaws.com/static/images/article0.00998d930354.png)

## Metadata
- Author: [[Marty Cagan]]
- Full Title: Product Ops Overview - Silicon Valley Product Group
- Category: #articles
- Document Tags: [[product]] 
- URL: https://www.svpg.com/product-ops-overview/

## Highlights
- “Our company relies on Product Ops to ensure our product managers learn the necessary skills, select and understand the appropriate tools, know when and how to run experiments, learn how to interpret and leverage data, and to connect the dots between the activities of the various product teams.”
