# The Graph: Why GRT Cannot Be Ignored?

![rw-book-cover](https://readwise-assets.s3.amazonaws.com/static/images/article3.5c705a01b476.png)

## Metadata
- Author: [[Sales Wallet]]
- Full Title: The Graph: Why GRT Cannot Be Ignored?
- Category: #articles
- Document Tags: [[grt]] 
- URL: https://medium.com/general_knowledge/the-graph-why-grt-cannot-be-ignored-26a1b44d97c8

## Highlights
- many smart contracts today are limited by their ability to effectively fetch data from the blockchains. they’re built on
- although Ethereum has a lot of data that is openly accessible to developers combing through that data is incredibly difficult
- Smart contracts are immutable programs that automatically execute a series of actions or transactions when a certain set of conditions are met.
- The Graph is the third and final component of the puzzle, the data sorting layer between the blockchain and dApp
- The Graph functions as a sort of marketplace for specific data that's on Ethereum. Each data set on this marketplace is called a Subgraph
- The Graph functions as a sort of marketplace for specific data that's on Ethereum. Each data set on this marketplace is called a Subgraph
- h. They believe has high-quality information
- GRT is an ERC20 token with an initial supply of 10 billion
- GRT could technically become deflationary, if there are enough query requests on the Graph Explorer
- The Graph is created an elaborate structure of economic incentives involving indexes who find the data, delegate us who ensure indexers are being effective and affordable, and curators who create and vet the data indexes are looking for.
