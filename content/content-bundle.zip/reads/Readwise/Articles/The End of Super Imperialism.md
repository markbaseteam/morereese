# The End of Super Imperialism

![rw-book-cover](https://readwise-assets.s3.amazonaws.com/static/images/article4.6bc1851654a0.png)

## Metadata
- Author: [[bitcoinmagazine.com]]
- Full Title: The End of Super Imperialism
- Category: #articles
- URL: https://bitcoinmagazine.com/culture/bitcoin-replacing-us-super-imperialism

## Highlights
- Ultimately, Hudson’s thesis argues that unlike classic European imperialism — driven by private sector profit motives — American super imperialism was driven by nation-state power motives. It was not steered by Wall Street, but by Washington
