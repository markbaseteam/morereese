# Design Foundations for Systems Capital

![rw-book-cover](https://readwise-assets.s3.amazonaws.com/static/images/article4.6bc1851654a0.png)

## Metadata
- Author: [[Griffith University Yunus Centre]]
- Full Title: Design Foundations for Systems Capital
- Category: #articles
- URL: https://medium.com/p/22c5fb094824

## Highlights
- This is the basic case for systems capital — if we’re serious about systems change, our investment approaches need to match the intention and reality of that pursuit.
