# The Moral Philosophy of Bitcoin

![rw-book-cover](https://readwise-assets.s3.amazonaws.com/static/images/article4.6bc1851654a0.png)

## Metadata
- Author: [[Prateek Goorha]]
- Full Title: The Moral Philosophy of Bitcoin
- Category: #articles
- Document Tags: [[bitcoin]] [[philosophy]] 
- URL: https://medium.com/coinmonks/the-moral-philosophy-of-bitcoin-eac9df43ea69

## Highlights
- Beyond technical concepts, there are simple ideas with astounding memetic resonance that have become tenets for a class of individuals who see themselves as true Bitcoiners : low time preference; hard money; store of value; #HODL; hyperbitcoinization; #stackingsats; “number go up”; Bitcoin not blockchain; stock-to-flow; digital gold; shitcoins, and a hundred others.
- Indeed, you would need to be a polymath of awesome capabilities to understand every aspect of what Bitcoin unleashes. That there is a larger human story to tell is evident to the extent that we see Bitcoin as exceptional, revolutionary, and unique.
- one that makes clear that Bitcoin has a larger agenda, not merely for currency, economies or even for society, but in the story of human moral evolution.
