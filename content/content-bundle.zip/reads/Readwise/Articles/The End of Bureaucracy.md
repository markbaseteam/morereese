# The End of Bureaucracy

![rw-book-cover](https://readwise-assets.s3.amazonaws.com/static/images/article3.5c705a01b476.png)

## Metadata
- Author: [[Gary Hamel, Michele Zanini]]
- Full Title: The End of Bureaucracy
- Category: #articles
- Document Tags: [[haier]] [[org-design]] 
- URL: https://hbr.org/2018/11/the-end-of-bureaucracy

## Highlights
- Why is bureaucracy so resistant to efforts to kill it? In part because it works, at least to a degree. With its clear lines of authority, specialized units, and standardized tasks, bureaucracy facilitates efficiency at scale. It’s also comfortably familiar, varying little across industries, cultures, and political systems.
- These new realities are at last producing alternatives to bureaucracy. Perhaps the most promising model can be found at a company that would not, at first glance, appear to be a child of the digital age. Haier
- Haier has divided itself into more than 4,000 microenterprises, or MEs, most of which have 10 to 15 employees.
    - Tags: [[fractal-organization]] 
- Haier has some 75,000 employees globally
- Every ME is charged with pursuing ambitious goals for growth and transformation—known internally as “leading targets.”
- At Haier every ME is free to buy services, or not, from other MEs.
- “incubating” MEs, or entirely new businesses
- “node” MEs. These businesses sell component products and services
- “transforming” MEs—market-facing units that have roots in Haier’s legacy appliance business
- A substantial part of a node’s revenue depends on the success of its ME customers.
- Every node is thus invested in the performance of the market-facing units, and every employee’s pay is linked to market outcomes.
- Haier is made up of thousands of microenterprises (MEs), which are grouped into platforms.
- Haier sees itself not as a company but as a hub in a much larger network
- While many executives view their businesses as linear value chains, beginning with R&D and ending with sales and support, Haier sees them as value networks in which all parties collaborate at every stage.
- As Laurence J. Peter, author of The Peter Principle, wryly put it: “Bureaucracy defends the status quo long past the time the quo has lost its status.”
- There are three ways to launch a new business at Haier. In the first and most common case, an internal entrepreneur posts an idea online and invites others to help flesh out the nascent business plan. (This is how Zhang Yi, who at the time was an after-sales service manager working in the field, started Express Cabinets.) Second, a platform leader can invite insiders and outsiders to submit proposals for exploiting a white space opportunity. Third, would-be entrepreneurs can pitch their ideas at one of Haier’s monthly road shows across China, which connect local innovators with platform leaders and members of Haier’s investment and innovation platform.
- Every incubating ME is a separate legal entity, funded in part by the founding team.
- “Microenterprises are like a reconnaissance unit—they scan the battlefield and identify the most promising opportunities. It’s like a giant search function.”
- At Haier, MEs are expected to be self-managing, and their freedoms are formally enshrined in three rights: Strategy. The right to decide what opportunities to pursue, to set priorities, and to form both internal and external partnerships. People. The right to make hiring decisions, align individuals and roles, and define working relationships. Distribution. The right to set pay rates and distribute bonuses.
- Opportunities for additional compensation are tied to three performance thresholds: Baseline. When an ME’s quarterly sales and earnings growth exceeds a base target, team members get a bonus proportionate to the amount by which the target was exceeded. Value-adjusted mechanism (VAM). If the ME achieves a midpoint goal between the quarterly baseline and leading targets, the team’s bonus is doubled. At this level, employees are also allowed to contribute their own money, typically 15,000 RMB (about $2,200) each quarter, to a special investment account. If the team hits the VAM target the subsequent quarter, that investment produces a 100% dividend. VAM annual target. When an ME team beats its VAM target for four consecutive quarters, it becomes eligible for profit sharing. Twenty percent of the ME’s net profits in excess of the VAM goal are distributed to the team, though 30% of that amount will be set aside to fund bonuses the following year. As an ME closes in on its leading target, the profit share increases proportionately, sometimes exceeding 40%.
- New leaders are chosen competitively. Typically, three or four candidates will present their plans to the ME team.
- As Zhang often reminds his colleagues, it’s impossible to engineer a complex system from the top down. It has to emerge through an iterative process of imagination, experimentation, and learning.
- As Zhang said in a long-ago meeting with one of the authors of this article: “We want to encourage employees to become entrepreneurs because people are not a means to an end but an end in themselves. Our goal is to let everyone become their own CEO—to help everyone realize their potential.”
