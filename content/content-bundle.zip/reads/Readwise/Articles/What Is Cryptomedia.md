# What Is Cryptomedia?

![rw-book-cover](https://repository-images.githubusercontent.com/324294035/e52bd700-470b-11eb-9432-afecfc8a193d)

## Metadata
- Author: [[Jacob Horne]]
- Full Title: What Is Cryptomedia?
- Category: #articles
- URL: https://cryptomedia.wtf/

## Highlights
- Cryptomedia = [Hypermedia + Creator + Owner + Market] = Value ([View Highlight](https://read.readwise.io/read/01grdcc413n8xg7zfhgnxz051j))
- Cryptomedia is a medium for anyone on the internet to create *universally accessible* and *individually ownable* hypermedia. ([View Highlight](https://read.readwise.io/read/01grdcdercmkgb4bbfzyyenjbs))
- Cryptomedia is created using the [Zora protocol](https://twitter.com/ourZORA/status/1341950748402221056?s=20). ([View Highlight](https://read.readwise.io/read/01grdce4b45r9rxrth3z7wxx9n))
