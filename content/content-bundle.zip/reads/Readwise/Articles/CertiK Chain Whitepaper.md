# CertiK Chain Whitepaper

![rw-book-cover](https://readwise-assets.s3.amazonaws.com/static/images/article2.74d541386bbf.png)

## Metadata
- Author: [[certik.org]]
- Full Title: CertiK Chain Whitepaper
- Category: #articles
- URL: https://www.certik.org/whitepaper

## Highlights
- In order to fully realize the decentralization vision, the security of blockchains must also be decentralized.
- Unfortunately, today this is untrue. Existing blockchain security analysis is conducted in a centralized process through a handful of security auditors. Following an audit, many projects, along with their communities, signal their security and correctness by showcasing that they have undergone an audit. However, few users take the time, or have the ability, to investigate independently whether the code is truly secure and correct; instead, they trust in the centralized process.
- The goal of CertiK Chain is to become the infrastructure of provable trust for all.
- the Chain uses a Delegated Proof-of-Stake (DPoS) consensus protoco
- CertiK Chain enables a system of decentralized Security Oracles which provide runtime analysis of the security of live smart contracts.
- The native digital cryptographically-secured utility token of the CertiK Platform (CTK)
- The goal of introducing CTK is to provide a convenient and secure mode of payment and settlement between participants who interact within the ecosystem on the CertiK Platform, and it is not, and not intended to be, a medium of exchange accepted by the public (or a section of the public) as payment for goods or services or for the discharge of a debt
- CTK may only be utilized on the CertiK Platform, and ownership of CTK carries no rights, express or implied, other than the right to use CTK as a means to enable usage of and interaction within the CertiK Platform.
- In addition to normal staking, CTK holders may choose to engage in "active staking," or staking their CTK as collateral into any of the CertiKShield Pools in exchange for higher staking rewards.
