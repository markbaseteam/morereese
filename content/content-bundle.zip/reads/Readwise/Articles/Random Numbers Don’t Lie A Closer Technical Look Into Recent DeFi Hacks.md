# Random Numbers Don’t Lie: A Closer Technical Look Into Recent DeFi Hacks

![rw-book-cover](https://readwise-assets.s3.amazonaws.com/static/images/article1.be68295a7e40.png)

## Metadata
- Author: [[George Georgiev]]
- Full Title: Random Numbers Don’t Lie: A Closer Technical Look Into Recent DeFi Hacks
- Category: #articles
- URL: https://cryptopotato.com/random-numbers-dont-lie-a-closer-technical-look-into-recent-defi-hacks/

## Highlights
- Cross-chain bridges can generally be divided into centralized custodial bridges (CCB) and Decentralized non-custodial bridges (DNCB).
- The primary purpose of this editorial is to educate and introduce, in relative detail, two often-ignored-yet-vital elements of decentralized cross-chain bridges: the random number ‘k’ involved in Secure Multi-Party Computation (SMPC) and its derivative ‘R’.
- Unlike “deterministic” algorithms that always give the same output given a particular input, “non-deterministic” algorithms can produce different outputs even if given the same input.
- ‘k’ value collision
- When leveraging SMPC, the signing agent is no longer an individual person, but multiple people working in concert to sign transactions.
- In Laymen’s terms, SMPC requires a group of people to work together on a task without knowing what it is they are working on, nor with whom they are working.
