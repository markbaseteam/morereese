# DAOs Aren’t a Fad — They’re A Platform

![rw-book-cover](https://readwise-assets.s3.amazonaws.com/static/images/article2.74d541386bbf.png)

## Metadata
- Author: [[Jeff Kauflin]]
- Full Title: DAOs Aren’t a Fad — They’re A Platform
- Category: #articles
- Document Tags: [[dao]] [[forbes]] [[komorebi-dao]] [[seed-club]] [[tribute-dao]] 
- URL: https://www.forbes.com/sites/jeffkauflin/2022/02/03/daos-arent-a-fad-theyre-a-platform/

## Highlights
- Aaron Wright, CEO and cofounder of Tribute Labs, which set up Flamingo, calls a DAO “a sub-reddit with a bank account.”
- n 2017, Wright cofounded what would become Tribute Labs with Swiss software engineer David Roon to advise companies on how to embed legal contracts into the blockchain
