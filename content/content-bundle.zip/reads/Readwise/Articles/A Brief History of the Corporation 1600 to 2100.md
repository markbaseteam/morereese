# A Brief History of the Corporation: 1600 to 2100

![rw-book-cover](https://readwise-assets.s3.amazonaws.com/static/images/article4.6bc1851654a0.png)

## Metadata
- Author: [[ribbonfarm.com]]
- Full Title: A Brief History of the Corporation: 1600 to 2100
- Category: #articles
- URL: https://www.ribbonfarm.com/2011/06/08/a-brief-history-of-the-corporation-1600-to-2100/

## Highlights
- wo functions that Drucker considered the only essential ones in business, marketing and innovation
- It was not until after the American Civil War and the Gilded Age that businesses fundamentally reorganized around (as we will see) time instead of space, which led, as we will see, to a central role for ideas and therefore the innovation function
- Employment fraction is of course only one of the many dimensions of corporate power (which include economic, material, cultural, human and political forms of power)
- 3-phase model of the history of the corporation: the Mercantilist/Smithian era from 1600-1800, the Industrial/Schumpeterian era from 1800 – 2000 and finally, the era we are entering
- , which I will dub the Information/Coasean era
- To a large extent, the history of the first 200 years of corporate evolution is the history of the East India Company.
- Asia simply had far more to sell than it wanted to buy. Until the EIC came along
- Mahan’s book is the essential lens you need to understand the peculiar military conditions in the 17th and 18th centuries that made the birth of the corporation possible.
- Conventionally, it is understood that the British and the Dutch were the ones who truly took over. But in reality, it was two corporations that took over: the EIC and the VOC
- Today the invisible web of container shipping serves as the bloodstream of the world. Its foundations were laid by the EIC.
- Per capita productivity is about efficient use of human time. But time, unlike space, is not a collective and objective dimension of human experience. It is a private and subjective one. Two people cannot own the same piece of land, but they can own the same piece of time.  To own space, you control it by force of arms. To own time is to own attention. To own attention, it must first be freed up, one individual stream of consciousness at a time.
- If the EIC was the archetype of the Mercantilist era, the Pennsylvania Railroad company was probably the best archetype for the Schumpeterian corporation. Modern corporate management as well Soviet forms of statist governance can be traced back to it
- The Schumpeterian corporation did to business what the doctrine of Blitzkrieg would do to warfare in 1939: move humans at the speed of technology instead of moving technology at the speed of humans.
- Adam Smith’s fundamental ideas helped explain the mechanics of Mercantile economics and the colonization of space.
  Joseph Schumpeter’s ideas helped extend Smith’s ideas to cover Industrial economics and the colonization of time.
  Ronald Coase turned 100 in 2010. He is best known for his work on transaction costs, social costs and the nature of the firm. Where most classical economists have nothing much to say about the corporate form, for Coase, it has been the main focus of his life.
- How do we measure Coasean growth? I have no idea. I am open to suggestions. All I know is that the metric will need to be hyper-personalized and relative to individuals rather than countries, corporations or the global economy.
