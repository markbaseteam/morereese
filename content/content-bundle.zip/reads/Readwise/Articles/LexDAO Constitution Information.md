# LexDAO Constitution Information

![rw-book-cover](https://readwise-assets.s3.amazonaws.com/static/images/article1.be68295a7e40.png)

## Metadata
- Author: [[CI/CD & Automation]]
- Full Title: LexDAO Constitution Information
- Category: #articles
- URL: https://github.com/lexDAO/LexDAO-Constitution

## Highlights
- Wyo. Stat. Title 17, Ch. 22 of the laws of the State of Wyoming.
- legal engineering professionals
- Membership as defined in Wyo. Stat. Title 17, Ch. 22 shall be voluntary and application open to any individual of at least 18 years of age whose purpose or presumed intent is to contribute, to build, and to use the services of LexDAO and is willing to accept the responsibilities and terms of membership.
- LexDAO Handbook
- LexDAO's Aragon Agent is located at LexDAO’s designated Ethereum Web3 address (0x97103fda00a2b47EaC669568063C00e65866a6
- The LexDAO Handbook
- to evidence capital or contributions of efforts provided by members, the Co-op may issue “Loot Shares”.
- The LexDAO Advisory Group (if formed via vote of LDC Members) shall have the power to interpret this Constitution, apply them to particular circumstances, and adopt policies in furtherance of them, provided that all such actions are reasonable and consistent.
