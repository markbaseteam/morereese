# Ownership in Cryptonetworks

![rw-book-cover](https://readwise-assets.s3.amazonaws.com/static/images/article3.5c705a01b476.png)

## Metadata
- Author: [[blog.curvelabs.eu]]
- Full Title: Ownership in Cryptonetworks
- Category: #articles
- Document Tags: [[dao]] [[dxdao]] [[governance]] [[ownership]] 
- URL: https://blog.curvelabs.eu/ownership-in-cryptonetworks-96f13f4a113e

## Highlights
- Let us define ownership in DAOs as a quantitative measure of one’s decision-making authority over a given treasury.
- There are certain key ownership types, such as a DAO possessing greater than 50% of the ownership of another DAO, creating a nested structure. We can think of something like the Omen Guild’s sub-DAO relationship to the DXdao as an example, or the Minion framework.
- Uniswap’s control network has three independent nodes: the DAO, the business proper, and the grants council (independent because they freely govern separate treasuries).
- To Uniswap’s credit, only ~18% of its tokens sit with centralized financial entities
- The question of “how to spend a billion dollars most effectively?” is better reframed as: “How do you distribute ownership effectively across organizations in a given control network?”
- Nevertheless, we can imagine four DAO tactics for ownership distribution and dissolution, some softer expressions of power, and others harder (with the ultimate aim of acquisition or secession):
- Should DAOs aim for a structure that maximizes profit and market liquidity share, denominated in monocultural, globalized fiat, as TNCs do today? Or should they pursue self-sovereign values, aiming to do their accounting in localized currencies that are issued by adaptive governance collectives?
- Simply put: I believe particularly assertive DAOs should find and recruit the best collection of squads to grow themselves.
- Squads with multiple DAO tokens (ownership rights) have multiple liquidity sources, increasing their chance at survival and preserving the collective memory.
- Collectively deciding who, how, and how much ownership is distributed across a given control network is tough, but the path dependencies introduced by these decisions matter, as they will define the cryptosphere’s future.
