# A Proof of Stake Design Philosophy

![rw-book-cover](https://readwise-assets.s3.amazonaws.com/static/images/article4.6bc1851654a0.png)

## Metadata
- Author: [[Vitalik Buterin]]
- Full Title: A Proof of Stake Design Philosophy
- Category: #articles
- URL: https://medium.com/p/506585978d51

## Highlights
- The “one-sentence philosophy” of proof of stake is thus not “security comes from burning energy”, but rather “security comes from putting up economic value-at-loss”.
- It is important to have both layers of defense: economic incentives to discourage centralized cartels from acting anti-socially, and anti-centralization incentives to discourage cartels from forming in the first place.
