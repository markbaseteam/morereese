# Algorithmic Stablecoins- Everything You NEED to Know!

![rw-book-cover](https://readwise-assets.s3.amazonaws.com/static/images/article0.00998d930354.png)

## Metadata
- Author: [[Kevin Jayaraj]]
- Full Title: Algorithmic Stablecoins- Everything You NEED to Know!
- Category: #articles
- Document Tags: [[algorithmic-stablecoin]] [[definition-of]] [[learn-pod]] [[pubdao]] 
- URL: https://www.coinbureau.com/education/algorithmic-stablecoins/

## Highlights
- By derivation, ‘Algorithmic Stablecoin’ can be defined as a stablecoin that maintains its peg through a decentralized self-sustaining protocol or economic system.
- broadly categorize them into four models-
  Rebasing Algorithmic Stablecoins
  Seigniorage Algorithmic Stablecoins
  Over-collateralized Algorithmic Stablecoins
  Fractional Algorithmic Stablecoins
- The ‘Rebasing Algorithmic Stablecoin’ is one of the first models for a decentralized algorithmic stablecoin. Under this model, the token price is stabilized by a ‘rebasing’ of the total token supply.
