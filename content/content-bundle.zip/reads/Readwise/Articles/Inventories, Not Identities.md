# Inventories, Not Identities

![rw-book-cover](https://readwise-assets.s3.amazonaws.com/static/images/article1.be68295a7e40.png)

## Metadata
- Author: [[blog.gnosis.pm]]
- Full Title: Inventories, Not Identities
- Category: #articles
- Document Tags: [[dao]] [[decentralized-identity]] [[definition-of-dao]] [[gnosis]] [[wallet]] 
- URL: https://blog.gnosis.pm/inventories-not-identities-7da9a4ec5a3e

## Highlights
- the issues raised by social platforms defining legitimate identities are not trivial, and there is more at stake than we may think.
- Ultimately, web 3.0 identity will revolve around questions of privacy, portability, and ownership.
- our accounts of the future may look more like inventories, less like identities
- In the same way that digital assets can be self-custodial, many people present blockchain-based accounts as a way to “own” your identity.
- There are two ideas at the core of decentralized identities. One is that subjects have private control over their identifying data and can grant, revoke, and share partial access to it. While not necessary for its implementation, a corollary to this idea is that subjects can use such an identity standard as a universal login across platforms.
- When you connect using a wallet application, however, that wallet application is actually providing a range of services: functionally, you are simultaneously invoking fund management, identity (cross-platform address), and a profile (on-platform history) through one software account
- In short, this wide range of possibilities means web 3.0 “wallets” are actually a very powerful identity regime, and we must think carefully about how we wield them, especially as the distinction between financial applications and social applications fades.
- identity is always inherently relational, defined in relation to environment, authority, and self.
- What we need, then, is a technical stack that supports not an identity, but a collection of identities to navigate the highly varied contexts of web 3.0.
    - Tags: [[decentralized-identity]] [[favorite]] 
- With multi-signatures as a primitive for cooperatives, we have the basic blueprint for a revitalization of new mutualistic institutions in a peer-to-peer context
- While the imaginary potential behind decentralized autonomous organizations (DAOs) blooms wildly, one straightforward way to describe them could be voluntary associations in favor of digital cooperativism.
- Put in more traditional terms, multi-signature accounts can be explained as a form of joint bank account.
- Supporting a wide range of use cases, blockchain-based accounts are manifold in their function, acting authoritatively as wallets, identities, and beyond in one platform
- Composable identity approaches identity as inherently relational, providing modular tools for individuals, groups, and organizations to present themselves within technical systems
- Composable identity approaches identity as inherently relational, providing modular tools for individuals, groups, and organizations to present themselves within technical systems
- technical problems blockchain-based accounts are trying to solve: private key management, application interface, and transaction management
- “The Account Coordinator’s primary goal is to keep track of which keys have which capabilities on which networks. [It] should allow you to audit the interactions you’ve had on each application while preserving a coherent sense of self.”
- At their core, multi-signature accounts enable composable identity on web 3.0. When we approach identity as an inventory holding multiple contexts, we can expansively navigate the highly varied use cases of a peer-to-peer web, and reimagine what we are.
