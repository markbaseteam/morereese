# Service DAOs - Landscape, Challenges, and Solutions

![rw-book-cover](https://readwise-assets.s3.amazonaws.com/static/images/article1.be68295a7e40.png)

## Metadata
- Author: [[Terry Chung]]
- Full Title: Service DAOs - Landscape, Challenges, and Solutions
- Category: #articles
- URL: https://medium.com/p/b1af1a212ea

## Highlights
- ownership fundamentally changes the approach people take to the organization.
- Contributors get paid in stables, service DAO governance tokens, and the client’s project tokens.
- Even for DAOs that have access to talent, getting the talent within the network to actually contribute is difficult.
- Operators cited shyness and confusion as the two main sources of this issue.
- In general, most DAOs were struggling to achieve a balance between incurring too much communication, documentation, process optimization overhead on one hand and variance of contributor work, lack of unified processes delaying contracts, confusion on how to participate/onboard on the other.
    - Tags: [[service-dao]] [[dao]] 
- Custom CRM, and invoice https://smartinvoice.xyz/
