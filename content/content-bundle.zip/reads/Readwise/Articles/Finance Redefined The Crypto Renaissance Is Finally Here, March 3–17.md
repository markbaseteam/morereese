# Finance Redefined: The Crypto Renaissance Is Finally Here, March 3–17

![rw-book-cover](https://readwise-assets.s3.amazonaws.com/static/images/article3.5c705a01b476.png)

## Metadata
- Author: [[Andrey Shevchenko]]
- Full Title: Finance Redefined: The Crypto Renaissance Is Finally Here, March 3–17
- Category: #articles
- Document Tags: [[alchemix]] [[defi]] [[weth10]] 
- URL: https://cointelegraph.com/news/finance-redefined-the-crypto-renaissance-is-finally-here-march-3-17

## Highlights
- I believe the fate of the crypto market is strongly tied to that of the tech sector and stock market as a whole
- We’re still in very, very early stages of DeFi and crypto adoption. All we’ve seen so far is a lot of Ponzi games with maybe a few small nuggets of something real.
- Another exciting new primitive is Alchemix, a protocol that lets you draw a loan backed by your future yield.
