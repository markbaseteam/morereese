# The Everything Bubble & TINA 2.0

![rw-book-cover](https://readwise-assets.s3.amazonaws.com/static/images/article1.be68295a7e40.png)

## Metadata
- Author: [[@johnstcapital]]
- Full Title: The Everything Bubble & TINA 2.0
- Category: #articles
- URL: https://blog.ftx.com/blog/the-everything-bubble/

## Highlights
- The Everything Bubble.
- “QE Infinity turned your savings account into your checking account, the bond market into your savings account, the equity market into the bond market, the venture market into the equity market, while given rise to the crypto market as the new venture market.”
- Dr. Jean-Paul Rodrigue published a widely circulated economic bubble chart in which he identified four distinct phases of a bubble, referred to as the (i) Stealth Phase (ii) Awareness Phase (iii) Mania Phase & (iv) Blow-Off Phase.
- There Is No Alternative (“TINA”) 1.0
- Do you know that when Bitcoin went from $17,000 to $3000 that 86% of the people that owned it at $17,000, never sold it?” Well, this was huge in my mind. So here’s something w/ a finite supply & 86% of the owners are religious zealots.
- are we in a crypto bubble? We think it’s important to bifurcate between large cap crypto vs. some of the more speculative fringe, while diving into BTC, Layer 1 Smart Contract Protocols / DeFi, and NFT’s.
- To win DeFi, Web 3.0, NFT’s, & gaming you need to have a high performant blockchain with the appropriate trade-offs between the Blockchain Trilemma of Scalability, Security & Decentralization.
- TINA 2.0
- Paul Tudor Jones wrote an excellent letter last May entitled, The Great Monetary Inflation, where he outlined assets to own as inflation hedges in which he identified Gold, The Yield Curve, NASDAQ 100, and Bitcoin as the assets most likely to outperform.
- There is a “Big 6” story going on in the commodity world right now between Copper, Nickel, Silver, Lithium, Cobalt, and Aluminum
- What makes something a good store of value? PTJ ranks assets across four characteristics: Purchasing Power- How does this asset retain its value over time? Trustworthiness- How is it perceived through time and universally as a store of value? Liquidity- How quickly can the asset be monetized into a transactional currency? Portability- Can you geographically move this asset if you had to for an unforeseen reason?
    - Tags: [[money]] 
- the US government is spending $875M per hour in 2021.
- If global central banks and governments are going to continue to print money, investors are faced with a TINA 2.0 predicament, where cash is literally burning a hole in their pockets, pushing them not just into risk assets, but further out the risk curve, exacerbating wealth inequality along the way, leading to even further risk taking.
- We’re not believers that there will be “one chain to rule the world,” but liquidity & therefore network effects tend to coalesce around a handful of purpose built winners for technology (e.g., AWS / Azure / Google) and trading (e.g., ICE / NDAQ / CME / CBOE) so there’s a need to put a stake in the ground.
- Paul Tudor Jones wrote an excellent letter last May entitled, The Great Monetary Inflation, where he outlined assets to own as inflation hedges in which he identified Gold, The Yield Curve, NASDAQ 100, and Bitcoin as the assets most likely to outperform.
