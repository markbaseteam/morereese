# Why DAOs Are the New Firms

![rw-book-cover](https://readwise-assets.s3.amazonaws.com/static/images/article1.be68295a7e40.png)

## Metadata
- Author: [[newsletter.banklesshq.com]]
- Full Title: Why DAOs Are the New Firms
- Category: #articles
- Document Tags: [[dao]] [[incentive]] [[org-design]] 
- URL: https://newsletter.banklesshq.com/p/why-daos-are-the-new-firms

## Highlights
- DAOs are not the first type of organization to tackle decentralized governance. In fact, many corporations are far more “decentralized” than we give them credit for.
- Decentralized Autonomous Organization (DAO), a form of social organization built on blockchains and smart contracts.
- Today I want to position DAOs within the historical development of the modern capitalist firm to better appreciate what these new social organizations are capable of on a logistical and economic scale.
- The economist Ronald Coase poignantly argued that firms exist for reasons of efficiency. Firms are a mode of organization that helps capitalists reduce the transaction costs of doing business i.e., using the market.
- The Coasean explanation was steeped in neoclassical economic thinking where firm owners were assumed to be operating as rational calculators (homo economicus) responding strictly to market incentives and performing lightning-fast cost-benefit analyses.
- Why the need to decentralize the firm? Building on Coase’s insight, later economists argued that there were two key driving forces of this structural decentralization into the M-shaped firm.
- The first sought to solve the constrained knowledge problems of planning that top managerial executives faced
- The second driving factor toward the M-shaped firm revolved around incentive problems. Employees within the U-shaped firm had little incentive to work harder or be entrepreneurial in their job scopes when remuneration was tied to a salaried paycheck
- Enabled by blockchains, DAOs are the next iteration in the continued decentralization of the modern capitalist firm
- The economic marvel of DAOs lies in how it so superbly aligns the incentives between work and reward
- Arthur Rock
- Rock pioneered the private limited partnership model that compensated upper management and junior employees with stock options, later becoming synonymous with Silicon Valley’s equity culture
- This model of “liberation capital” introduced high-powered incentives for workers and unlocked human talent
- DAOs extend this economic logic to every worker. Like gig economy workers, most DAOs offer a flexible “pay for work” model. Unlike gig economy workers, however, DAO workers are paid in native tokens (equity). DAOs, therefore, empower workers with the best of both worlds: flexibility and stakeholdership
