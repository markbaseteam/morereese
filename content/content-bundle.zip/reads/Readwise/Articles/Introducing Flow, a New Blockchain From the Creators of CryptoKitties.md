# Introducing Flow, a New Blockchain From the Creators of CryptoKitties

![rw-book-cover](https://readwise-assets.s3.amazonaws.com/static/images/article3.5c705a01b476.png)

## Metadata
- Author: [[Roham Gharegozlou]]
- Full Title: Introducing Flow, a New Blockchain From the Creators of CryptoKitties
- Category: #articles
- Document Tags: [[blockchain]] [[dapper-labs]] [[flow]] [[Proof-of-Stake]] 
- URL: https://medium.com/dapperlabs/introducing-flow-a-new-blockchain-from-the-creators-of-cryptokitties-d291282732f5

## Highlights
- Flow is a fast, secure, and developer-friendly blockchain built to support the next generation of games, apps, and the digital assets that will power them.
- Flow, a fast and developer-friendly blockchain built to support entire ecosystems of apps, games, and the digital assets that power them.
- financing from Andreessen Horowitz’s crypto fund and Accomplice as well as leading players in entertainment and crypto
- Flow has a pipelined architecture that separates the jobs typically done by a single node across five different node types
- cryptographic technique called Specialized Proofs of Confidential Knowledge (SPoCKs)
- Examples of experiences that can be powered by Flow include: artists or bands using crypto tokens to give millions of fans unprecedented new ways to show their fandom; games that reward players for adding value and enable assets and identities that users can take across infinite open environments; or platforms for sports fans around the world to trade verified, authentic, limited-edition digital memorabilia in real-time.
