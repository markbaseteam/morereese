# What Is a Security? The Howey Test and Reves Test

![rw-book-cover](https://readwise-assets.s3.amazonaws.com/static/images/article1.be68295a7e40.png)

## Metadata
- Author: [[Laura Anthony]]
- Full Title: What Is a Security? The Howey Test and Reves Test
- Category: #articles
- URL: https://securities-law-blog.com/2014/11/25/what-is-a-security-the-howey-test-and-reves-test/

## Highlights
- Securities Act of 1933, as amended (“Securities Act”).  Section 5 of the Securities Act
- Both the Securities Act and the Securities Exchange Act of 1934 (“Exchange Act”) contain definitions of a security.
- Section 2(a)(1) of the Securities Act defines a security as:
  The term “security” means any note, stock, treasury stock, security future, security-based swap, bond, debenture, evidence of indebtedness, certificate of interest or participation in any profit-sharing agreement, collateral-trust certificate, preorganization certificate or subscription, transferable share, investment contract, voting-trust certificate, certificate of deposit for a security, fractional undivided interest in oil, gas, or other mineral rights, any put, call, straddle, option, or privilege on any security, certificate of deposit, or group or index of securities (including any interest therein or based on the value thereof), or any put, call, straddle, option, or privilege entered into on a national securities exchange relating to foreign currency, or, in general, any interest or instrument commonly known as a “security”, or any certificate of interest or participation in, temporary or interim certificate for, receipt for, guarantee of, or warrant or right to subscribe to or purchase, any of the foregoing.
- Section 3(a)(10) of Exchange Act defines a security as:
  The term “security” means any note, stock, treasury stock, security future, security-based swap, bond, debenture, certificate of interest or participation in any profit-sharing agreement or in any oil, gas, or other mineral royalty or lease, any collateral-trust certificate, preorganization certificate or subscription, transferable share, investment contract, voting-trust certificate, certificate of deposit for a security, any put, call, straddle, option, or privilege on any security, certificate of deposit, or group or index of securities (including any interest therein or based on the value thereof), or any put, call, straddle, option, or privilege entered into on a national securities exchange relating to foreign currency, or in general, any instrument commonly known as a “security”; or any certificate of interest or participation in, temporary or interim certificate for, receipt for, or warrant or right to subscribe to or purchase, any of the foregoing; but shall not include currency or any note, draft, bill of exchange, or banker’s acceptance which has a maturity at the time of issuance of not exceeding nine months, exclusive of days of grace, or any renewal thereof the maturity of which is likewise limited.
- The landmark U.S. Supreme Court case interpreting the definition of an “investment contract” as a security is SEC v. W. J. Howey Co., 328 U.S. 293 (1946), the result of which has become commonly known as the “Howey Test.”
- Although the term “note” is specifically included in the statutory definition of a security, case law has determined that not every “note” is a security.
- The Exchange Act and SEC specifically exclude notes with a term of less than nine months, the proceeds of which are used for a current transaction, from the definition of a “security.”
- Relying on Howey, many courts developed an analysis based on the risk of the loan.  That is, the issue revolved around whether the lender had contributed “risk capital” subject to the entrepreneurial or managerial efforts of the borrower
- Under the “family resemblance” test, one must start with the presumption that a note is a security which presumption is rebutted if the note bears a resemblance to one of the enumerated categories on a judicially developed list of exceptions.  If the “note” does not bear a resemblance to an item on the list, the analysis continues to determine if a new category should be added to the list
