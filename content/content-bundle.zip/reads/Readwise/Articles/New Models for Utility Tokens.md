# New Models for Utility Tokens

![rw-book-cover](https://readwise-assets.s3.amazonaws.com/static/images/article2.74d541386bbf.png)

## Metadata
- Author: [[multicoin.capital]]
- Full Title: New Models for Utility Tokens
- Category: #articles
- URL: https://multicoin.capital/2018/02/13/new-models-utility-tokens/

## Highlights
- There are three types of cryptoassets: stores of value, security tokens, and utility tokens
- Proprietary payment currencies are, generally speaking, susceptible to the velocity problem, which will exert perpetual downwards price pressure
- The price of the utility token should increase approximately linearly with usage of the network.
- Of course, the corollary to this is that the price of the native token should decrease if usage of the network falls, or grows more slowly than previously forecast.
- In the work token model, a service provider stakes (AKA bonding) the native token of the network to earn the right to perform work for the network.
    - Tags: [[token-model]] [[work-token]] 
- The beauty of the work token model is that, absent any speculators, increased usage of the network will cause an increase in the price of the token. As demand for the service grows, more revenue will flow to service providers. Given a fixed supply of tokens, service providers will rationally pay more per token for the right to earn part of a growing cash flow stream.
- The valuation model for work tokens is simple: net present value (NPV)
- The work token model only works if the service being provided is a pure commodity.
- The work-token model is predicated on assigning new jobs to service providers based on their staked tokens. This is not amenable to service providers who must actively compete for customers. In these types of networks, another model is necessary.
- In the BME model, unlike the work token model, tokens are a proprietary payment currency. But unlike traditional proprietary payment currencies, users who want to use a service do not directly pay a counterparty to use the service. Rather, users burn tokens.
- Like the work token model, the BME model creates a model in which linear growth in usage of the network causes linear, non-speculative growth in the value of the token
- Given that work tokens capture far more value than BME tokens, teams should try to implement work tokens whenever possible. However, the work token is not universally applicable. Work tokens are applicable for most decentralized cloud services such as Filecoin, Keep, Truebit, and Livepeer. These services can use the work token model because they provide undifferentiated commodity services
- In systems using work-tokens, the unit price of the service needs to be set at the network level. Individual service providers cannot set pricing
- In systems implementing BME, every service provider can set her own price.
- Network effects for utility tokens are not based on liquidity of the token itself. They’re based on the intrinsic nature of the protocol
