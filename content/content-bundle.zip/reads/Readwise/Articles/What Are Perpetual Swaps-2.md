# What Are Perpetual Swaps?

![rw-book-cover](https://readwise-assets.s3.amazonaws.com/static/images/article1.be68295a7e40.png)

## Metadata
- Author: [[Aditya Palepu]]
- Full Title: What Are Perpetual Swaps?
- Category: #articles
- URL: https://medium.com/p/130236587df2

## Highlights
- For traders who want the benefits of derivatives, but don’t want to deal with the complexity of expiration dates, there’s another option, one that dominates the crypto markets: the perpetual swap.
- unlike futures contracts where the price can deviate from the spot underlying price (commonly referred to as basis), perpetual swaps should always be closely pegged to the underlying they track. This is accomplished with something called a “funding rate mechanism”
- profit = position_size * (current_price - entry_price)
  profit = 2 * (14,000 - 4,000)
  profit = 20,000
- Funding rates are the magic behind how perpetual swaps track the underlying asset’s spot price.
- when a perpetual swap has been trading above the price of the underlying, the funding rate will be positive. Long traders will pay short traders, thus disincentivizing buying and incentivizing selling, lowering the perpetual swap price to fall in line with the underlying asset.
- when a perpetual swap has been trading below the price of the underlying, the funding rate will be negative. Short traders will pay long traders, thus disincentivizing selling and incentivizing buying, raising the perpetual swap price to fall in line with the underlying asset.
- a perpetual swap fundamentally stays in line by balancing supply and demand by paying an interest rate.
- Perpetual swaps began as inversely settled futures, meaning that they were settled in crypto instead of USD
- Alice decides to purchase 20 BTC/USD perpetual swap contracts at a price of $10,000 each. She checks back 6 months later to find that Bitcoin is trading at $20,000. Excitedly, she decides to sell 20 BTC/USD perp swaps, thereby closing her position. Her profits would roughly be position_size * (close_price — average_entry_px) = 20 * (20,000 — 10,000), which equals $200,000. I say roughly because, keep in mind, during the 6 months she’s held the position, she will also gain/lose any funding rate related payments along the way
