# Japanese Philosopher Kojin Karatani Awarded the 2022 Berggruen Prize

![rw-book-cover](https://readwise-assets.s3.amazonaws.com/static/images/article0.00998d930354.png)

## Metadata
- Author: [[Nathan Gardels]]
- Full Title: Japanese Philosopher Kojin Karatani Awarded the 2022 Berggruen Prize
- Category: #articles
- URL: https://www.noemamag.com/japanese-philosopher-kojin-karatani-awarded-the-2022-berggruen-prize

## Highlights
- Kojin Karatani
- In Karatani’s sharpest departure from conventional wisdom, he locates the origins of philosophy not in Athens, but in the earlier Ionian culture that greatly influenced the so-called “pre-Socratic thinkers” such as Heraclitus and Parmenides.
- been named this year’s laureate for the $1 million Berggruen Prize for Culture and Philosophy
- Their ideas centered on the flux of constant change, in which “matter moves itself” without the gods, and the oneness of all being — a philosophical outlook closer to Daoist and Buddhist thought than to Plato’s later metaphysics, which posited that, as Karatani puts it, “the soul rules matter.”
