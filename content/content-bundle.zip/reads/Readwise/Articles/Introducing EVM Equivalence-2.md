# Introducing EVM Equivalence

![rw-book-cover](https://readwise-assets.s3.amazonaws.com/static/images/article2.74d541386bbf.png)

## Metadata
- Author: [[Optimism]]
- Full Title: Introducing EVM Equivalence
- Category: #articles
- URL: https://medium.com/p/5c2021deb306

## Highlights
- If you think of Ethereum as an almighty, decentralized court, then the core insight of L2 scalability is: “don’t go to court to cash a check — just go if the check bounces.”
