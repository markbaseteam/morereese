# IPv4 vs. IPv6: What’s the Difference?

![rw-book-cover](https://readwise-assets.s3.amazonaws.com/static/images/article3.5c705a01b476.png)

## Metadata
- Author: [[Andy Patrizio]]
- Full Title: IPv4 vs. IPv6: What’s the Difference?
- Category: #articles
- URL: https://www.avast.com/c-ipv4-vs-ipv6-addresses

## Highlights
- In the early days of the internet, it was necessary to know a website’s IP address in order to navigate to it. Then, the Domain Name Service (DNS) came along,
- IPv4 has a theoretical limit of 4.3 billion addresses, and in 1980, that was more than enough
- IPv6 uses 128-bit addresses, allowing for a theoretical 340,282,366,920,938,463,463,374,607,431,768,211,456, or 340 undecillion addresses.
- 2002:0de6:0001:0042:0100:8c2e:0370:7234,
- 5.62.42.77
- The advent of IPv6 brought more functionality, in addition to more IP addresses
