# For Annual Planning, Investing Beats Budgeting

![rw-book-cover](https://readwise-assets.s3.amazonaws.com/static/images/article0.00998d930354.png)

## Metadata
- Author: [[RobSolomon]]
- Full Title: For Annual Planning, Investing Beats Budgeting
- Category: #articles
- URL: https://corporate-rebels.com/annual-planning-investing-beats-budgeting/

## Highlights
- Zero-based budgeting, beyond budgeting, better budgeting, and activity-based budgeting are just a handful of the more recent and popular methodologies that strive to move past the traditional process in favor of something more dynamic. While they have their differences, the core concept underlying each is that planning should resemble an investing process.
- In 2019, we piloted “Mesh Fund” to arm ConsenSys with a modern budgeting process tailored to its unique org structure
