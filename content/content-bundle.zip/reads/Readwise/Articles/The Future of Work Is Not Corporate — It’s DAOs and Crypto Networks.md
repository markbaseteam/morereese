# The Future of Work Is Not Corporate — It’s DAOs and Crypto Networks

![rw-book-cover](https://readwise-assets.s3.amazonaws.com/static/images/article3.5c705a01b476.png)

## Metadata
- Author: [[Future]]
- Full Title: The Future of Work Is Not Corporate — It’s DAOs and Crypto Networks
- Category: #articles
- Document Tags: [[dao]] 
- URL: https://future.a16z.com/the-future-of-work-daos-crypto-networks/

## Highlights
- The traditional way to make money was “work-to-earn,” but the future of income is “x-to-earn” — play to earn, learn to earn, create to learn, and work to earn.
- will require new decentralized autonomous organizations (DAOs) that can coordinate all this new activity outside the context of corporate systems.
- In our world of complex information and orbital stakeholders, companies are no longer suited to help us coordinate our activity.
- Crypto networks create better alignment between participants, and DAOs will be the coordination layer for this new world.
- A DAO is an internet-native organization with core functions that are automated by smart contracts, and with people who do the things that automation cannot
- Core contributors: work-to-earn
- Bounty hunters: contribute-to-earn
- “Bounty Hunters” complete clearly defined work for an agreed upon price and / or duration of time.
- Core contributors are how we typically think of employees today — people focusing full-time on one (maybe 2-3 in some circumstances) project or organization.
- Network participants: participate-to-earn
- Play-to-earn
- Play-to-earn is a new type of gaming model that rewards players for playing and achieving within a game.
- Learn-to-earn
- Learn-to-earn is a new education model in which instead of paying to learn, a person is actually compensated for demonstrating that they have learned something.
- Create-to-earn
- Token holders: Invest-to-earn
- On-chain reputations will replace the way companies currently use credentials, resumes, and interview processes.
- X-to-earn is about rewarding value where it is created.
- truly global workforces with lower switching costs only increase these competitive dynamics.
