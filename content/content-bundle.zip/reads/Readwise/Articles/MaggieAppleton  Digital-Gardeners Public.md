# MaggieAppleton / Digital-Gardeners Public

![rw-book-cover](https://opengraph.githubassets.com/690604e2d4ba4ad353a4ee8e51469fd7ba0f33264dd2f39eb1025e04a5270e6c/MaggieAppleton/digital-gardeners)

## Metadata
- Author: [[MaggieAppleton]]
- Full Title: MaggieAppleton / Digital-Gardeners Public
- Category: #articles
- Document Tags: [[awesome-list]] [[digital-gardeners]] [[digital-gardening]] [[tools]] 
- URL: https://github.com/MaggieAppleton/digital-gardeners

## Highlights
- [Digital Garden Terms of Service](https://www.swyx.io/writing/digital-garden-tos/) by Shawn ([View Highlight](https://read.readwise.io/read/01grza45sr36yt5fzwjgjqjmwh))
