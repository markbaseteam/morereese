# Roadmaps - Linear Guide

![rw-book-cover](https://readwise-assets.s3.amazonaws.com/static/images/article4.6bc1851654a0.png)

## Metadata
- Author: [[Roadmap Details]]
- Full Title: Roadmaps - Linear Guide
- Category: #articles
- URL: https://linear.app/docs/roadmaps?noRedirect=1

## Highlights
- Roadmaps add a high-level structure that organizes projects in your workspace. ([View Highlight](https://read.readwise.io/read/01grf91p7jnt04fwyd86wwt403))
