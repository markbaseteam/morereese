# The Fifteen Fundamental Properties

![rw-book-cover](https://readwise-assets.s3.amazonaws.com/static/images/article0.00998d930354.png)

## Metadata
- Author: [[Chris Wage]]
- Full Title: The Fifteen Fundamental Properties
- Category: #articles
- URL: https://carcinisation.com/2015/04/01/the-fifteen-fundamental-properties/

## Highlights
- levels of scale
- strong centers
- boundaries
- theory of beauty as perceived by humans, conveyed in fifteen “fundamental properties.”
- alternating repetition
- positive space
- good shape
- local symmetries
- deep interlocking and ambiguity
- contrasts
- gradients
- roughness
- echoes
- the void
- simplicity and inner calm
- non-separateness
