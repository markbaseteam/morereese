# An Explanation of DAOstack in Fairly Simple Terms

![rw-book-cover](https://readwise-assets.s3.amazonaws.com/static/images/article0.00998d930354.png)

## Metadata
- Author: [[medium.com]]
- Full Title: An Explanation of DAOstack in Fairly Simple Terms
- Category: #articles
- Document Tags: [[definition-of-dao]] 
- URL: https://medium.com/daostack/an-explanation-of-daostack-in-fairly-simple-terms-1956e26b374

## Highlights
- DAOstack is an open-source software stack designed to support a global collaborative network
- Decentralized Autonomous Organizations. DAOs are organizations that run on peer-to-peer software backbones and empower groups of people to make non-hierarchical decisions about shared resources, like funds
- In a DAO, a network of peers encodes its protocols for decision-making into secure, decentralized software (in our case, smart contracts on the Ethereum blockchain). This software becomes the arbiter that tallies votes and carries out the will of the people
- if you’re going to coordinate a crowd effectively, you need technology not just for making proposals and tallying votes, but also for managing the collective attention
- Infra is the foundation layer of the stack. It houses the most basic, backend software modules for decentralized governance, such as voting machines and voting permissions systems like DAOstack’s Reputation system.
- ArcGraph is a caching layer based on The Graph that fetches, stores, and organizes information from the blockchain, enabling applications built on DAOstack to achieve fast load times.
- The first production-ready application built on the stack is Alchemy, an intuitive user interface for participating in DAO governance.
- The ArcHives will be a set of registries for the various types of modules in the stack–Arc contracts, applications, DAOs, and so on–registries that will be curated by the DAOstack community itself.
- GEN is a cryptocurrency that manages attention within the DAOstack ecosystem.
- holographic consensus
- holographic consensus
- holographic consensus
- This creates a dynamic we call holographic consensus.
- we want to point the incentive structures for everyone in the DAOstack ecosystem towards the improvement of that community. Using GEN, everyone in the ecosystem, from DAOs to voters to stakers, has a vested interest in DAOs becoming more useful and effective tools, because it is primarily through the improvement and prevalence of DAOs that GEN will gain in value
- DAOstack’s first governance templates implement voting rights using a system called Reputation
- Reputation is a score assigned to each user that represents that user’s voter power
- The Genesis DAO is the first DAO created using DAOstack
- The DAOstack project, at its essence, endeavors to use crypto-economics and other technologies to create moment-to-moment micro-incentives that, when multiplied across thousands of individuals and millions of moments, enable crowds to collaborate more resiliently and efficiently than any other system that has yet existed
