# The Pale King: An Unfinished Novel

![rw-book-cover](https://readwise-assets.s3.amazonaws.com/static/images/article4.6bc1851654a0.png)

## Metadata
- Author: [[David Foster Wallace]]
- Full Title: The Pale King: An Unfinished Novel
- Category: #articles
- URL: https://readwise.io/reader/document_raw_content/31901220

## Highlights
- It was true: The entire ball game, in terms of both the exam and life, was what you gave attention to vs. what you willed yourself to not ([View Highlight](https://read.readwise.io/read/01grde1a23vc6meg7kpkdvyww9))
- lashed past the window. Above and below were a different story, but there was always something disappointing about clouds when you were inside them; they ceased to be clouds at all. It just got really foggy. ([View Highlight](https://read.readwise.io/read/01grde1tdk9swdpys0yk28c888))
    - Tags: [[novel]] 
- Tedium is like stress but its own Category of Woe ([View Highlight](https://read.readwise.io/read/01grde2sksfthc54vvp2b5xbt6))
- Each car not only parked by a different human individual but conceived, designed, assembled from parts each one of which was designed and made, transported, sold, financed, purchased, and insured by human individuals, each with life stories and self-concepts that all fit together into a larger pattern of facts. ([View Highlight](https://read.readwise.io/read/01grde3rf0mv8n687zhde5nwfc))
- Fact: The birth agonies of the New IRS led to one of the great and terrible
  PR discoveries in modern democracy, which is that if sensitive issues of governance can be made sufficiently dull and arcane, there will be no need for officials to hide or dissemble, because no one not directly involved will pay enough attention to cause trouble. ([View Highlight](https://read.readwise.io/read/01grde6beww2p0v76bck3hcwcn))
- ‘Let me throw him off, Mr. G., I’m pleading with you.’ ‘Here’s something worth throwing out there. It was in the 1830s and ’40s
  that states started granting charters of incorporation to larger and regulated companies. And it was 1840 or ’41 that de Tocqueville published his book about Americans, and he says somewhere that one thing about democracies and their individualism is that they by their very nature corrode the citizen’s sense of true community, of having real true fellow citizens whose interests and concerns were the same as his. This is a kind of ghastly irony, if you think about it, since a form of government engineered to produce equality makes its citizens so individualistic and self-absorbed they end up as solipsists, navelgazers.’ ([View Highlight](https://read.readwise.io/read/01grde96h4g6s85yvmw6ghsthd))
- between the age of industrial democracy and the stage that comes after, where what industrial democracy was about was production and the economy depended on constantly increasing production and the democracy’s big tension was between industry’s needs for policies that abetted production and citizens’ needs to both benefit from all the production and still have their basic rights and interests protected from industry’s simpleminded emphasis on
  production and profits.’ ([View Highlight](https://read.readwise.io/read/01grde9y8n994vgpxp4zfyy7m7))
