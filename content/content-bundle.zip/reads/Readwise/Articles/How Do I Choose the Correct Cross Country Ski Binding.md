# How Do I Choose the Correct Cross Country Ski Binding?

![rw-book-cover](https://readwise-assets.s3.amazonaws.com/static/images/article2.74d541386bbf.png)

## Metadata
- Author: [[Moab Gear Trader]]
- Full Title: How Do I Choose the Correct Cross Country Ski Binding?
- Category: #articles
- URL: https://moabgeartrader.com/2020/02/08/choose-the-correct-cross-country-ski-bindings/

## Highlights
- Generally, there are three types of bindings used in cross country skiing. Three pin, SNS, and NNN. The most widely used are NNN and SNS.
