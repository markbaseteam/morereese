# Community Design : Town Halls and Event Planning

![rw-book-cover](https://readwise-assets.s3.amazonaws.com/static/images/article2.74d541386bbf.png)

## Metadata
- Author: [[Community Managers]]
- Full Title: Community Design : Town Halls and Event Planning
- Category: #articles
- URL: https://docs.google.com/document/u/0/d/1-L5XD0f87hClU_Lfkasy0P9ytORpLuSYbOVZmMuNrA4/mobilebasic

## Highlights
- When designing the agenda, it’s useful to think about slower starts, peaks in energy, and ends.
- Sample Evaluation Criteria Engagement during the event: Total Members at End / Total Members at Start Engagement post-event: Governance Participation within 24 hours of Town Hall Attendance: Total Attendees / Total Membership Awareness: Total Members Aware of Product Changes / Total Membership For example product engagement/awareness survey Awareness: RTs and Engagements on Twitter / Weekly email opens / Engagement in post-event discord message
