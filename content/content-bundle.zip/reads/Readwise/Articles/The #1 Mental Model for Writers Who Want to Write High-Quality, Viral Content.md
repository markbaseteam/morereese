# The #1 Mental Model for Writers Who Want to Write High-Quality, Viral Content

![rw-book-cover](https://readwise-assets.s3.amazonaws.com/static/images/article2.74d541386bbf.png)

## Metadata
- Author: [[Michael Simmons]]
- Full Title: The #1 Mental Model for Writers Who Want to Write High-Quality, Viral Content
- Category: #articles
- Document Tags: [[mental-models]] 
- URL: https://medium.com/accelerated-intelligence/the-1-mental-model-for-writers-who-want-to-write-high-quality-viral-content-43ecf0d4ec05

## Highlights
- “I write because I don’t know what I think until I read what I say.”
    - Tags: [[favorite]] [[broadcast2hightlights]] [[writing]] 
