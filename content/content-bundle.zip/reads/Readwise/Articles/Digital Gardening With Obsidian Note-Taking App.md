# Digital Gardening With Obsidian Note-Taking App

![rw-book-cover](https://miro.medium.com/max/534/1*Wfzm1_2EgEDAIP_34SfXAA.png)

## Metadata
- Author: [[Project Eme]]
- Full Title: Digital Gardening With Obsidian Note-Taking App
- Category: #articles
- URL: https://projecteme.medium.com/digital-gardening-with-obsidian-8f7ccc044466

## Highlights
- One of the key principles of digital gardening is to focus on the process of learning and creation, rather than the end product. It’s about tending to your online space by planting seeds of ideas and watching them evolve over time. You can allow your interests and passions to guide your content, and let your website or blog become a reflection of who you are and what you care about. ([View Highlight](https://read.readwise.io/read/01grjdkzn6f5t3exh0fcb0enbt))
    - Tags: [[digital-gardening]] 
