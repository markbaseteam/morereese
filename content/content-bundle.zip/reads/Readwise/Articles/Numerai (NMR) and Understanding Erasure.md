# Numerai (NMR) and Understanding Erasure

![rw-book-cover](https://readwise-assets.s3.amazonaws.com/static/images/article3.5c705a01b476.png)

## Metadata
- Author: [[Pragati Shrivastava]]
- Full Title: Numerai (NMR) and Understanding Erasure
- Category: #articles
- URL: https://cryptotradernews.com/cryptocurrency/numerai-nmr-and-understanding-erasure/

## Highlights
- Numerai plans to bring Web3 to every application on the internet.
- Kazutsugi
- Erasure is a peer to peer, decentralized data marketplace for predictions that allow individuals to sell predictions that everyone can put their trust in.
- Proof of Existence
- Erasure uses IPFS, a decentralized file storage network, where data is stored in a feed
