# How to DAO 202: Using Town Halls to Sow the Seeds of Community

![rw-book-cover](https://readwise-assets.s3.amazonaws.com/static/images/article4.6bc1851654a0.png)

## Metadata
- Author: [[creators.mirror.xyz]]
- Full Title: How to DAO 202: Using Town Halls to Sow the Seeds of Community
- Category: #articles
- Document Tags: [[dao]] 
- URL: https://creators.mirror.xyz/AjUaG6IgbS9qxuNimZvgsjtgLJw2GHAJcZLkhnTkLK0

## Highlights
- Part 1: Set Objectives Part 2: Design the Agenda Part 3: Outline a Seasonal Program Part 4: Develop an Event Logistics Checklist Part 5: Study the Town Halls of Other DAOs for Improvement Part 6: Setting Yourself Up for Success
- The following are four examples of good objectives for a DAO town hall: Inform Excite Engage Support
- Meetings in digital communities should be composable, accessible asynchronously, and non-mandatory.
- When designing the agenda, it’s useful to think about slower starts, peaks in energy, and ends.
- Sample Content Agenda (1 Hour) Pre-Event Announce event on Twitter and Discord Promote event and explain the agenda in the weekly newsletter Invite people to add the event to their calendar Re-announce event on social media 10 minutes prior to start Event Transition intro visual and music into screenshare of meeting summary Recap the previous week and engage members as they arrive Give specific guild-by-guild updates and facilitate discussion Introduce main topics of discussion, as well as guest-speakers Gauge community pulse through asking for responses every 3-5 minutes Address open governance items Facilitate an Open Q&A Conclude with a group action item for the week Post-Event Sum up the event in a blog post Do a Twitter thread summary and link to blog post Send out a summary in the Newsletter with link to blog and thread Post a summary on Discord with links to all of the above Host ad-hoc Twitter Spaces or Discord lounges as necessary
- Logistics Checklist Time (e.g. which time-zone coverage will the town hall have?) Cadence (Weekly, Fortnightly, Monthly) Type (Community Building, Ops Documentation, Entertainment, Showcase, other/mixed) Attendee Scope (Members only, open to everyone, combination) Voice Channel (Discord Stage, Voice Channel, Zoom Call, Twitter Spaces, Clubhouse) Visual Sharing (Discord Screen Share, Zoom, Figma Jam) Chatting Channel (Discord Text Channel, Zoom Chat, Figma Chat) Content Design (Knowledge Management Software (e.g. Clarity, Roam, Docs) vs. Slide Presentation vs. None) Facilitators (1 person, team, contributors, special guests) Easter-eggs / Interaction Design (Yes / No) Intro / Outro Music (Yes / No) Recording process (e.g. upload to YouTube or community file)
