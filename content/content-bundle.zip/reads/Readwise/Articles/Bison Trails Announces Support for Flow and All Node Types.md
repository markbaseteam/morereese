# Bison Trails Announces Support for Flow and All Node Types

![rw-book-cover](https://readwise-assets.s3.amazonaws.com/static/images/article4.6bc1851654a0.png)

## Metadata
- Author: [[Bison Trails]]
- Full Title: Bison Trails Announces Support for Flow and All Node Types
- Category: #articles
- Document Tags: [[flow]] 
- URL: https://bisontrails.co/flow-protocol-all-nodes-types/

## Highlights
- The consensus process is separate from the compute process on Flow, with four node types splitting the work of maintaining, securing, and progressing the chain.
- Collection Nodes are placed in cooperating Clusters by the protocol to collectively manage the transaction pool and collect valid transactions to propose to Consensus Nodes.
- Consensus Nodes form and propose blocks using the HotStuff consensus algorithm to create a globally consistent chain of blocks. They have minimal bandwidth and computation requirements, which makes it easier for anyone to participate in consensus.
- Execution Nodes execute transactions and maintain the Execution State, a cryptographically-verifiable data store for all user accounts and smart contract states. They also respond to queries related to the Execution State. This work requires the Execution Nodes to be most resource-intensive on the network. It is also the key reason Flow can improve its scale and efficiency without sharding.
  Because of the significant hardware requirements to run these nodes, they are the least accessible option for participating as a Validator. However, with relatively few Execution Nodes doing the work, the rewards per node are expected to be high.
- Verification Nodes confirm the work done by Execution Nodes is correct. Although each individual Verification Node only checks a small amount of the total computation, collectively the nodes check every computation several times in parallel.
