# Process People

![rw-book-cover](https://readwise-assets.s3.amazonaws.com/static/images/article0.00998d930354.png)

## Metadata
- Author: [[Marty Cagan]]
- Full Title: Process People
- Category: #articles
- URL: http://www.svpg.com/process-people

## Highlights
- Makers definitely include your designers and your engineers, and supporting roles like user research and data analysts. Makers design and build the products we love, so most people understand the critical contribution of makers.
  Managers definitely include the managers of designers, engineers, and product managers. Managers are primarily responsible for the staffing and coaching of the makers, so most people understand their importance, especially if you’re a maker fortunate enough to work for a manager committed to helping you progress in your career. ([View Highlight](https://read.readwise.io/read/01grgy5x9kvetxaqdnhpj0mnh9))
    - Tags: [[product]] [[maker-manager]] 
- As Jeff Bezos warns, “Good process serves you so you can serve customers. But if you’re not watchful, the process can become the thing. This can happen very easily in large organizations.**”** ([View Highlight](https://read.readwise.io/read/01grgy9hd5q3jtq62k8fnnhjh6))
    - Tags: [[jeff-bezos]] [[process]] 
