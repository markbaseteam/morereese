# Acting US Comptroller Hsu Says He's Looking to the Lessons of 2008 for Crypto Regulation

![rw-book-cover](https://readwise-assets.s3.amazonaws.com/static/images/article3.5c705a01b476.png)

## Metadata
- Author: [[Time pressure]]
- Full Title: Acting US Comptroller Hsu Says He's Looking to the Lessons of 2008 for Crypto Regulation
- Category: #articles
- URL: https://cryptonews.net/en/news/regulation/1755707/

## Highlights
- Acting Comptroller of the Currency Michael Hsu says he's looking to the past to find the tools to regulate the crypto industry.
