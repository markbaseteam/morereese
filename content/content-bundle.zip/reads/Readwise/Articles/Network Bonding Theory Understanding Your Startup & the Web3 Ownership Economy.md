# Network Bonding Theory: Understanding Your Startup & the Web3 Ownership Economy

![rw-book-cover](https://readwise-assets.s3.amazonaws.com/static/images/article4.6bc1851654a0.png)

## Metadata
- Author: [[nfx.com]]
- Full Title: Network Bonding Theory: Understanding Your Startup & the Web3 Ownership Economy
- Category: #articles
- URL: https://www.nfx.com/post/network-bonding-theory/

## Highlights
- uld be a direct network, market network, marketplace network, platform network, etc so it can produce network effects among your users/customers.
- , the product of your startup should be a direct network, market network, marketplace network, platform network, etc so it can produce network effects among your users/customers.
- Every person or asset you bring to a startup network is bonding to that network in an implicit mathematical equation.
