# The Invisible Work of Community

![rw-book-cover](https://readwise-assets.s3.amazonaws.com/static/images/article1.be68295a7e40.png)

## Metadata
- Author: [[Dennison Bertram]]
- Full Title: The Invisible Work of Community
- Category: #articles
- URL: https://medium.com/p/e37c5ed14699

## Highlights
- Initially, this work is emotionally rewarding for many members. There is the enthusiasm of a launch or drop, the excitement from working together with “fellow degens” to deploy smart contracts or setup channels
- “Soft fudders”
- While tooling and best practices can go a long way to addressing the issues outlined above, perhaps the most useful first step for contributors is to better understand their role in a decentralized organization.
    - Tags: [[dao-contributor]] 
- Being a volunteer, contributor, or builder in an open decentralized community is an inherently political position.
