# SEC v Crypto, the Checkmate

![rw-book-cover](https://readwise-assets.s3.amazonaws.com/static/images/article3.5c705a01b476.png)

## Metadata
- Author: [[EDITORIAL]]
- Full Title: SEC v Crypto, the Checkmate
- Category: #articles
- URL: https://www.trustnodes.com/2021/09/15/sec-v-crypto-the-checkmate

## Highlights
- Asked directly by Senator Pat Toomey whether stablecoins are a security, Gensler said “they may be.” Toomey pushed back to say the Howey test for what is a security has the requirement of expectations for gain, there is obviously no such expectation when it comes to something like USDc.
- there’s obviously a big difference between a demand note and a stablecoin. Stablecoins are tokenized actual dollars, they are not effectively corporate bonds that pay interest to the public for the public lending the company money to fund its operations
- engaging politics is not optional, at least not until we have a state of peace without emergency powers and we have a restoration of functioning checks and balances
- By the letter of the law, bitcoin is illegal because no one may issue a currency except the Federal Reserve Banks. This monopolistic claim on monetary power, however, is unenforcable because bitcoin does not have someone or some group you can arrest and so shut it all down.
- there is only one test, and it is not a Howey test or a Reves test, but this test:
  “Is the project so decentralized that you can not arrest or fine an individual or a group controlling the project to shut it down?”
- if your project is not decentralized and you are in US, you might have to register with SEC. If it is largely decentralized but you want to start off with some training wheels to mitigate any potential bugs, either go to Europe for a few years and launch from there or go Nakamoto style
