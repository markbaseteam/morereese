# The Cartoon Guide to Perps

![rw-book-cover](https://readwise-assets.s3.amazonaws.com/static/images/article1.be68295a7e40.png)

## Metadata
- Author: [[paradigm.xyz]]
- Full Title: The Cartoon Guide to Perps
- Category: #articles
- Document Tags: [[perps]] 
- URL: https://www.paradigm.xyz/2021/03/the-cartoon-guide-to-perps/

## Highlights
- In this post, I’ll share what I learned: four very different (but mathematically identical) mental models for what perps are, how they work, and when they don’t.
- A perp’s value at any given time is represented by its mark price.
- When the index price and mark price are the same, the perp is worth the same as the underlier, and all is as it should be.
- When the index price and the mark price diverge, the system transfers a funding fee between those who are long the perp (have bought it) and those who are short the perp (have sold it). In our example perp, the funding fee paid by the longs to the shorts is $(mark price – index price) per contract per day. When this number is negative, the shorts pay the longs
- Traders must also put down collateral, known as margin.
