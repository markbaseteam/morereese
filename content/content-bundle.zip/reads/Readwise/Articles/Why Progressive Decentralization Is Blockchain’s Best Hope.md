# Why Progressive Decentralization Is Blockchain’s Best Hope

![rw-book-cover](https://readwise-assets.s3.amazonaws.com/static/images/article3.5c705a01b476.png)

## Metadata
- Author: [[Arthur Câmara]]
- Full Title: Why Progressive Decentralization Is Blockchain’s Best Hope
- Category: #articles
- Document Tags: [[>unread]] 
- URL: https://www.freecodecamp.org/news/why-progressive-decentralization-is-blockchains-best-hope-31a497f2673b/

## Highlights
- “Progressive decentralization” is really an umbrella encompassing many strategies, mechanisms, and tools to make building on the blockchain more viable.
- Immutability, the inability to be edited, is at once the blockchain’s greatest strength and its largest barrier to meaningful adoption.
- Simply put, progressive decentralization advocates easing into decentralization in stages rather than diving in headfirst. What that looks like is building mechanisms into smart contracts that confer special powers to the creators up front, then incrementally lock those powers away in a transparent and systematic way.
