# Breaking Into Web3 as a PM

![rw-book-cover](https://readwise-assets.s3.amazonaws.com/static/images/article2.74d541386bbf.png)

## Metadata
- Author: [[Peter Yang]]
- Full Title: Breaking Into Web3 as a PM
- Category: #articles
- URL: https://creatoreconomy.so/p/breaking-into-web3-as-a-pm

## Highlights
- I’ve found that user needs often don’t align with business needs in web2
- My advice is to treat your web3 job search like being a founder.
- In web3, it’s less about “I want a PM job” and more about “this company has X, Y, Z needs that I can help with.”
