# SEC Issues Investigative Report Concluding DAO Tokens, a Digital Asset, Were Securities

![rw-book-cover](https://readwise-assets.s3.amazonaws.com/static/images/article4.6bc1851654a0.png)

## Metadata
- Author: [[The SEC's]]
- Full Title: SEC Issues Investigative Report Concluding DAO Tokens, a Digital Asset, Were Securities
- Category: #articles
- Document Tags: [[sec]] [[securities-law]] [[the-dao]] 
- URL: https://www.sec.gov/news/press-release/2017-131

## Highlights
- The SEC's Report of Investigation found that tokens offered and sold by a "virtual" organization known as "The DAO" were securities and therefore subject to the federal securities laws.
