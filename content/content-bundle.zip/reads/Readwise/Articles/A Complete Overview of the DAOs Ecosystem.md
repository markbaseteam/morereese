# A Complete Overview of the DAOs Ecosystem

![rw-book-cover](https://readwise-assets.s3.amazonaws.com/static/images/article0.00998d930354.png)

## Metadata
- Author: [[Will Kendall]]
- Full Title: A Complete Overview of the DAOs Ecosystem
- Category: #articles
- Document Tags: [[aave]] [[compound]] [[dao]] [[flamingo]] [[forefront]] [[maker]] [[moloch]] [[pubdao]] [[uniswap]] [[upsteam]] 
- URL: https://coinmarketcap.com/alexandria/article/a-complete-overview-of-the-daos-ecosystem

## Highlights
- DeFi DAOs
- Anyone with an Ethereum address can submit a proposal to change the protocol, but only MKR governance token holders can vote on new proposals.
- By holding UNI tokens, you can vote on proposed changes to the protocol. Token holders who don’t wish to submit proposals or vote on proposals submitted by others can delegate their tokens to other users.
- DAO Operating Systems
- Upstream aims to give founders and creators a much easier time building their own DAOs by integrating the entire DAO tech stack into one place, rather than spreading all of the community’s resources out over multiple apps, DApps and platforms
- Syndicate is building the tools to make building DAOs, as well as finding and connecting into new DAOs, much easier for everyone.
- DAOstack’s toolkit was designed for maximum scalability, which enables newly created DAOs to link in with existing DAOs. And as the network of DAOs grows, all its member organizations will benefit from an innovative and collaborative network.
- Moloch wants to coordinate funding for open-source infrastructure on the Ethereum blockchain which, without a DAO structure in place designed to address this problem, probably wouldn’t happen.
- Pleasr is experimenting with fractional asset ownership, which will allow it to blend DeFi with community ownership and digital art
- Neptune members pool their capital and vote on which DeFi protocols to supply liquidity to. The community is full of members who have been involved with Ethereum and DeFi since the early days. This liquidity is provided by the DAO as a both a service to the DeFi space and an investment for the DAOs members
- The DAO describes its principal service as “translating crypto and DeFi for the world.”
- Forefront is a community DAO focused on creating and curating resources for the social token community.
