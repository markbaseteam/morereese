# Hong Kong and Singapore Take Different Approaches to Regulating Digital Assets

![rw-book-cover](https://readwise-assets.s3.amazonaws.com/static/images/article4.6bc1851654a0.png)

## Metadata
- Author: [[Sam Reynolds]]
- Full Title: Hong Kong and Singapore Take Different Approaches to Regulating Digital Assets
- Category: #articles
- URL: https://blockworks.co/hong-kong-and-singapore-take-different-approaches-to-regulating-digital-assets/

## Highlights
- The difference in regulatory approaches between Hong Kong and Singapore begins with how the two Cities define digital assets — in Hong Kong they are called Virtual Assets while in Singapore they are known as Payment Tokens — and thus the regulators that would supervise the market.
