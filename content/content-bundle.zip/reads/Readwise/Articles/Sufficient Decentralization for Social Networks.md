# Sufficient Decentralization for Social Networks

![rw-book-cover](https://readwise-assets.s3.amazonaws.com/static/images/article3.5c705a01b476.png)

## Metadata
- Author: [[Varun Srinivasan]]
- Full Title: Sufficient Decentralization for Social Networks
- Category: #articles
- URL: https://www.varunsrinivasan.com//2022/01/11/sufficient-decentralization-for-social-networks

## Highlights
- decentralizing access ensures that they can’t be monopolistic and ignore users
