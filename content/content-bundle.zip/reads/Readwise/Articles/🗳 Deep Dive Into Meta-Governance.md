# 🗳 Deep Dive Into Meta-Governance

![rw-book-cover](https://readwise-assets.s3.amazonaws.com/static/images/article3.5c705a01b476.png)

## Metadata
- Author: [[Nate Parton]]
- Full Title: 🗳 Deep Dive Into Meta-Governance
- Category: #articles
- URL: https://medium.com/p/cdabadb650dd

## Highlights
- High participation costs are a key driver of voter apathy.
