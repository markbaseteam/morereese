# Lands of Lorecraft

![rw-book-cover](https://readwise-assets.s3.amazonaws.com/static/images/article3.5c705a01b476.png)

## Metadata
- Author: [[Venkatesh Rao]]
- Full Title: Lands of Lorecraft
- Category: #articles
- URL: https://studio.ribbonfarm.com/p/lands-of-lorecraft

## Highlights
- lorecraft
- lorecraft has emerged from the internet itself, rather than from a particular geography
- lorecraft is the evil twin of marketing.
  Specifically:
  Marketing is the story insiders tell outsiders to influence them in some way
  Lore is the story insiders tell themselves to manage their own psyches
- Lore is something you witness, and attempt to shape as it emerges, if it emerges, not something you design and execute.
- When “HR” to you mainly means a bunch of cloud apps rather than Toby from The Office, when even your boss is potentially an app streaming tasks and bounties at you rather than a person, when your world of work does not exist in the reality distortion field of a Steve Jobs, but in the inanimate reality distortion field of a stack of cobbled together SaaS tools, you end up thinking very differently about traditional questions of supervision, authority, tasking, and coordination.
