# The Ultimate List of ERC Standards You Need to Know

![rw-book-cover](https://readwise-assets.s3.amazonaws.com/static/images/article4.6bc1851654a0.png)

## Metadata
- Author: [[Facebook]]
- Full Title: The Ultimate List of ERC Standards You Need to Know
- Category: #articles
- Document Tags: [[erc-1155]] [[erc-165]] [[erc-20]] [[erc-223]] [[erc-721]] [[erc-777]] [[erc-824]] [[erc-827]] [[erc-865]] [[erc-884]] [[ethereum]] [[token]] 
- URL: https://101blockchains.com/erc-standards/

## Highlights
- ERC 20 standard – The Most Popular Token Standard
- ERC 165 – The Supporting Pillar of ERC 721
- This is really a standard for a method, instead of tokens.
- While all contracts can interact with ERC 20 tokens, it’s different from other ERC standards for tokens, like ERC 721. Smart co ntracts
- ERC 165 standardizes a method for this, besides standardizing the identification of interfaces.
- ERC 721 – The Standard for Non Fungible Tokens
- A smart contract that will interact with ERC 721 tokens must implement a separate interface, and hence it needs to follow the ERC 165 standard.
- ERC 223 – Solves the ‘Token Loss’ Issues of the ERC20
- If you send ERC 20 tokens to smart contracts that can’t handle tokens, this action burns the tokens, and you can’t recover them. ERC 223 proposes to prevent this.
- It specifies functions that a contract can code so that if it can’t accept tokens, the transfer will fail. This doesn’t burn any token!
- ERC 621 – Can Modify the Total Token Supply
- An extension to ERC 20, this standard is to increase or decrease total token supply using two functions, i.e., ‘increaseSupply’, and ‘decreaseSupply’.
- ERC 777 – Reduces Friction in Crypto Transactions
- OpenZeppelin has already implemented ERC777 to build, automate, and operate decentralized applications.
- ERC 827 – Enables Token Transfer for A 3rd Party to Spend It
- ERC 884 – Tokenizes Stock
- ERC 1155 – The Most Advanced Non Fungible Token
- For ERC 1155, users can create multiple tokens in a single contract. Also, you can use ERC-1155 for the fungible and non-fungible use cases. All of these traits make ERC1155 better at storage management, efficient, and budget-friendly
