# Lonely Surfaces: On AI-generated Images

![rw-book-cover](https://readwise-assets.s3.amazonaws.com/static/images/article4.6bc1851654a0.png)

## Metadata
- Author: [[L. M. Sacasas]]
- Full Title: Lonely Surfaces: On AI-generated Images
- Category: #articles
- URL: https://theconvivialsociety.substack.com/p/lonely-surfaces-on-ai-generated-images

## Highlights
- “Art is dead, dude. It’s over. AI won. Humans lost.”
- “when people’s imaginative energy is replaced by the drop-down menu ‘creativity’ of big tech platforms, on a mass scale, we are facing a particularly dire form of immiseration.”
- By immiseration, I’m thinking of the late philosopher Bernard Stiegler’s coinage, “symbolic misery”—the disaffection produced by a life that has been packaged for, and sold to, us by commercial superpowers. When industrial technology is applied to aesthetics, “conditioning,” as Stiegler writes, “substitutes for experience.”
