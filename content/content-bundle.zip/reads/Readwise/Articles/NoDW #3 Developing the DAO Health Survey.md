# NoDW #3: Developing the DAO Health Survey

![rw-book-cover](https://readwise-assets.s3.amazonaws.com/static/images/article4.6bc1851654a0.png)

## Metadata
- Author: [[K]]
- Full Title: NoDW #3: Developing the DAO Health Survey
- Category: #articles
- Document Tags: [[dao]] [[definition-of-dao]] [[org-design]] 
- URL: https://talentdao.substack.com/p/nodw-3-developing-the-dao-health

## Highlights
- a DAO is a network of contributors coordinating in dynamic virtual teams toward a shared purpose by decentralizing authority and ownership.
    - Tags: [[dao]] [[definition-of]] 
- operational definition of DAO Health: The DAO's ability to coordinate teams toward a shared vision and objectives as a function of the contributor socio-psychological factors that drive collective productivity, performance, leadership, and individual experience and well-being.
