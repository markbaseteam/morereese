# A Comparison Between 5 Major Blockchain Protocols

![rw-book-cover](https://readwise-assets.s3.amazonaws.com/static/images/article3.5c705a01b476.png)

## Metadata
- Author: [[edChain]]
- Full Title: A Comparison Between 5 Major Blockchain Protocols
- Category: #articles
- URL: https://medium.com/p/b8a6a46f8b1f

## Highlights
- ‘Nodes’, i.e. computers on the network, maintain a shared version of truth. ‘Blocks’, i.e. block records are linked via a predetermined protocol
