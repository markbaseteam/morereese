# Ethereum Traces, Not Transactions

![rw-book-cover](https://readwise-assets.s3.amazonaws.com/static/images/article2.74d541386bbf.png)

## Metadata
- Author: [[Surya Rastogi]]
- Full Title: Ethereum Traces, Not Transactions
- Category: #articles
- URL: https://medium.com/@theimperialduke/ethereum-traces-not-transactions-3f0533d26aa

## Highlights
- Transactions can trigger smaller atomic actions that modify the internal state of the EVM. Information about the execution of these actions is logged and can be found stored as an EVM execution trace, or just a trace.
    - Tags: [[evm]] 
- three main trace types (call, create, suicide)
