# July 2021 Newsletter: Record Household Equity Exposure

![rw-book-cover](https://readwise-assets.s3.amazonaws.com/static/images/article1.be68295a7e40.png)

## Metadata
- Author: [[lynalden.com]]
- Full Title: July 2021 Newsletter: Record Household Equity Exposure
- Category: #articles
- URL: https://www.lynalden.com/july-2021-newsletter/

## Highlights
- fiscal-driven inflation (like what occurred in the 1940s) differs quite a bit from loan-driven inflation (like what occurred in the 1970s)
- folks holding cash in a bank, or holding government bonds, are gradually losing purchasing power on their holdings, since the interest rates aren’t keeping up with inflation
- holders of paper assets are losing value, and that policy roadmap of fiscal-driven inflation accompanied by low bond yields is playing out
- It’s also important to separate deep supply bottlenecks from surface-layer ones
- Semiconductor bottlenecks are a “deeper” type of supply constraint than, say, sawmill capacity. It requires many billions of dollars, and plenty of time, to construct new semiconductor foundries.
- I’m structurally bullish on energy in general, but I’m seeing the Delta virus variant and government lockdown responses to it as a near-term risk factor for a correction in the industry.
- When stocks are cheap and households have low stock exposure, stocks tend to do very well from that point.
