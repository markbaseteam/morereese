# What Are Digital Gardens?

![rw-book-cover](https://i0.wp.com/cagrimmett.com/wp-content/uploads/2022/02/cropped-CleanShot-2022-02-02-at-07.00.33@2x.png?fit=512%2C512&ssl=1)

## Metadata
- Author: [[Chuck Grimmett]]
- Full Title: What Are Digital Gardens?
- Category: #articles
- URL: https://cagrimmett.com/ideas/2020/11/08/what-are-digital-gardens/

## Highlights
- to link, annotate, change, summarize, copy, and share — these are the verbs of gardening ([View Highlight](https://read.readwise.io/read/01gs342sea15vwbwnr39mfpy5w))
    - Tags: [[digital-gardening]] 
- [Maggie Appleton](https://href.li/?https://maggieappleton.com/), [Tom Critchlow](https://href.li/?https://t.co/JB96byanIP?amp=1), [Anne-Laure Le Cunff](https://twitter.com/anthilemoon), [Venkatesh Rao](https://href.li/?https://www.ribbonfarm.com/), [Andy Matuschak](https://twitter.com/andy_matuschak), [Anna Gát](https://href.li/?https://www.annagat.com/), and [Joel Hooks](https://href.li/?https://joelhooks.com/digital-garden). ([View Highlight](https://read.readwise.io/read/01gs343e4qph2t1cweryn9etjx))
    - Tags: [[digital-gardeners]] 
