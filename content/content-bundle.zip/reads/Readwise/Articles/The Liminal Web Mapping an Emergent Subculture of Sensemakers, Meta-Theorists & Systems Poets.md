# The Liminal Web: Mapping an Emergent Subculture of Sensemakers, Meta-Theorists & Systems Poets

![rw-book-cover](https://readwise-assets.s3.amazonaws.com/static/images/article4.6bc1851654a0.png)

## Metadata
- Author: [[joelightfoot.org]]
- Full Title: The Liminal Web: Mapping an Emergent Subculture of Sensemakers, Meta-Theorists & Systems Poets
- Category: #articles
- URL: https://www.joelightfoot.org/post/the-liminal-web-mapping-an-emergent-subculture-of-sensemakers-meta-theorists-systems-poets

## Highlights
- The Liminal Web is made up of a collection of individuals who often have a long history of feeling as if they don’t wholly belong in any particularly scene or space, as such they tend to hold onto any sense of group identification quite lightly.
- The Liminal Web is a collection of thinkers, writers, theorists, podcasters, videographers and community builders who all share a high crossover in their collection of perspectives on the world. It not only includes creators of content but also the people and communities who resonate with the constellation of ideas such creators put forward.
