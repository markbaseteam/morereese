# *Big Shout Out to James Waugh, Cooper Turley, Eva Beylin, Drew Harding, Garrett MacDonald, James Young and Alex Masmej for Editing and Adding to the Paper

![rw-book-cover](https://readwise-assets.s3.amazonaws.com/static/images/article2.74d541386bbf.png)

## Metadata
- Author: [[CI/CD & Automation]]
- Full Title: *Big Shout Out to James Waugh, Cooper Turley, Eva Beylin, Drew Harding, Garrett MacDonald, James Young and Alex Masmej for Editing and Adding to the Paper
- Category: #articles
- Document Tags: [[dao]] [[metacartel]] 
- URL: https://github.com/metacartel/MCV/blob/master/MCV-Whitepaper.md

## Highlights
- DAOs coordinate components of the soft human-facing layer of crypto: money, social capital, reputation and attention; they give power to individuals upon crowd consensus, and are inherently a political tool
- "If you want to go fast, go alone. If you want to go far, go together."
- In this paper, we explore the concept of MetaCartel Ventures, a for-profit investment DAO coupled with a legal entity.
- ​​MetaCartel Ventures (MCV) is a for-profit DAO created by the MetaCartel community for the purposes of making investments into early-stage Decentralized Applications (DApps).
- The technology half of MCV will consist of an instance of the Moloch v2 smart contract standard and the legal half consisting a member-managed Delaware limited liability company governed primarily by the Grimoire (the "Limited Liability Company Agreement") and the statutes of the Delaware Limited Liability Company Act.
- As more projects penetrate viable markets, make business model breakthroughs, and discover UX innovations, we believe the Ethereum application layer will prove to become the leading venture ecosystem to focus on.
- MetaCartel believes that we will likely see another highly profitable cryptonative asset class emerge. "The next big thing will likely start out looking like a toy." --- Chris Dixon
- The DAO's "Grimoire", a Limited Liability Company Agreement, that constitutes a voluntary, legally binding agreement among the members of the DAO
- The Delaware Limited Liability Company Act, which is a statute (set of laws) determining the default governance rules and meta-rules for LLCs formed in Delaware.
- The Grimoire constitutes a pact among MCV's members. Meanwhile, the Delaware Limited Liability Company Act prescribes meta-rules about how that pact should be written and interpreted.
- when a person follows the on-chain procedures for acquiring DAO shares from MCV's smart contracts (specifically, Moloch.sol), the person will also legally become a member of MCV, with rights and obligations determined by the terms of the Grimoire and the Delaware Limited Liability Company Act.
- all DAO members are recognised as managing members of the LLC and will have full economic, informational and governance rights in the LLC.
- Mages are DAO members that are considered to be actively participating in the members' shared management efforts
- Goblins are DAO members that may choose not to exercise such rights and powers to the same extent as Mages do, despite legally having all the same managerial rights and powers under the Grimoire.
- Many past DAO projects, touting the principle of "code is law", have abandoned legal structuring altogether and sought to defer all legal results to the operation of software. This approach has been described as "absolute code deference."
- "qualified code deference."
- Proposals are of two types: ordinary and extraordinary.
- Ordinary proposals include membership admission, membership expulsion, proposed payments to service providers, and proposed investments in other projects.
- projects. Ordinary proposals are handled entirely on-chain through MCV's Moloch.sol smart contract. They must be sponsored by an existing member, but may be proposed by anyone through Moloch.sol. The outcome of ordinary proposals is decided by a majority of the votes cast on the proposal, with no quorum requirement.
- Ordinary proposals are handled entirely on-chain through MCV's Moloch.sol smart contract. They must be sponsored by an existing member, but may be proposed by anyone through Moloch.sol. The outcome of ordinary proposals is decided by a majority of the votes cast on the proposal, with no quorum requirement.
- Extraordinary proposals pertain to MCV's meta-rules and cannot be handled purely on-chain. If such a proposal is made on-chain and approved without the requisite legal formalities, it will be invalid and will not be honored, and the members responsible should be expelled. Extraordinary proposals require approval by 69% of MCV's then-current shares. Examples of extraordinary proposals include any proposal to amend the Grimoire in any material respect (aside from specified exceptions), sell more than 50% of MCV's investment assets to a third party, merge MCV as an LLC with or into another business entity, acquire a majority of the assets or securities of another business entity / organization or commence or participate in any legal proceeding.
- RageTokens": Freely trading payment tokens such as ETH and DAI; and
- "RageClaims": Non-transferable, personal, economic tokens that represents the exiting DAO member's remaining economic pro rata claim to the DAO's future income from the revenue-generating assets the DAO holds at the time of the member's exit.
- GuildBank: The DAO smart contract (GuildBank.sol) manages the tokens of the DAO
- Claims token contracts (ERC-1843) are smart contracts that allocate claims on the future revenue that is deposited into the claims token contracts via specific ERC-20 tokens
- Assets are of two types: cash and cash equivalents, which in most cases will be tradable cryptonative tokens ("RageTokens"), or revenue-generating assets ("RageClaims")
- In the Moloch v2 smart contracts, there are 8 proposal types which must pass a voting and grace period, similar to Moloch v1, including
- Membership admission proposals
- Membership expulsion (GuildKick) proposals
