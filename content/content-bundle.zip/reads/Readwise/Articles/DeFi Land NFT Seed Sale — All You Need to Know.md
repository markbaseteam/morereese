# DeFi Land NFT Seed Sale — All You Need to Know

![rw-book-cover](https://readwise-assets.s3.amazonaws.com/static/images/article4.6bc1851654a0.png)

## Metadata
- Author: [[DeFi Land]]
- Full Title: DeFi Land NFT Seed Sale — All You Need to Know
- Category: #articles
- Document Tags: [[play-to-earn]] [[solana-ecosystem]] 
- URL: https://defiland.medium.com/defi-land-nft-seed-sale-all-you-need-to-know-733728b9a1cd

## Highlights
- February 8th, 2500 DeFi Land Seed NFTs will be dropped through the Magic Eden platform.
