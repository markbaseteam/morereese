# WIP: The Case for Sharing Your Work in Public

![rw-book-cover](https://nesslabs.com/wp-content/uploads/2019/11/work-in-public-banner.png)

## Metadata
- Author: [[Anne-Laure Le Cunff]]
- Full Title: WIP: The Case for Sharing Your Work in Public
- Category: #articles
- URL: https://nesslabs.com/work-in-public

## Highlights
- Working in public means sharing your process and challenges, rather than just the final product. ([View Highlight](https://read.readwise.io/read/01grz9bnqhf0jb3xgwqpzk6nc9))
