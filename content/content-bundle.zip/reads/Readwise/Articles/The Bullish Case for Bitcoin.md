# The Bullish Case for Bitcoin

![rw-book-cover](https://readwise-assets.s3.amazonaws.com/static/images/article3.5c705a01b476.png)

## Metadata
- Author: [[vijayboyapati.medium.com]]
- Full Title: The Bullish Case for Bitcoin
- Category: #articles
- Document Tags: [[bitcoin]] [[in-depth]] [[mental-model]] [[monetary-policy]] [[money]] 
- URL: https://vijayboyapati.medium.com/the-bullish-case-for-bitcoin-6ecc8bdecc1

## Highlights
- Bitcoins fall into an entirely different category of goods, known as monetary goods, whose value is set game-theoretically. I.e., each market participant values the good based on their appraisal of whether and how much other participants will value it.
- Collectibles served as a sort of “proto-money” by making trade possible between otherwise antagonistic tribes and by allowing wealth to be transferred between generations.
- Early man faced an important game-theoretic dilemma when deciding which collectibles to gather or create: which objects would be desired by other humans?
- The key attribute that makes Bitcoin valuable for proscribed activities is that it is “permissionless” at the network level.
- Furthermore, the Lindy effect suggests that the longer Bitcoin remains in existence the greater society’s confidence that it will continue to exist long into the future
- India’s Gold Control Act
- time when most of the world converged on a single store of value — gold — and this period saw the greatest explosion of trade in the history of the world
- Using modern terminology, money always evolves in the following four stages:
- No one alive has seen the real-time monetization of a good (as is taking place with Bitcoin), so there is precious little experience regarding the path this monetization will take.
- The difference between the purchasing power of a monetary good and the exchange-value it could command for its inherent usefulness can be thought of as a “monetary premium”. As a monetary good transitions through the stages of monetization (listed in the section above), the monetary premium will increase.
- The price of a monetary good is not a reflection of its cash flow or how useful it is but, rather, is a measure of how widely adopted it has become for the various roles of money.
- on the Speculative Bitcoin Adoption/Price Theory,
- Since the inception of the first exchange traded price in 2010, the Bitcoin market has witnessed four major Gartner hype cycles.
- It is worth observing that the rise in Bitcoin’s price during the aforementioned hype cycles was largely correlated with an increase in liquidity and the ease with which investors could purchase bitcoins.
- Bitcoin’s final Gartner hype cycle will begin when nation-states start accumulating it as a part of their foreign currency reserves.
- Unfortunately, it will probably be the states with the strongest executive powers — dictatorships such as North Korea — that will move the fastest in accumulating bitcoins.
- When a nation’s money is abandoned and replaced by Bitcoin, Bitcoin will have transitioned from being a store of value in that society to a generally accepted medium of exchange. Daniel Krawisz coined the term “hyperbitcoinization” to describe this process.
- A network effect — the increased value of using Bitcoin simply because it is already the dominant network — is a feature in and of itself. For any technology that possesses a network effect, it is by far the most important feature.
- An important rule can be gleaned from the major forks that have happened to both the Bitcoin and Ethereum networks. The majority of the market capitalization will settle on the network that retains the highest-calibre and most active developer community.
- Bitcoin is an incipient money that is transitioning from the collectible stage of monetization to becoming a store of value.
