# A Proof of Stake Design Philosophy

![rw-book-cover](https://readwise-assets.s3.amazonaws.com/static/images/article4.6bc1851654a0.png)

## Metadata
- Author: [[Vitalik Buterin]]
- Full Title: A Proof of Stake Design Philosophy
- Category: #articles
- Document Tags: [[ethereum]] [[Proof-of-Stake]] 
- URL: https://medium.com/@VitalikButerin/a-proof-of-stake-design-philosophy-506585978d51

## Highlights
- Casper consensus
- cryptography is one of the very few fields where adversarial conflict continues to heavily favor the defender
- The “cypherpunk spirit” isn’t just about idealism; making systems that are easier to defend than they are to attack is also simply sound engineering
- proof of work necessarily operates on a logic of massive power incentivized into existence by massive rewards
- Proof of stake breaks this symmetry by relying not on rewards for security, but rather penalties
- The “one-sentence philosophy” of proof of stake is thus not “security comes from burning energy”, but rather “security comes from putting up economic value-at-loss”.
- individuals’ moral forbearances and communication inefficiencies will often raise the cost of an attack to levels much higher than the nominal protocol-defined value-at-loss
- It is important to have both layers of defense: economic incentives to discourage centralized cartels from acting anti-socially, and anti-centralization incentives to discourage cartels from forming in the first place
- These cryptoeconomic networks come in many flavors — ASIC-based PoW, GPU-based PoW, naive PoS, delegated PoS, hopefully soon Casper PoS — and each of these flavors inevitably comes with its own underlying philosophy.
