# High-Level Overview

![rw-book-cover](https://readwise-assets.s3.amazonaws.com/static/images/article1.be68295a7e40.png)

## Metadata
- Author: [[Cookie Policy]]
- Full Title: High-Level Overview
- Category: #articles
- Document Tags: [[band]] 
- URL: https://docs.bandchain.org/introduction/overview.html

## Highlights
- Band Protocol is a cross-chain data oracle that aggregates and connects real-world data and APIs to smart contracts.
- The protocol is built on top of BandChain, a Cosmos-SDK based blockchain designed to be compatible with most smart contract and blockchain development frameworks.
