# The Five-Point Palm Exploding DAO Technique

![rw-book-cover](https://readwise-assets.s3.amazonaws.com/static/images/article0.00998d930354.png)

## Metadata
- Author: [[anisha.mirror.xyz]]
- Full Title: The Five-Point Palm Exploding DAO Technique
- Category: #articles
- Document Tags: [[minimum-viable-dao]] 
- URL: https://anisha.mirror.xyz/a1yabGHM1sASV9Jubugi1D3mh4BQ-cirTaoVbLmqx80

## Highlights
- The first formal DAO, called “The DAO” was formed in April 2016
- MVD, or Minimum Viable DAO
- These are five broadly applicable concepts to consider. North Star — What is the one liner purpose for this DAO? Centralized vs. Decentralized — Can your DAO truly function in a decentralized manner to achieve your North Star goal? Logistics — have you identified the logistics that need to be handled to accomplish your North Star goal? Are they feasible? Narrative — what are you pitching your community and what is the narrative that will bring DAO members together? Why is the DAO doing what it’s doing? Lifespan — is this looking to be a DAO that exists for 2 months, a year, or forever?
- Sit down by yourself or your other core team members and strip away all the noise. What is the high signal message or purpose you’re trying to communicate. WHY are you trying to creating a DAO, WHAT is it meant for? Adjust to make sure it’s not too broad or narrow. That’s your North Star.
- If you really think about it, you should instinctively know whether a decentralized or more centralized structure is most likely needed to accomplish that North Star vision.
- North Star — What is the one liner purpose for this DAO? Centralized vs. Decentralized — Can your DAO truly function in a decentralized manner to achieve your North Star goal? Logistics — have you identified the logistics that need to be handled to accomplish your North Star goal? Are they feasible? Narrative — what are you pitching your community and what is the narrative that will bring DAO members together? Why is the DAO doing what it’s doing? Lifespan — is this looking to be a DAO that exists for 2 months, a year, or forever?
