# Cinneamhain Ventures Is an Activist Venture Firm, Investing in the Blockchain Space as a Single Unified Technology Rather Than Zero-Sum Products.

![rw-book-cover](https://readwise-assets.s3.amazonaws.com/static/images/article2.74d541386bbf.png)

## Metadata
- Author: [[Adam Cochran]]
- Full Title: Cinneamhain Ventures Is an Activist Venture Firm, Investing in the Blockchain Space as a Single Unified Technology Rather Than Zero-Sum Products.
- Category: #articles
- URL: https://cehv.com/cehvs-blockchain-osi-model-thesis/

## Highlights
- “The Internet” as most users know it is actually an open source collection of protocols and standards that we can represent collectively in the “Open Systems Interconnection Model.”
    - Tags: [[broadcast2hightlights]] 
- three operational sectors in which most of the value extraction takes place.
  We can divide these into:
  Enabler Sectors
  Standards Sectors
  Interaction Sectors
- Enabler sectors are the necessary evils of the OSI stack. They are the core pieces of any protocol that make communication and interactivity possible, and their needed in order to enable anything higher up in the stack. These are primarily made up of the physicals, data link and network layers. Because these layers are ultimately a gatekeeper to a larger end goal, they create immense value capture.
- In the Standards Sectors, revenue is driven by creating a uniform standard of adoption and building ancillary services around that.
  One of the best examples of this is companies creating document standards (like Adobe’s PDF) and building a company around them.
- Each layer is also improved and expanded in scope by the robustness of layers below it.
- For example, the Presentation Layer of the blockchain OSI model is a series of set standards that allow us to build various Application Layer products and Interaction Layer tools because they are open sourced and pre-defined, and do not require a permissioned model which would allow companies to monopolize these tools
- The physical layer of the stack is where unique physical architecture is created and either connects us directly in a peer-to-peer fashion, or helps capture data from our physical world and process it into data higher in the stack
- The Data Link layer can best be thought of as the software of the Physical layer. While it often runs on distinct hardware (mining units for blockchains or hubs/routers for the internet) the goal of the Data Link layer is to provide the connectivity and procedural logic for transmitting data between entities, and in turn catching any errors that take place at the physical layer
- The Network layer aims to connect any two physical nodes of a network by correctly routing information
- The Micro-Network Layer
- The Macro-Network Layer
- The Information layer is the set of standards, procedures and protocols of how we index, store and sort information
- The Processing layer of the OSI stack, is one of the broadest and most diverse in terms of its specific end goals.
  If we think of blockchains as one unified network like the internet, then the systems that exist at the Processing layer are the specialized hardware on which we operate
- The goal of the Presentation layer is to create systematic standards of how we encode and interpret information
- The Software layer creates tools that we use to develop, deploy and manage Application or Interaction layer programs, often using existing Presentation layer standards to do so
- The Application layer is where most users interact with actual programs that use collections of the underlying protocols.
  These end user applications are the first layer that exist without their primary purpose being the enablement of opportunities above them in the stack
- The Interaction layer are specific software tool sets that allow users to easily interact with applications, or sometimes even lower stack level protocols
- The Platform layer is one that hasn’t yet been captured in the blockchain space. It will be the platforms that make it trivial for others to build new lower stack solutions, or applications that solve either builder problems or consumer problem opportunities
- Some would argue that in the classic web, the most valuable Platform businesses are Microsoft Azure or Amazon AWS, and I think that is true from a raw revenue perspective.
  I think in terms of adding the most value to the internet as a whole, the winner is WordPress, who made it easy for anyone to start a website.
- a settlement layer is a universal truth, finality and security. That is something that doesn’t exist in the classic internet.
- no one ever buys a light bulb because they love light bulbs. They buy it because they have a good book they want to read in the dark.
  Right now, the blockchain space is a bunch of light bulb enthusiasts arguing about who has the best filament and no one is selling books.
