# What I Wish I Knew Before Talking to Lawyers About DAOs

![rw-book-cover](https://readwise-assets.s3.amazonaws.com/static/images/article0.00998d930354.png)

## Metadata
- Author: [[mirror.xyz]]
- Full Title: What I Wish I Knew Before Talking to Lawyers About DAOs
- Category: #articles
- Document Tags: [[dao]] [[legal]] [[legal-structure]] 
- URL: https://mirror.xyz/0x954888B7a5C6736F4955dF18B556D8328FD02f61/5K9llACK4tzu5WHL68CM3bBsmSleL_XxJ2kRGYnwp7A

## Highlights
- Two core concepts to mention going into this are Legal Liability and Tax Protection
- There are five general options for how to legally structure your DAO:
  Don’t set up an entity at all.
  US based LLC.
  Offshore Foundation.
  Onshore Foundation.
  Some combination of the above.
- Not having an entity at all for the DAO creates three massive risk factors:
- No incorporation = unlimited liability.
- No incorporation = crazy tax burdens.
- No incorporation = no interaction with the real world.
- an onshore Foundation can be “ownerless”, which will reduce the founding team’s legal liability if things go sideways
- primary countries to look at for Onshore foundations are Switzerland (where they are technically called “Associations”) and Singapore.
- “Offshore” here refers to the opposite of Onshore, in that you create a Foundation somewhere that is tax neutral.
  The three major options here are Panama, the British Virgin Islands, and the Cayman Islands.
- the most common approach I’ve seen is actually to mix and match. Typically this means creating a Foundation that is the official legal wrapper of the “DAO” and a separate, wholly unrelated, “Development Agency” (DA) onshore somewhere. This DA is incorporated as an LLC or local equivalent and is registered as a normal non-crypto entity.
  A common path is the Cayman Foundation + a Singapore entity.
- Here’s how it works: the DAO has the treasury. Typically, the treasury is held in a multi-sig wallet that “belongs” to the DAO. The DAO/Foundation should also have a business account with an exchange like FTX to provide a fiat off-ramp should you need to pay lawyers, accountants, etc in meatspace.
  The DA pays the leadership team and all associated expenses for the DAO. The Foundation has a Service agreement with the DA and pays accordingly. If, for example, there were $100,000 in expenses, the Foundation may send $120,000 to the DA. The DA then pays taxes on the $20k of profit, ensuring that you are paying taxes somewhere as mentioned at the beginning of this essay. In this fashion, the dual structure seems to provide the ideal balance of Legal Liability and Tax Protection.
- Roles in a Cayman Foundation
- Every Foundation must have at least one Director, Supervisor, and Secretary. These can be human beings or corporate entities, and the same entity can be both Director and Secretary if desired
- In short, the best approach is to create a separate entity to issue the token to bottle up some of the legal liability. This is typically achieved by creating an offshore private company that is entirely owned by your offshore Foundation
