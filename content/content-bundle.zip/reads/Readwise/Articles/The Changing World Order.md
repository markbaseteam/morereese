# The Changing World Order

![rw-book-cover](https://readwise-assets.s3.amazonaws.com/static/images/article4.6bc1851654a0.png)

## Metadata
- Author: [[Ray Dalio]]
- Full Title: The Changing World Order
- Category: #articles
- Document Tags: [[>unread]] 
- URL: https://www.linkedin.com/pulse/changing-world-order-ray-dalio-1f

## Highlights
- to develop an understanding of what is happening now and might happen over the next few years, I needed to study the mechanics be- hind similar cases in history—e.g., the 1930–45 period, the rise and fall of the Dutch and British empires, the rise and fall of Chinese dynasties, and others.
- This Big Cycle produces swings between 1) peaceful and prosperous periods of great creativity and productivity that raise living standards a lot and 2) depression, revolution, and war periods when there is a lot of fighting over wealth and power and a lot of destruction of wealth, life, and other things we cherish. I
- there are long- term debt cycles that last about 100 years and short-term debt cycles that last about eight years.
- one’s ability to anticipate and deal well with the future depends on one’s understanding of the cause/effect relationships that make things change, and one’s ability to understand these cause/effect relationships comes from studying how they have changed in the past
- On a Sunday night—August 15, 1971—President Richard Nixon announced that the US would renege on its promise to allow paper dollars to be turned in for gold.
- Studying money and credit cycles throughout history made me aware of the long-term debt and capital markets cycle (which typically lasts about 50 to 100 years), which has led me to view what is happening now in a very different way than if I hadn’t gained that perspective.
- debt that is denominated in the world’s reserve currency (i.e., US dollar-denominated debt now) is the most fundamental building block for the world’s capital markets and the world’s economies
- printing money and buying financial assets (now called “quantitative easing”) also widens the wealth gap because buying financial assets pushes up their prices, which benefits the wealthy who hold more financial assets than the poor do
- I saw that the great empires typically lasted roughly 250 years, give or take 150 years, with big economic, debt, and political cycles within them lasting about 50 to 100 years.
