# The Web3 Curation Landscape

![rw-book-cover](https://readwise-assets.s3.amazonaws.com/static/images/article2.74d541386bbf.png)

## Metadata
- Author: [[jo7.mirror.xyz]]
- Full Title: The Web3 Curation Landscape
- Category: #articles
- URL: https://jo7.mirror.xyz/UVZNJa__GXzd5dl6LSVXvapqPvpupKg4W6iiZqaug4w

## Highlights
- general heuristics and themes emerging in this nascent space: Spatial projects are pushing the boundaries of experience Large marketplaces are giving way to curated marketplaces Story and feed-based tools are improving discovery
- Teams building in the “Discovery” sector of the curation space seek to enable the process of finding and learning about creators and their works
