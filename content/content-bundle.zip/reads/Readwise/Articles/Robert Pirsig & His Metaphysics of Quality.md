# Robert Pirsig & His Metaphysics of Quality

![rw-book-cover](https://readwise-assets.s3.amazonaws.com/static/images/article0.00998d930354.png)

## Metadata
- Author: [[philosophynow.org]]
- Full Title: Robert Pirsig & His Metaphysics of Quality
- Category: #articles
- Document Tags: [[essay]] [[moq]] [[philosophy]] [[pirsig]] [[zamm]] 
- URL: https://philosophynow.org/issues/122/Robert_Pirsig_and_His_Metaphysics_of_Quality

## Highlights
- This is one of the primary reasons Zen & the Art of Motorcycle Maintenance was written. It gives us, amongst other things, a rational framework (or ‘static latch’) to underpin the hippy ideals of peace, love, artistic creativity and personal freedom.
- As a new lecturer, he noticed that he was under legal contract to teach ‘quality’ to his students, even though it was not made clear by the college authorities what was meant by this term. Pirsig soon realised that teachers had been passing and failing students on the quality of their work for centuries without any viable definition of what ‘quality’ actually was.
- It is worth emphasising here that ‘subjects’ and ‘objects’ are intellectual concepts, rather than concepts derived from experience. Unfortunately, these concepts have been ingrained in us from an early age, so we generally accept their validity without question. But this is basically just a metaphysical convention. Pirsig would say that reality can be divided up metaphysically in numerous ways: it’s just that some ways are better than 
  So instead of dividing everything into subjects and objects, Pirsig divides reality into Dynamic Quality (this is capitalised deliberately) and static quality.
- the Buddha can’t tell you what Dynamic Quality is, but he can point a way so that you can experience it for yourself, and then you might understand.
- “It’s important to keep all ‘concepts’ out of Dynamic Quality. Concepts are always static. Once they get into Dynamic Quality they’ll overrun it and try to present it as some kind of a concept itself…
- The MOQ is truly empirical. Science is not. Classical science starts with a concept of the objective world – atoms and molecules – as the ultimate reality. This concept is certainly supported by empirical observation but it is not the empirical observation itself.
- Pirsig asserts that Dynamic Quality refers to what Buddhists would call ‘unconditioned reality’, and static quality refers to ‘conditioned reality’ – more commonly known by the Buddhists as ‘the everyday world’:
- Although Pirsig recognises that each level of static patterns has emerged from the one below, each level follows its own rules. The physical laws such as gravitational attraction (inorganic) evolve relatively slowly; whereas the laws of the jungle (biology), co-operation between animals (society), and the ideas of freedom and rights (intellect) evolve relatively fast. It is important to note that the laws of the four static levels often clash: compare adultery (biological good) vs. family stability (social good).
- my PhD, at www.robertpirsig.org/PhD.html
- the strength of the Metaphysics of Quality is its ability to incorporate the ‘indeterminate absolute’ within a coherent, scientifically-oriented paradigm
