# Uniswap: A Good Deal for Liquidity Providers?

![rw-book-cover](https://readwise-assets.s3.amazonaws.com/static/images/article2.74d541386bbf.png)

## Metadata
- Author: [[Pintail]]
- Full Title: Uniswap: A Good Deal for Liquidity Providers?
- Category: #articles
- URL: https://medium.com/p/104c0b6816f2

## Highlights
- divergence_loss = 2 * sqrt(price_ratio) / (1+price_ratio) — 1
- So the actual return for liquidity providers is a balance between the divergence loss caused by the price differential and the accumulated fees from trades on the exchange.
