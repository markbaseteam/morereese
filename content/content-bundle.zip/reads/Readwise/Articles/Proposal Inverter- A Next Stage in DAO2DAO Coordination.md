# Proposal Inverter- A Next Stage in DAO2DAO Coordination

![rw-book-cover](https://readwise-assets.s3.amazonaws.com/static/images/article0.00998d930354.png)

## Metadata
- Author: [[mirror.xyz]]
- Full Title: Proposal Inverter- A Next Stage in DAO2DAO Coordination
- Category: #articles
- URL: https://mirror.xyz/0x0966262125B5E01B5D77B862830a341419BC2872/y-aaFWpbogZt5jWGqu6sVlOG-fKh0p-5V6l2o01yyy0

## Highlights
- a proposal inverter is defined as: “. . . a funding primitive that enables multiple groups or individuals to collaborate on common proposals. It reduces (1) the administrative overhead of coordinating payment processes between funders and contributors (especially in the case of collaborative funding) and (2) allows funding flow to persist as long as the proposal inverter is sufficiently funded. The aim of the proposal inverter is to facilitate communications & transactions between contributors and funders”
