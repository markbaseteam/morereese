# The Graph Network in Depth

![rw-book-cover](https://readwise-assets.s3.amazonaws.com/static/images/article3.5c705a01b476.png)

## Metadata
- Author: [[Graph Node]]
- Full Title: The Graph Network in Depth
- Category: #articles
- Document Tags: [[grt]] 
- URL: https://thegraph.com/blog/the-graph-network-in-depth-part-1

## Highlights
- The mission of The Graph is to enable internet applications that are entirely powered by public infrastructure.
- it’s critical that we shift from a paradigm of businesses paying for the ongoing storage, compute, and other services required to keep an application running, toward users directly paying networks of decentralized service providers for granular usage of these resources.
- The Graph Network decentralizes the API and query layer of the internet application stack.
- Consumers. Consumers pay Indexers for queries. These will typically be end users but could also be web services or middleware that integrate with The Graph.
- Indexers. Indexers are the node operators of The Graph. They are motivated by earning financial rewards.
- Delegators. Delegators put GRT at stake on behalf of an Indexer in order to earn a portion of indexer rewards and fees, without having to personally run a Graph Node. They are financially motivated.
- The query market serves a similar purpose to an API in a traditional cloud-based application—efficiently serving data required by a front end running on a user’s device. The key difference is that whereas a traditional API is operated by a single economic entity that users have no say over, the query market comprises a decentralized network of Indexers, all competing to provide the best service at the best price.
- The query market serves a similar purpose to an API in a traditional cloud-based application—efficiently serving data required by a front end running on a user’s device.
- Indexer Staking. Indexers deposit Graph Tokens to be discoverable in the query market and to provide economic security for the work they are performing.
- Curator Signaling. Curators deposit Graph Tokens in a curation market, where they are rewarded for correctly predicting which subgraphs will be valuable to the network.
