# Vitalik Buterin Wants Your Passport as NFT-like Soulbound Token on the Blockchain

![rw-book-cover](https://readwise-assets.s3.amazonaws.com/static/images/article2.74d541386bbf.png)

## Metadata
- Author: [[Jade Gao]]
- Full Title: Vitalik Buterin Wants Your Passport as NFT-like Soulbound Token on the Blockchain
- Category: #articles
- Document Tags: [[learn-pod]] [[pubdao]] [[soulbound-tokens]] 
- URL: https://dappradar.com/blog/vitalik-buterin-wants-your-passport-as-nft-like-soulbound-token-on-the-blockchain

## Highlights
- Ultimately the SBT concept could make your passport, medical data, or diplomas into Soulbound tokens.
- the current web3 life revolves mainly around the financial aspect
- SBT is like the credit system we have been using in real-world finance, but SBT can be used as a multi-dimensional social scoring standard
- Empower uncollateralized lending with a credit score system
- Make DAOs Sybil-attack-resistant
- A DeSoc where every identity is verifiable but still private
