# Bonding Curve

![rw-book-cover](https://readwise-assets.s3.amazonaws.com/static/images/article4.6bc1851654a0.png)

## Metadata
- Author: [[Full definition]]
- Full Title: Bonding Curve
- Category: #articles
- URL: https://coinmarketcap.com/alexandria/glossary/bonding-curve

## Highlights
- A bonding curve is a mathematical concept used to describe the relationship between price and the supply of an asset.
- The basis of the bonding curve is the idea that when a person purchases an asset that is available in a limited quantity (like Bitcoin), then each subsequent buyer will have to pay slightly more for it.
