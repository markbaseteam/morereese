# The LAO Joins Forces With Moloch DAO and MetaCartel to Begin to Standardize DAO-Related Smart…

![rw-book-cover](https://readwise-assets.s3.amazonaws.com/static/images/article3.5c705a01b476.png)

## Metadata
- Author: [[medium.com]]
- Full Title: The LAO Joins Forces With Moloch DAO and MetaCartel to Begin to Standardize DAO-Related Smart…
- Category: #articles
- URL: https://medium.com/@thelaoofficial/the-lao-joins-forces-with-moloch-dao-and-metacartel-to-begin-to-standardize-dao-related-smart-b6ee4b0db071

## Highlights
- Moloch DAO, OpenLaw, and MetaCartel have been working on extensions to the initial Moloch DAO code in order to power next-generation LAOs — limited liability autonomous organizations — which would enable DAOs to engage in a greater range of for-profit ventures.
- organizational primitives; simple smart contracts that enabled groups of people to pool assets, collectively vote, and direct assets to third parties.
