# Eurodollar

![rw-book-cover](https://readwise-assets.s3.amazonaws.com/static/images/article4.6bc1851654a0.png)

## Metadata
- Author: [[CFI Team]]
- Full Title: Eurodollar
- Category: #articles
- URL: https://corporatefinanceinstitute.com/resources/knowledge/finance/eurodollar/

## Highlights
- A Eurodollar refers to a time deposit account that is denominated in U.S. dollars and held in foreign banks.
- The Eurocurrency market encompasses the entire money market for currencies that exist in foreign countries.
- From an umbrella perspective, the eurocurrency market is responsible for the external lending and borrowing of the world’s most convertible currencies, such as the dollar and pound sterling.
