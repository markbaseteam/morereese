# What Is a Light Client and Why You Should Care?

![rw-book-cover](https://readwise-assets.s3.amazonaws.com/static/images/article0.00998d930354.png)

## Metadata
- Author: [[parity.io]]
- Full Title: What Is a Light Client and Why You Should Care?
- Category: #articles
- URL: https://www.parity.io/blog/what-is-a-light-client/

## Highlights
- A client in computer science is a piece of hardware or software that connects to a server.
- Because all these clients talk to each other, they form a network where each client is a node. This is the reason why the term node is also used in place of client.
- Metamask, MyEtherWallet, and MyCrypto connect to a remote node by default but still allow users to connect to their own local node if they wish to. This is not the case of the Jaxx or Exodus wallets, which connect to a remote node by default with no option of connecting to a user’s own local node.
- A light client or light node is a piece of software that connects to full nodes to interact with the blockchain.
- A light client or light node is a piece of software that connects to full nodes to interact with the blockchain.
- light client or light node is a piece of software that connects to full nodes to interact with the blockchain
- light clients do not interact directly with the blockchain; they instead use full nodes as intermediaries. Light clients rely on full nodes for many operations, from requesting the latest headers to asking for the balance of an account
- Miners are full nodes attached to a specific software.
- The light client does not need to trust the full node for every request that it makes to the full node. This is because the block headers contain a piece of information called the Merkle tree root. The Merkle tree root is like a fingerprint of all information on the blockchain about account balances and smart contract storage.
- As light clients need to send several requests to do simple operations, the overall network bandwidth needed is higher than that of a full node. On the other hand, the amount of resources and storage needed is several orders of magnitude lower than that of a full node while achieving a very high level of security.
- Full node incentivization by light clients is an active area of research, as the incentivization is key to the ecosystem’s stability.
- Individual users might want to run a full node because it is the most secure way to interact with the blockchain. At a much smaller scale, they might also do it by pure altruism to help the network. Running a full node 24/7 requires a good level of knowledge and resources that most users are understandably not willing to invest. Except for miners, there is no built-in incentive to run a full node despite this piece of infrastructure being critical to the network.
