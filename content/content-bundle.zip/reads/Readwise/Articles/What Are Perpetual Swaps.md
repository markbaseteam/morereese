# What Are Perpetual Swaps?

![rw-book-cover](https://readwise-assets.s3.amazonaws.com/static/images/article4.6bc1851654a0.png)

## Metadata
- Author: [[medium.com]]
- Full Title: What Are Perpetual Swaps?
- Category: #articles
- Document Tags: [[perps]] 
- URL: https://medium.com/derivadex/what-are-perpetual-swaps-130236587df2

## Highlights
- Perpetual swaps are derivatives that let you buy or sell the value of something (that something is usually called an “underlying asset”) with several advantages: 1) there is no expiry date to your position (i.e., you can hold it as long as you want), 2) the underlying asset itself is never traded (meaning no custody issues), and 3) the swap price closely tracks the price of the underlying asset, and 4) it’s easy to short.
    - Tags: [[perpetual-swaps]] 
- Unlike the futures and options markets, perpetual swaps do not expire and do not have a settlement date, meaning you can hold your position forever.
- Unlike the spot markets, the underlying asset is never involved directly, so you can gain exposure to an asset’s price movements without having to actually hold or borrow the asset itself. And lastly, unlike futures contracts where the price can deviate from the spot underlying price (commonly referred to as basis), perpetual swaps should always be closely pegged to the underlying they track. This is accomplished with something called a “funding rate mechanism”
- profit = position_size * (current_price - entry_price) profit = 2 * (14,000 - 4,000) profit = 20,000
- when a perpetual swap has been trading above the price of the underlying, the funding rate will be positive. Long traders will pay short traders, thus disincentivizing buying and incentivizing selling, lowering the perpetual swap price to fall in line with the underlying asset.
- when a perpetual swap has been trading below the price of the underlying, the funding rate will be negative. Short traders will pay long traders, thus disincentivizing selling and incentivizing buying, raising the perpetual swap price to fall in line with the underlying asset.
