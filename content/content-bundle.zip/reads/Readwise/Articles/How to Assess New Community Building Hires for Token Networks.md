# How to Assess New Community Building Hires for Token Networks

![rw-book-cover](https://readwise-assets.s3.amazonaws.com/static/images/article3.5c705a01b476.png)

## Metadata
- Author: [[medium.com]]
- Full Title: How to Assess New Community Building Hires for Token Networks
- Category: #articles
- Document Tags: [[community]] [[community-building]] [[dao]] [[pet3rpan]] [[talent]] 
- URL: https://medium.com/1kxnetwork/how-to-assess-new-community-building-hires-for-token-networks-a2672c07dd58

## Highlights
- Community building is the process of bringing together people for the purposes of achieving a set of shared goals and missions.
- Community is a long term process. It is one thing to create temporary attention but another to foster meaningful networks of relationships and rally entire communities to contribute their time, and energy over a period of time.
    - Tags: [[community]] 
- In many cases, some of the best emerging community builders I’ve come across are often ones who’ve not had a lot of experience but are those who’ve been first hand witnesses to how real thriving communities form and emerge over time, usually as a community participant themselves
- When ramping up hiring for community building roles, be ready with several challenges, problems, or objectives for potential trial candidates to try to solve and execute on.
