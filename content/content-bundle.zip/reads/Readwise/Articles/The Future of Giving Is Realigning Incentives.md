# The Future of Giving Is Realigning Incentives

![rw-book-cover](https://readwise-assets.s3.amazonaws.com/static/images/article3.5c705a01b476.png)

## Metadata
- Author: [[Kris Decoodt]]
- Full Title: The Future of Giving Is Realigning Incentives
- Category: #articles
- URL: https://medium.com/p/ac265e3010b8

## Highlights
- Decentralized Altruistic Community (DAC)
