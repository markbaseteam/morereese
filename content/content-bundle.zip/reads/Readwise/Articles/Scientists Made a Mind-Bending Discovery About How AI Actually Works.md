# Scientists Made a Mind-Bending Discovery About How AI Actually Works

![rw-book-cover](https://video-images.vice.com/articles/63e5738933267a09855519e1/lede/1675982382952-gettyimages-1202177981.jpeg?image-resize-opts=Y3JvcD0xeHc6MC44NjU2eGg7MHh3LDAuMTM0NHhoJnJlc2l6ZT0xMjAwOiomcmVzaXplPTEyMDA6Kg)

## Metadata
- Author: [[Tatyana Woodall]]
- Full Title: Scientists Made a Mind-Bending Discovery About How AI Actually Works
- Category: #articles
- URL: https://artifact.news/s/F34em1Y-BUE=

## Highlights
- But with in-context learning, the system can learn to reliably perform new tasks from only a few examples, essentially picking up new skills on the fly. Once given a prompt, a language model can take a list of inputs and outputs and create new, often correct predictions about a task it hasn’t been explicitly trained for. ([View Highlight](https://read.readwise.io/read/01gryrb6g0x8t2qhehkeh3mvab))
    - Tags: [[machine learning]] [[ai]] [[llm]] 
- AI models that exhibit in-context learning actually create smaller models inside themselves to achieve new tasks. ([View Highlight](https://read.readwise.io/read/01gryrcy101bs1fr4md1rvkter))
    - Tags: [[in-context-learning]] [[ai]] 
