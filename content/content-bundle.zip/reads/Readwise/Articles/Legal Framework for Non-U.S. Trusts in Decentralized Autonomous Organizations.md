# Legal Framework for Non-U.S. Trusts in Decentralized Autonomous Organizations

![rw-book-cover](https://readwise-assets.s3.amazonaws.com/static/images/article3.5c705a01b476.png)

## Metadata
- Author: [[dYdX]]
- Full Title: Legal Framework for Non-U.S. Trusts in Decentralized Autonomous Organizations
- Category: #articles
- Document Tags: [[dao]] [[dydx]] [[legal]] 
- URL: https://dydx.foundation/blog/en/legal-framework-non-us-trusts-in-daos

## Highlights
- Guernsey purpose trust
- The Purpose Trust was contemplated in the context of a DAO’s grants program but could be adopted by other subDAOs and potentially DAOs.
- The Trustees are entitled to continue to receive compensation for their roles as Trustees, so long as the compensation is approved by the DAO token holders.
- The Purpose Trust solves the main issues facing DAOs regarding entity structure: (1) limiting liability for DAO participants, (2) providing a legal form to engage in off-chain activity, and (3) clarifying existing tax obligations.
- When the Purpose Trust replaces the function of a DAO committee or subDAO rather than a wrapper for the entire DAO, it alleviates the DAO token holders from taking actions that could result in liability for them
- the Purpose Trust requires the Trustees to act.
- An issue that has plagued DAOs has been their inability to act in the off-chain world, requiring DAOs to have (a) the initial development company sign agreements on its behalf, creating significant risk to the development company; (b) one DAO token holder signs agreements, creating significant risk to that DAO token holder and potentially all other holders; (c) the DAO signs agreements, essentially admitting the unlimited liability of the DAO token holders; or (d) the DAO has avoided interacting with the off-chain world.
- the Purpose Trust minimizes tax risk for DAO token holders and Trustees.
- One of the primary concerns with introducing a legal structure into a DAO is that observing corporate formalities designed for centralized and in-person organizational structures is that the benefits of decentralization and autonomous operations could be compromised
- The only government involvement that can exist with the Purpose Trust under Guernsey law is a Guernsey court deciding a matter applicable to it.
- When using the Purpose Trust under Guernsey law, DAO token holders retain many more rights that enhance the multi-sig arrangement. At a high level, DAO token holders retain the legal right to direct Trustees to remove Trustees, add Trustees, remove the Enforcer, add an Enforcer, or terminate the Purpose Trust and transfer funds wherever the DAO token holders determine (other than to the DAO or the DAO token holders)
- DAO communities should consider exploring the use of the Purpose Trust under Guernsey law to determine whether it is an appropriate vehicle for the growth of the applicable DAO and protocol.
- This framework touches on only one specific use case but many more exist, such as (1) wrapping an entire DAO with all DAO token holders as Trustees; (2) holding the DAO treasury; (3) holding all IP (including copyrights and trademarks) along with transfers of repos holding the copyrighted code; (4) holding fees received from the applicable protocol to be distributed directly to other Purpose Trusts carrying out functions for the DAO; or (5) serving as a finance and operations hub for the DAO.
