# RDX Works Wallet Roadmap

![rw-book-cover](https://readwise-assets.s3.amazonaws.com/static/images/article2.74d541386bbf.png)

## Metadata
- Author: [[radixdlt.com]]
- Full Title: RDX Works Wallet Roadmap
- Category: #articles
- Document Tags: [[defi]] [[radix]] [[wallet]] 
- URL: https://www.radixdlt.com/post/rdx-works-wallet-roadmap

## Highlights
- Just see Metamask’s role in the Ethereum DeFi ecosystem; not only is it how the majority of users interact with Ethereum
- A DeFi-focused wallet is crucial
- without a substantial rethink of the usability of DeFi (including wallets), DeFi will remain a niche because “consumers value ease of use and convenience over privacy or self-sovereignty”.
- Wallet goals for RDX Works
- the current wallet has a very specific goal on our roadmap: holding, sending, and staking tokens on the Olympia networ
- Babylon
