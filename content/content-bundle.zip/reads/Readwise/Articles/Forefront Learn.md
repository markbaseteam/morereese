# Forefront Learn

![rw-book-cover](https://readwise-assets.s3.amazonaws.com/static/images/article1.be68295a7e40.png)

## Metadata
- Author: [[forefront.market]]
- Full Title: Forefront Learn
- Category: #articles
- URL: https://forefront.market/learn/social-tokens/background

## Highlights
- A social token is a form of cryptocurrency that gives power back to creators, facilitates incentive alignment, and moves us towards an open and participatory economy with greater access to ownership and less reliance on closed, for-profit, and extractive web2 platforms
- “Creator economy” is a term used to describe an economic model in which creators and cultural producers make money from their audience, directly or indirectly.
- Although social tokens are not explicitly linked to the concept of DAOs (decentralized autonomous organizations), they are often used in tandem and in mutually reinforcing ways.
