# A Century of Fiscal and Monetary Policy: Inflation vs Deflation

![rw-book-cover](https://readwise-assets.s3.amazonaws.com/static/images/article0.00998d930354.png)

## Metadata
- Author: [[Lyn Alden]]
- Full Title: A Century of Fiscal and Monetary Policy: Inflation vs Deflation
- Category: #articles
- URL: https://www.lynalden.com/fiscal-and-monetary-policy/

## Highlights
- The effectiveness of monetary policy, including interest rate manipulation and asset purchases, diminishes significantly when debt is high, interest rates hit the zero bound, and the money multiplier is low.
- In essence, monetary policy is effective at putting the brakes on an economy, but bad at stimulating an economy, whereas fiscal spending has the opposite tilt.
- normal 5-10 year business credit cycles
- deleveraging rarely reduces debt levels all the way back to where they started in the cycle, in part due to that fiscal and monetary policy response
- whenever the private sector deleverages a bit in blue below, the public sector leverages up in red below.
- at the end of a long-term debt cycle, the denominator (currency) goes up a lot more than the numerator (nominal debt) goes down.
- someone’s liability is someone else’s asset. When you default on a liability, you destroy someone else’s asset
- Another way of putting it, is that a fiat currency regime rarely if ever collapses from lack of printed fiat. When the zero bound for interest rates is reached, and/or sovereign debt is high and they run low on real private buyers of their sovereign debt, they print. If there is a historically high public and private debt level relative to the number of fiat currency units in the system, they increase the number of fiat currency units in the system.
- It’s interesting how the century-long wealth concentration cycle matched almost perfectly (inversely) with the century-long interest rate cycle. Wealth concentration peaked during high levels of system-wide leverage and low interest rates, and bottomed during periods of low leverage and high inflation and high interest rates
- historically, the difference between a normal short-term deleveraging event and a long-term deleveraging event, is that the long-term version usually includes a significant component of currency devaluation.
- Based on historical probability, that’s mathematically what currency holders and bond holders are doing when a sovereign hits over 130% debt to GDP. They are buying bonds at record high prices (aka record low yields) at a time when the sovereign is least likely to be able to repay its debt in real purchasing power terms over the next decade or two as some of those long bonds mature.
- Eventually, monetary policy on its own runs out of ammo, with rates at zero and aggressive expansion of the monetary base happening, but little real lending, and little velocity of money or strong growth in broad money supply, or strong rebound in GDP. Further QE at that point can pump up asset prices, which can in some cases make wealth inequality worse, and can’t do much about the real underlying economy.
- whether QE is inflationary or not, largely depends on whether it is accompanied by high fiscal spending, since QE’s role in that environment is merely to recapitalize the banking system and monetize those fiscal deficits
- Consumer price inflation can be caused by all sorts of policy and psychological reasons, but ultimately occurs because too much money is printed and spent relative to the productive supply of goods and services in the economy. In opposition to that, deflation is caused by technological progress and productivity improvement, excessive debt levels which constrain spending, and an abundance of supply of goods and services relative to both demand and the amount of money in the system.
- Aggressive broad money expansion, often accompanied by some degree of supply limitation, is generally inflationary.
- when interest rates run into the zero bound, fiscal spending takes over
