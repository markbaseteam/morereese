# How to Grow Decentralized Communities

![rw-book-cover](https://readwise-assets.s3.amazonaws.com/static/images/article4.6bc1851654a0.png)

## Metadata
- Author: [[medium.com]]
- Full Title: How to Grow Decentralized Communities
- Category: #articles
- Document Tags: [[community]] [[community-building]] [[dao]] [[governance]] 
- URL: https://medium.com/1kxnetwork/how-to-grow-decentralized-communities-1bf1044924f8

## Highlights
- We can think of the community building process as a 3-stage funnel that takes a potential member from the community discovery stage to sustained positive-sum participation. In building this funnel, community builders should aim to do the following:Creating opportunities for people to discover the community/projectCreating ways for people to get involved meaningfullyCreating opportunities for participants to build a sense of ownership
- 1. Creating opportunities for intrinsically motivated contributors to discover the community
- focus on creating awareness around what differentiates the community: from how the product was built and designed, ways to participate in the community, the community’s existing contributors, the people behind the project, its mission and values, narratives, memes
- 2. Building a relationship with new community members to foster minimum viable contributors
- The goal of minimum viable participation is to foster a relationship, from which further trust and engagement can be built.
- The key is making sure there are call-to-actions for the different community contributors you are aiming to attract.
- You want to think of monetary rewards as a means of acknowledging the value that a community member brings to the community as opposed to being the direct incentive to participate.
- You want to think of monetary rewards as a means of acknowledging the value that a community member brings to the community as opposed to being the direct incentive to participate.
- 3. Fostering community ownership
- only once community members have grown to become familiar with a community and invested enough of their time and energy, is it possible for them to grow an ownership mentalit
