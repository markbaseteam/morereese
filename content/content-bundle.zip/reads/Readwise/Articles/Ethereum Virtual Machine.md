# Ethereum Virtual Machine

![rw-book-cover](https://readwise-assets.s3.amazonaws.com/static/images/article1.be68295a7e40.png)

## Metadata
- Author: [[Full definition]]
- Full Title: Ethereum Virtual Machine
- Category: #articles
- URL: https://coinmarketcap.com/alexandria/glossary/ethereum-virtual-machine-evm

## Highlights
- Ethereum Virtual Machine (EVM) is a computation engine which acts like a decentralized computer that has millions of executable projects.
  It acts as the virtual machine which is the bedrock of Ethereum’s entire operating structure. 
  It is considered to be the part of the Ethereum that runs execution and smart contract deployment.
