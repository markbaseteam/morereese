# Why Solana Is the ‘World Computer’ Blockchain Developers Need

![rw-book-cover](https://readwise-assets.s3.amazonaws.com/static/images/article4.6bc1851654a0.png)

## Metadata
- Author: [[Andrew Hyde]]
- Full Title: Why Solana Is the ‘World Computer’ Blockchain Developers Need
- Category: #articles
- URL: https://medium.com/p/ee849caaa9a0

## Highlights
- While there are many types of scaling solutions being worked on, each of them create idiosyncratic forms of complexity for application developers, users, and the ecosystem as a whole.
- “creating ecosystem baggage”
- Solana’s guiding principle is that software shall not get in the way of hardware
