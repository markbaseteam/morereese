# Drive-to-Earn & Proof-of-Movement

![rw-book-cover](https://readwise-assets.s3.amazonaws.com/static/images/article2.74d541386bbf.png)

## Metadata
- Author: [[Andy C]]
- Full Title: Drive-to-Earn & Proof-of-Movement
- Category: #articles
- URL: https://medium.com/dimo-network/drive-to-earn-proof-of-movement-c284d969caeb

## Highlights
- the “Platform Problem”.
