# Squads 101: Multisig, and Beyond!

![rw-book-cover](https://readwise-assets.s3.amazonaws.com/static/images/article2.74d541386bbf.png)

## Metadata
- Author: [[Squads]]
- Full Title: Squads 101: Multisig, and Beyond!
- Category: #articles
- URL: https://medium.com/p/71b0698fd23e

## Highlights
- You can think of a multisig as a decentralized, co-owned bank vault that needs multiple keys to open, with no middlemen sitting between you and your vault.
- Multisigs are essential for DAOs and web3 startups because they enable collaborative custody and ensure decentralization of control of funds.
