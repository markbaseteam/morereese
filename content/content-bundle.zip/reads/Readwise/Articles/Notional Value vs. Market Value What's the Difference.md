# Notional Value vs. Market Value: What's the Difference?

![rw-book-cover](https://readwise-assets.s3.amazonaws.com/static/images/article0.00998d930354.png)

## Metadata
- Author: [[Full Bio]]
- Full Title: Notional Value vs. Market Value: What's the Difference?
- Category: #articles
- URL: https://www.investopedia.com/ask/answers/050615/what-difference-between-notional-value-and-market-value.asp

## Highlights
- Notional value is the total value controlled by a position or obligation; e.g. how much value is represented by a derivatives contract.
- Market value is price of a security set by buyers and sellers in the marketplace through supply and demand.
- For example, a call option representing 100 shares of XYZ stock with a strike price of $40 may trade in the market for $1.20 per contract (100 x $1.20 = $120 market value), but represents a notional value of $4,000 (100 x $40).
