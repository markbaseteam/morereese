# Eurodollar

![rw-book-cover](https://readwise-assets.s3.amazonaws.com/static/images/article3.5c705a01b476.png)

## Metadata
- Author: [[From Wikipedia, the free]]
- Full Title: Eurodollar
- Category: #articles
- URL: https://en.wikipedia.org/wiki/Eurodollar

## Highlights
- Gradually, after World War II, the quantity of U.S. dollars outside the United States increased significantly, as a result of both the Marshall Plan and imports into the U.S., which had become the largest consumer market after World War II.
- Eurodollars are time deposits denominated in U.S. dollars at banks outside the United States, and thus are not under the jurisdiction of the Federal Reserve.
- In the mid-1950s, Eurodollar trading and its development into a dominant world currency began when the Soviet Union wanted better interest rates on their Eurodollars and convinced an Italian banking cartel to give them more interest than could have been earned if the dollars were deposited in the U.S.
- Eurodollars can have a higher interest rate attached to them because of the fact that they are out of reach from the Federal Reserve.
