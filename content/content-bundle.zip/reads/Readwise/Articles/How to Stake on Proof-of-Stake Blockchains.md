# How to Stake on Proof-of-Stake Blockchains

![rw-book-cover](https://readwise-assets.s3.amazonaws.com/static/images/article4.6bc1851654a0.png)

## Metadata
- Author: [[Cryptopedia Staff]]
- Full Title: How to Stake on Proof-of-Stake Blockchains
- Category: #articles
- URL: https://www.gemini.com/cryptopedia/staking-rewards-pos-blockchains

## Highlights
- Dilution refers to the reduction in value of a single cryptocurrency or the market capitalization of a cryptocurrency protocol due to the minting of new tokens.
