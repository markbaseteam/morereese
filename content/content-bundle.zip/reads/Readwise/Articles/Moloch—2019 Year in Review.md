# Moloch—2019 Year in Review

![rw-book-cover](https://readwise-assets.s3.amazonaws.com/static/images/article4.6bc1851654a0.png)

## Metadata
- Author: [[? Moloch]]
- Full Title: Moloch—2019 Year in Review
- Category: #articles
- URL: https://medium.com/molochdao/moloch-2019-year-in-review-eb6f53dc035

## Highlights
- With Moloch’s framework, we aimed to streamline grants in order to get value-adding developments funded faster.
- In terms of funding focus, ETH 2.0 was Moloch’s initial mandate and continues to be a focus.
- Moloch v2 Changelog
- most important are multi-token support and guild kick
- Multi-token support allows the DAO to acquire and spend (or invest in) an unlimited portfolio of assets
- Guild kick allows members to vote to remove members which is especially important if a member presents a risk to the DAO’s legal compliance
