# The Horizen Q3 Review

![rw-book-cover](https://readwise-assets.s3.amazonaws.com/static/images/article4.6bc1851654a0.png)

## Metadata
- Author: [[Horizen News]]
- Full Title: The Horizen Q3 Review
- Category: #articles
- URL: https://blog.horizen.io/the-horizen-q3-review/

## Highlights
- Zendoo is now live on the final tesnet and will be released to the public in mid-October.
