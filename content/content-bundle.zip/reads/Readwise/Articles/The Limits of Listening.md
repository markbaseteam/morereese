# The Limits of Listening

![rw-book-cover](https://cdn2.psychologytoday.com/assets/styles/manual_crop_1_91_1_1528x800/public/teaser_image/blog_entry/2023-02/booba%20kiki%20effect.png.jpg?itok=D0viF1nL)

## Metadata
- Author: [[Hara Estroff Marano]]
- Full Title: The Limits of Listening
- Category: #articles
- URL: https://artifact.news/s/2kH1VjMe2io=

## Highlights
- bouba/kiki effect suggests a more complex reason: Potential customers know what they want but they cannot articulate it. The dilemma is reflected in Henry Ford’s classic statement: “If I had asked my customers what they wanted, they would have said, ‘a faster horse.’” ([View Highlight](https://read.readwise.io/read/01grd2za5sv7k766h12kg819n7))
