# 5 Product Management Frameworks Used by Billion Dollar Companies

![rw-book-cover](https://readwise-assets.s3.amazonaws.com/static/images/article3.5c705a01b476.png)

## Metadata
- Author: [[Productboard Editorial]]
- Full Title: 5 Product Management Frameworks Used by Billion Dollar Companies
- Category: #articles
- Document Tags: [[product]] 
- URL: https://www.productboard.com/blog/5-product-management-frameworks-billion-dollar-companies/

## Highlights
- Experimentation: Spotify tests and measures to deliver an exceptional experience
- Spotify is perhaps well known for its autonomous “squads.”
- They follow a model of Think It, Build It, Ship It, Tweak It.
- Working backwards: Why Amazon starts by focusing on the finished product
- Amazon starts any new product by explaining precisely what they hope customers and the media will say when they get their hands on it
- Two equal parts: Typeform’s two-part framework emphasizes product discovery
- Typeform uses a two-part product management framework. The first half focuses on product discovery, which Typeform considers to be crucially important. The second half of their framework focuses on delivery.
- Instead, they break the MVP into three parts:
  Earliest testable product – The testable product is the fastest way to get data on an idea. So as not to spend too much time developing an MVP, the earliest testable product might be something as simple as a fake door test.
  Earliest usable product – A “usable” product is an actual product that early adopters will use without being incentivized. At this stage, the product has baseline functionality and may lack “delight,” but the purpose is to collect data and feedback. Typeform is trying to figure out whether it’s worth putting more hours into developing the full product.
  Earliest lovable product – This is the product that customers will love. They’ll tell their friends about it and are willing to pay a premium for it. It’s still not 100% finished, but it’s the closest thing to a finished product at this stage.
- Customer obsession: How GoGoVan’s fixation on customer problems is a big advantage
- They structure product discovery based on three pillars: user interviews, sales interviews, and usage data
- Growth: Why Shopify’s growth framework takes products to new heights
- The product growth framework has eight steps:
  Stage your company – First, you need to understand the stage of your company and your product. Are you trying to find product/market fit? Are you trying to launch an MVP? Whatever it is, define it. A lot of companies dive into product growth without identifying their stage.
  Know your strategic goal – This is another one you have to define ahead of time. What’s your goal for your product? Are you going after profitability, new users, or something else? Articulating this ahead of time will help you identify what your product needs to do to drive growth.
  Model the funnel – What’s the process that users will take to start using your product? Are they going to be existing or new users? These are questions that a model will help you answer. Modeling your funnel will also help you understand what areas you need to improve on to really grow your product.
  Define your north star metric – You need a metric to help you understand whether you’re headed in the right direction. Your north start measures progress immediately, or at least incrementally, and may differ slightly from your overall strategic goal.
  Create a prioritization grid – Get input from everyone working on this project about what features they think will create the most significant impact for your users. Everyone on your team is going to have different ideas about prioritization, which is why it’s essential to hear from multiple people.
  Set targets – Targets aren’t goals or deadlines as they’re simply milestones to complete in the near term. They help keep your team on track and working toward your north star metric and your strategic goal.
  Work on execution – Efficient execution enables every step of product growth. You need to work with your team to create an efficient process for all phases of product development—from prioritization to delivery.
  Develop a multidisciplinary team – Your team needs skills in product, engineering, design, data, and marketing. That doesn’t mean you need one person dedicated to each task, but your whole team should cover these fundamental skills.
