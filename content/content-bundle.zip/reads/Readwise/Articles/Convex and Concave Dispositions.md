# Convex and Concave Dispositions

![rw-book-cover](https://readwise-assets.s3.amazonaws.com/static/images/article1.be68295a7e40.png)

## Metadata
- Author: [[vitalik.ca]]
- Full Title: Convex and Concave Dispositions
- Category: #articles
- URL: https://vitalik.ca/general/2020/11/08/concave.html

## Highlights
- tradeoff of compromise versus purity
