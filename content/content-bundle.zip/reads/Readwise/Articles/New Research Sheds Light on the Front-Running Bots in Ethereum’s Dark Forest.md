# New Research Sheds Light on the Front-Running Bots in Ethereum’s Dark Forest

![rw-book-cover](https://readwise-assets.s3.amazonaws.com/static/images/article4.6bc1851654a0.png)

## Metadata
- Author: [[Benjamin Powers]]
- Full Title: New Research Sheds Light on the Front-Running Bots in Ethereum’s Dark Forest
- Category: #articles
- URL: https://www.coindesk.com/new-research-sheds-light-front-running-bots-ethereum-dark-forest

## Highlights
- ZenGo
- The ZenGo report described front-running as the “act of getting a transaction first in line in the execution queue, right before a known future transaction occurs.”
- Ethereum front-running happens because bots are able to bid “a slightly higher gas price on a transaction, incentivizing miners to place earlier in the order when constructing the block. The higher-paying transactions are executed first. Thus, if two transactions making a profit from the same contract call are placed in the same block, only the first takes the profit,” the researchers wrote.
