# A Prehistory of DAOs

![rw-book-cover](https://readwise-assets.s3.amazonaws.com/static/images/article3.5c705a01b476.png)

## Metadata
- Author: [[gnosisguild.mirror.xyz]]
- Full Title: A Prehistory of DAOs
- Category: #articles
- Document Tags: [[definition-of-dao]] 
- URL: https://gnosisguild.mirror.xyz/t4F5rItMw4-mlpLZf5JQhElbDfQ2JRVKAzEpanyxW1Q

## Highlights
- The year is 1996. John Perry Barlow is about to declare, “The internet consists of transactions, relationships, and thought itself”
- another written work that would impact the political ideology of the early internet appeared: Tribes, Institutions, Markets, Networks (TIMN) by David Ronfeldt.
- The TIMN report creates a narrative of societal evolution in which humans have progressed through four distinct organizational forms: (T) Tribes have the societal organizing principle of kinship, clans, and lineages. (I) Institutions have the societal organizing principle of hierarchy. (M) Markets have the societal organizing principle of competitive exchange. (N) Networks have the societal organizing principle of heterarchic collaborative exchange. Heterarchic here denotes organizations that are non-hierarchical, unranked, or possess the ability to be ranked in multiple ways.
- A key distinguishing feature between networks and the organizational forms preceding them is that networks are described as multi-organizational, emphasizing collaboration between “small, scattered, and autonomous” groups over larger distances. These groups do not necessarily share a distinct organizational unity.
- Based on Vitalik Buterin’s DAOs, DACs, DAs and More: An Incomplete Terminology Guide from 2014, a DAO could be described then as a capitalized organization in which a software protocol informs its operation, placing automation at its center and humans at its edges.
- In 2021, a DAO could be described as a voluntary association with the operating principles of digital cooperativism. As voluntary associations, they are a cross-jurisdictional way for strangers, friends, or unlikely allies to pseudonymously come together toward common goals, supported by a token model, incentives, and governance. Members of a DAO can have representative ownership of its digital assets through a token, which often simultaneously acts as a governance right and network utility.
- Although many DAOs would not embrace the label of digital cooperative, one could say DAOs embrace cooperativism as a protocol, meaning an evolving set of relational practices that are distinct from traditional corporate structures or decentralized autonomous corporations, because they prioritize member ownership.
- This essay’s history of DAOs is far from complete, as other projects like Aragon, Colony, DAOhaus, and DAOstack continue to develop their platforms for DAOs and modular initiatives like Block Science and Commons Stack arise
- Today, the International Cooperative Alliance defines cooperatives as “an autonomous association of persons united voluntarily to meet their common economic, social, and cultural needs and aspirations through a jointly-owned and democratically-controlled enterprise”
- The establishment of the Rochdale Principles, formulated by a society of weavers in 1844, marked a key moment in the history of cooperatives. The International Cooperative Alliance adopted these operating principles, which still guide cooperatives globally: Voluntary and Open Membership Democratic Member Control Member Economic Participation Autonomy and Independence Education, Training, and Information Cooperation among Cooperatives Concern for Community
- for DAOs with the mission of economic value creation, a token becomes a useful mechanism on three fronts: Bootstrapping Funding Distributing Governance Rights Aligning Ecosystem of DAOs
- emphasis on long termism, through establishing more cultural patterns around token vesting, limited transferability, or more experimental mechanisms.
- proponents of DAOs have a core belief about their impact on the future: DAOs could out-compete by out-cooperating the modern firm
- DAOs aspire to become more efficient as they scale
- Genesis DAO, a collective centered around the DAOstack platform
- In Ownership in Cryptonetworks, Patrick Rawson argues that for DAOs, “distributing ownership to squadlike entities with more specialized objectives is the key long-term problem to solve” in order to enable meaningful work.
- Inspired by Rawson’s analysis, we can roughly sketch three layers of a DAO: Token: Multi-organizational networks aligned by token ownership Teams: Teams, guilds, and squads represented by token ownership Missions: Missions, milestones, and raids financed by token ownership
- The TIMN RAND report this essay began with closes on a curious note. It reads: Much of the literature about redesigning organizations for the information-age focuses on production—on improving productivity, or manufacturing something new like the Boeing 777 jetliner. Yet, does this not reflect a lingering industrial-age mentality? Production organizations remain a crucial part of the organizational ecology. However, we should also be thinking about “sensory organizations.” Sensory functions are quite different from production functions, and require different modes of organization—e.g., more networks connected to the world outside an office’s boundaries. Determining appropriate designs for all manner of sensory organizations may become a good meta-theme for innovative research and development in the years ahead (
- Even though the term DAO remains poetically correct, we could propose an occasional replacement: decentralized avatar organizations.
- To escape the tendency to fetishize technical protocols for governance, decentralized avatar organizations must cultivate compelling environments players want to inhabit, recognizing narratives, aesthetics, and goals held in common are key to their success.
