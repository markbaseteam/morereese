# Introducing EVM Equivalence

![rw-book-cover](https://readwise-assets.s3.amazonaws.com/static/images/article3.5c705a01b476.png)

## Metadata
- Author: [[medium.com]]
- Full Title: Introducing EVM Equivalence
- Category: #articles
- URL: https://medium.com/ethereum-optimism/introducing-evm-equivalence-5c2021deb306

## Highlights
- If you think of Ethereum as an almighty, decentralized court, then the core insight of L2 scalability is: “don’t go to court to cash a check — just go if the check bounces.”
- This forced rollups to pioneer on two fronts at once:Building a scalable, production-ready rollup infrastructure.Solving the long-infamous EVM-in-EVM problem.
- EVM compatibility is not the same as EVM equivalence, and settling for mere compatibility means that you are forced to modify, or even completely reimplement, lower-level code that Ethereum’s supporting infrastructure also relies on. If L2s want to surf Ethereum’s wave of infrastructural network effects, they must become EVM equivalent.
- In short: EVM equivalence is complete compliance with the Ethereum yellow paper, the formal definition of the protocol. By definition, L1 Ethereum software must comply with this specification.
- Projects like Solidity, Vyper, and Hardhat selflessly worked on OVM versions of their devtools
- Separating Block Generation and Execution
- A core pattern of blockchain modularization is separating consensus from execution — that is, having different processes for determining and executing the next block
