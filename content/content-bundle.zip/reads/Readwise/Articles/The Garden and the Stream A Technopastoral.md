# The Garden and the Stream: A Technopastoral

![rw-book-cover](https://mikecaulfield.files.wordpress.com/2015/10/t_d4424f37-afe9-7065-bc7f-13540c92ce85.jpg)

## Metadata
- Author: [[mikecaulfield]]
- Full Title: The Garden and the Stream: A Technopastoral
- Category: #articles
- URL: https://hapgood.us/2015/10/17/the-garden-and-the-stream-a-technopastoral/

## Highlights
- And when you get to that point, where you’ve mapped out 1000s of articles of your own knowledge you start to see impacts on your thought that are very hard to describe.
  Over time these things you write up start to form a deep network that helps you think. ([View Highlight](https://read.readwise.io/read/01gs349x2w1m9gakzm8vmdyqwd))
    - Tags: [[digital-gardening]] 
- The Garden is the web as topology. The web as space. It’s the integrative web, the iterative web, the web as an arrangement and rearrangement of things to one another. ([View Highlight](https://read.readwise.io/read/01gs34br1p9paptdhtz4fdb0qr))
    - Tags: [[definition-of]] [[digital-gardening]] 
- Things in the Garden don’t collapse to a single set of relations or canonical sequence, and that’s part of what we mean when we say “the web as topology” or the “web as space”. Every walk through the garden creates new paths, new meanings, and when we add things to the garden we add them in a way that allows many future, unpredicted relationships ([View Highlight](https://read.readwise.io/read/01gs34cc4ya1s85r2yddrbrsgf))
- The bridge is a bridge is a bridge — a defined thing with given boundaries and a stated purpose. But the multi-linear nature of the garden means that there is no one right view of the bridge, no one correct approach. The architect creates the bridge, but it is the visitors to the park who create the bridge’s meaning. A good bridge supports many approaches, many views, many seasons, maybe many uses, and the meaning of that bridge will even evolve for the architect over time. ([View Highlight](https://read.readwise.io/read/01gs34d9zexbeqvd1mk11dq1sh))
- In the stream metaphor you don’t experience the Stream by walking around it and looking at it, or following it to its end. You jump in and let it flow past. You feel the force of it hit you as things float by.
  It’s not that you are passive in the Stream. You can be active. But your actions in there — your blog posts, @ mentions, forum comments — exist in a context that is collapsed down to a simple timeline of events that together form a narrative.
  In other words, the Stream replaces topology with serialization. Rather than imagine a timeless world of connection and multiple paths, the Stream presents us with a single, time ordered path with our experience (and only our experience) at the center. ([View Highlight](https://read.readwise.io/read/01gs34fh495d147gjg12dv220h))
- Whereas the garden is integrative, the Stream is self-assertive. ([View Highlight](https://read.readwise.io/read/01gs34gmeayymv2db8ssrtmj0m))
- Vannevar Bush’s 1945 essay As We May Think ([View Highlight](https://read.readwise.io/read/01gs34hcg20veff4wgy318jev5))
