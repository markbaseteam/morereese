# A Love Letter to DAOs | State of the DAOs

![rw-book-cover](https://readwise-assets.s3.amazonaws.com/static/images/article2.74d541386bbf.png)

## Metadata
- Author: [[Hiro Kennelly]]
- Full Title: A Love Letter to DAOs | State of the DAOs
- Category: #articles
- Document Tags: [[dao]] 
- URL: https://banklessdao.substack.com/p/a-love-letter-to-daos-state-of-the

## Highlights
- DAOs compared to traditional companies. Focus: Traditional companies focus on customer needs and capturing value by meeting those needs. DAOs tend to focus more on community, thus community growth and engagement are better assessments for value creation. Compensation: DAOs blur the lines on compensation compared to traditional companies. DAOs are able to employ multiple compensation models to meet the various types of contributions from its members. Permission: DAOs may function on a permission continuum, some being more like a top-down traditional company, while others are fully permissionless and allow members to contribute freely. Management: Traditional companies have managers and supervisors to tell you what to do. DAOs rely on the art of delegation and the ability of contributors to choose the role or task they want to fill. Information and Tools: DAO contributors need access to information and the right tools to be able to make decisions and execute tasks. Traditional companies might gate access to information or require certain job titles to use certain tools. In DAOs, these are open to all. Data and Metrics: In traditional companies, most data and metrics are reserved for the executive suite. If DAOs are going to succeed, contributors need access to data and quality metrics to guide decision making.
