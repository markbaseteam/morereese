# What Is a DAO?

![rw-book-cover](https://readwise-assets.s3.amazonaws.com/static/images/article0.00998d930354.png)

## Metadata
- Author: [[lisawocken]]
- Full Title: What Is a DAO?
- Category: #articles
- URL: https://mirror.xyz/0x74c02fE52A544d3d1775796A9037cE560C40f581/DQ0N2xywJvbnog4jTD80R5orvReuOO4veZq3Muy7IqM

## Highlights
- As one of the co-founders of Ethereum, Vitalik Buterin, put it in 2014, DAOs have automation and the center, humans at the edges.
- DAOs, in a very basic sense, are another form of organization that is newer than the others (e.g. non-profits, corporations, small businesses)
- Simply put. Before blockchain technology, DAOs did not exist.
