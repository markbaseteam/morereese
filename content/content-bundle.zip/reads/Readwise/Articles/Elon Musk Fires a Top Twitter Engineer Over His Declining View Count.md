# Elon Musk Fires a Top Twitter Engineer Over His Declining View Count

![rw-book-cover](https://substackcdn.com/image/fetch/w_1200,h_600,c_limit,f_jpg,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2Fd6cac20c-f3e0-427f-99a8-d0912f1f0d4e_512x512.png)

## Metadata
- Author: [[Zoë Schiffer]]
- Full Title: Elon Musk Fires a Top Twitter Engineer Over His Declining View Count
- Category: #articles
- URL: https://open.substack.com/pub/platformer/p/elon-musk-fires-a-top-twitter-engineer?r=23t3cy&utm_medium=ios&utm_campaign=post

## Highlights
- As the adage goes, ‘you ship your org chart,’” said one current employee. “It’s chaos here right now, so we’re shipping chaos.” ([View Highlight](https://read.readwise.io/read/01grz875hzs2pt97y4kfb4vhnw))
