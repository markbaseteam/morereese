# Scaling Email to 10,000 on-Chain Addresses

![rw-book-cover](https://readwise-assets.s3.amazonaws.com/static/images/article2.74d541386bbf.png)

## Metadata
- Author: [[Nico's thoughts]]
- Full Title: Scaling Email to 10,000 on-Chain Addresses
- Category: #articles
- URL: https://paragraph.xyz/@nico/scaling-email-to-10,000-on-chain-addresses

## Highlights
- Simple Mail Transfer Protocol (SMTP) and its modern successor Extended SMTP (ESMTP) are the underlying protocols powering our daily email communication
- Usenet
- A cost-effective way to optimize message delivery for a large audience is a channel model
