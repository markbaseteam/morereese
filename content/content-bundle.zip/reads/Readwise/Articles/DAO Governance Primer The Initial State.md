# DAO Governance Primer: The Initial State

![rw-book-cover](https://readwise-assets.s3.amazonaws.com/static/images/article0.00998d930354.png)

## Metadata
- Author: [[holographic consensus]]
- Full Title: DAO Governance Primer: The Initial State
- Category: #articles
- Document Tags: [[dao]] [[definition-of-dao]] [[governance]] 
- URL: https://mirror.xyz/0x367B4bDf414Df673Df0129838ebfB9913147427F/R-ZpVf8WUpgZh30FpoUtVsxG4ysRqgMe4JOliDfL5fk

## Highlights
- A DAO is a mechanism of governance enabled by smart contract execution of tokenized commands.
