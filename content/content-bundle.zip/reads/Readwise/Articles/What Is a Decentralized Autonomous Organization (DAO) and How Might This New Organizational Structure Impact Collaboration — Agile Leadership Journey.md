# What Is a Decentralized Autonomous Organization (DAO) and How Might This New Organizational Structure Impact Collaboration? — Agile Leadership Journey

![rw-book-cover](https://readwise-assets.s3.amazonaws.com/static/images/article2.74d541386bbf.png)

## Metadata
- Author: [[Eunice Brownlee]]
- Full Title: What Is a Decentralized Autonomous Organization (DAO) and How Might This New Organizational Structure Impact Collaboration? — Agile Leadership Journey
- Category: #articles
- URL: https://agileleadershipjourney.com/blog-posts/2021/11/8/what-is-a-decentralized-autonomous-organization-and-how-might-this-new-organizational-structure-impact-collaboration

## Highlights
- I suggest that the collaborative power of “individuals as equals” is one significant aspect that sets DAOs apart from traditional hierarchical organizations, disrupting the traditional practices of management in decision-making.
