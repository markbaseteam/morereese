# SEC Chair Gensler Explains Why He Believes ‘Nakamoto’s Innovation Is Real’

![rw-book-cover](https://readwise-assets.s3.amazonaws.com/static/images/article4.6bc1851654a0.png)

## Metadata
- Author: [[Brenda Ngari]]
- Full Title: SEC Chair Gensler Explains Why He Believes ‘Nakamoto’s Innovation Is Real’
- Category: #articles
- URL: https://zycrypto.com/sec-chair-gensler-explains-why-he-believes-nakamotos-innovation-is-real/

## Highlights
- According to him, not a single crypto asset can fulfill all three key purposes of public fiat money (unit of account, medium of exchange, and store of value). However, cryptocurrencies like bitcoin provide digital, scarce investment vehicles.
