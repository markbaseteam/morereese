# This Week in Farcaster - February 4, 2023 - Sponsored by Purple

![rw-book-cover](https://readwise-assets.s3.amazonaws.com/static/images/article4.6bc1851654a0.png)

## Metadata
- Author: [[This Week in Farcaster]]
- Full Title: This Week in Farcaster - February 4, 2023 - Sponsored by Purple
- Category: #articles

## Highlights
- Dan was the featured guest in an episode of [Bankless](http://podcast.banklesshq.com/) that dropped Saturday , Jan. 28. "I want to build a protocol that has a billion plus people using it, but I want to do it in a way that doesn't compromise on the decentralization and the sovereignty at the user account level," said Dan. "Maybe it's a fool's errand but that's what we're trying to do." ([View Highlight](https://read.readwise.io/read/01grhxn8jmn77asfa50ctksw07))
    - Tags: [[farcaster]] 
