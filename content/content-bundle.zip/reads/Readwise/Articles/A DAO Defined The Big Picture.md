# A DAO Defined: The Big Picture

![rw-book-cover](https://readwise-assets.s3.amazonaws.com/static/images/article4.6bc1851654a0.png)

## Metadata
- Author: [[blog.aragon.org]]
- Full Title: A DAO Defined: The Big Picture
- Category: #articles
- Document Tags: [[aragon]] [[definition-of-dao]] 
- URL: https://blog.aragon.org/a-dao-defined-the-big-picture/

## Highlights
- A short definition is that a Decentralized Autonomous Organization (DAO) is an internet community that jointly controls a cryptocurrency wallet to pursue common goals - such as running a business or charity - without having to ask anyone for permission
- the DAO movement has opted out of the fiat money system entirely and instead built on internet currencies (cryptocurrencies) such as Ethereum
