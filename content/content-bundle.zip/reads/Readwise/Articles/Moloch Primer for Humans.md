# Moloch Primer for Humans

![rw-book-cover](https://readwise-assets.s3.amazonaws.com/static/images/article4.6bc1851654a0.png)

## Metadata
- Author: [[medium.com]]
- Full Title: Moloch Primer for Humans
- Category: #articles
- Document Tags: [[moloch]] [[pubdao]] [[ragequit]] 
- URL: https://medium.com/odyssy/moloch-primer-for-humans-9e6a4f258f78

## Highlights
- Moloch is built more upon the idea of a DAO as a primitive solution to human coordination, and testing real-world use-cases. Moloch as a framework is very unopinionated and can be combined/enhanced with many different currencies, functions, and extensions
- Ragequit burns Shares and returns the equivalent amount of value back to the user, based on current share value. It is used for two purposes:
  Express Dissent
  If a member does not like a proposal, they can ragequit their Shares at anytime as long as they do not have a ‘Yes‘ vote pending on a proposal.
  Withdraw Funds from the Bank
  Grantees receive Shares through proposals. They ragequit their shares to withdraw funds and execute on the proposal’s purpose in the real world.
- A glance at current Molochs and their use cases
- Moloch DAO (The OG Moloch)
- MetaCartel DAOGrant-giving organization funding and supporting the Ethereum application ecosystem. Basically a Y Combinator for Ethereum.
- Moloch DAO (The OG Moloch)Grant-giving organization funding initiatives for ETH 2.0, scalability and adoption.
- YangDAOSuper PAC for the US presidential candidate Andrew Yang. Lots of Memes.
- DAOSakaCreation, curation and selling of Artwork during Devcon V in Osaka
- TrojanDAOA network of artists & developers, on a mission to transform the cultural economy from the ground-up with the help of blockchain. Starting from Athens, Greece
- Raid GuildA collective of builders that form Raid Parties to team up on epic boss fights (open source web3 projects).
- Orochi DAOAn events-focused DAO born from the sponsoring events for Devcon V in Osaka and beyond.
- Using a DAO greatly lowers the coordination cost for a group of people to self-organize and distribute capital. Moloch’s ragequit mechanism and no quorum dependency lowers that even further.
