# Squads 101: DAOs & SubDAOs

![rw-book-cover](https://readwise-assets.s3.amazonaws.com/static/images/article0.00998d930354.png)

## Metadata
- Author: [[Squads]]
- Full Title: Squads 101: DAOs & SubDAOs
- Category: #articles
- URL: https://medium.com/p/379e26fd01d7

## Highlights
- In short, subDAOs are small autonomous working groups within a DAO that in many ways operate like their own miniDAO.
- “permissionless work.”
- SubDAOs should have their own treasury separate from the DAO’s main treasury.
- SubDAOs usually have their own governing process, while still operating within the governing principles of the parentDAO. A marketing subDAO may elect a team leader, whereas the main DAO has no CEO like figure. By giving the subDAO freedom to operate as it pleases instead of forcing a governance structure onto it, teams can organize naturally how they see fit, facilitating better results.
- As DAOs grow in scope, it becomes increasingly difficult for DAO members to coordinate.
- Different subDAOs will have different proximities to the parentDAO.
- SubDAOs should have full responsibility for delegating tasks and governing internally within their working group
