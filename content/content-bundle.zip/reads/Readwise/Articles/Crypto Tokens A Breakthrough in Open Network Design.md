# Crypto Tokens: A Breakthrough in Open Network Design

![rw-book-cover](https://readwise-assets.s3.amazonaws.com/static/images/article3.5c705a01b476.png)

## Metadata
- Author: [[cdixon.org]]
- Full Title: Crypto Tokens: A Breakthrough in Open Network Design
- Category: #articles
- Document Tags: [[chris-dixon]] [[token]] [[tokenomics]] 
- URL: https://cdixon.org/2017/05/27/crypto-tokens-a-breakthrough-in-open-network-design

## Highlights
- Tokens are a breakthrough in open network design that enable: 1) the creation of open, decentralized networks that combine the best architectural properties of open and proprietary networks, and 2) new ways to incentivize open network participants, including users, developers, investors, and service providers.
- By enabling the development of new open networks, tokens could help reverse the centralization of the internet, thereby keeping it accessible, vibrant and fair, and resulting in greater innovation.
- Below I walk through the two main benefits of the token model, the first architectural and the second involving incentives.
- Tokens enable the management and financing of open services
- Why did open social protocols get so decisively defeated by proprietary social networks?
- tokens provide a way not only to define a protocol, but to fund the operating expenses required to host it as a service
- tokens provide a model for creating shared computing resources (including databases, compute, and file storage) while keeping the control of those resources decentralized (and without requiring an organization to maintain them)
- Token networks remove this friction by aligning network participants to work together toward a common goal— the growth of the network and the appreciation of the token.
- Today Linux is the dominant worldwide operating system, and Wikipedia is the most popular informational website in the world.
