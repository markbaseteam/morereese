# Maker's Schedule, Manager's Schedule

![rw-book-cover](https://readwise-assets.s3.amazonaws.com/static/images/article4.6bc1851654a0.png)

## Metadata
- Author: [[paulgraham.com]]
- Full Title: Maker's Schedule, Manager's Schedule
- Category: #articles
- URL: http://www.paulgraham.com/makersschedule.html

## Highlights
- For someone on the maker's schedule, having a meeting is like throwing an exception. It doesn't merely cause you to switch from one task to another; it changes the mode in which you work.
