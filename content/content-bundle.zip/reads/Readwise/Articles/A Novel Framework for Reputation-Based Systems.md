# A Novel Framework for Reputation-Based Systems

![rw-book-cover](https://readwise-assets.s3.amazonaws.com/static/images/article2.74d541386bbf.png)

## Metadata
- Author: [[future.a16z.com]]
- Full Title: A Novel Framework for Reputation-Based Systems
- Category: #articles
- Document Tags: [[dao]] 
- URL: https://future.a16z.com/reputation-based-systems/

## Highlights
- Drawing on our knowledge of economic theory and game design, we argue for a reputation system design based on a pair of tokens—one for signaling reputation and the other for offering liquidity—which could serve as tangible representations of meaningful contributions.
- Reputation tokens on digital platforms typically serve two purposes:  To identify and reward the users who have contributed value to the platform—a form of signaling, which those users can parlay into public reputation.   To provide a form of compensation that enables contributors to liquefy some of the value they have created into an exchangeable currency.
- Yet these two roles are in opposition to each other. A token needs to be exchangeable in order to be liquid. But the more liquid a token is, the less effective it can be as a pure signal of reputation.
- This presents a paradox: if a token can be transferred easily, then those without reputation can simply purchase it, which reduces the token’s ability to serve as a reputation signal.
- Thus, establishing reputational capital requires fully (or at least mostly) non-transferable tokens.
- We propose a two-token reputation system, whereby one token, which we call “points,” serves as a non-transferable reputation signal. A second token, “coin,” is a transferable asset dispensed to holders of points on a regular cycle. Effectively, points spin off dividends in coins that can be used as tradable currency. Moreover, because coins accrue to holders of points, coins also have a link to the underlying reputation.
    - Tags: [[reputation-systems]] 
