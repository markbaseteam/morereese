# The Graph – Google of Blockchains?

![rw-book-cover](https://readwise-assets.s3.amazonaws.com/static/images/article2.74d541386bbf.png)

## Metadata
- Author: [[jakub]]
- Full Title: The Graph – Google of Blockchains?
- Category: #articles
- Document Tags: [[grt]] 
- URL: https://finematics.com/the-graph-explained/

## Highlights
- These kinds of services are very often called ingestion services as they basically consume all the data and transform it into a queriable format.
- The Graph aims at becoming one of the main core infrastructure projects necessary for building fully decentralized applications. It focuses on decentralizing the query and API layer of decentralized web (Web3) by removing a tradeoff that dApp developers have to make today: whether to build an app that is performant or truly decentralized.
- Queriable data is organised in the form of subgraphs. One decentralized application can make use of one or multiple subgraphs. One subgraph can also consist of other subgraphs and provide a consolidated view of data that the application may be interested in.
