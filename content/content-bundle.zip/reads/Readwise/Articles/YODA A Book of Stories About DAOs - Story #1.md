# YODA: A Book of Stories About DAOs - Story #1

![rw-book-cover](https://readwise-assets.s3.amazonaws.com/static/images/article4.6bc1851654a0.png)

## Metadata
- Author: [[this]]
- Full Title: YODA: A Book of Stories About DAOs - Story #1
- Category: #articles
- Document Tags: [[dao]] [[daohaus]] [[gelato-finance]] [[kickback]] [[metacartel]] [[metagame]] [[mintbase]] [[moloch]] [[zapper-finance]] 
- URL: https://mirror.xyz/rikasukenik.eth/ypr4aOWQIJqyvY3vxNgWk9YMfysXOzd62bPPLexY2Mg

## Highlights
- MetaCartel is also the earliest DAO, preceded only by Moloch DAO.
- MetaCartel’s logo: ChiliMan.
- MetaCartel’s logo: ChiliMan
- Peter Pan, the founder of MetaCartel DAO
- The most effective form of motivation is intrinsic, meaning you work because you want to; because you believe in the mission, because you align with the values, and because you se the impact your work is making
- The most effective form of motivation is intrinsic, meaning you work because you want to; because you believe in the mission, because you align with the values, and because you se the impact your work is making
- communicating mission and values is super important for DAOs
