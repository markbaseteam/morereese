# Eight Qualities of Decentralized Autonomous Organizations

![rw-book-cover](https://readwise-assets.s3.amazonaws.com/static/images/article1.be68295a7e40.png)

## Metadata
- Author: [[ourmachine.net]]
- Full Title: Eight Qualities of Decentralized Autonomous Organizations
- Category: #articles
- Document Tags: [[dao]] [[framework]] 
- URL: https://www.ourmachine.net/writing/eight-qualities-daos/

## Highlights
- Linked to the eleventh century “deodand” legal entity, a physical object that has been granted personhood in order to be litigated against, DACs were inspired by rivers and coral reefs granted legal rights
- taxonomy of DAOs
- The autopoietic quality indicates the organization can reproduce and maintain itself without a single point of failure.
- The alegal quality indicates the organization does not transgress legality but develops a foundational framework over time.
- The hyperscalable quality indicates the organization can reach large membership sizes and in contrast to the modern firm, become more efficient as it scales.5
- The executable quality indicates the organization can run its operations through minimal protocols such as software applications.
- The permissionless quality indicates any entity can enter and exit the organization according to public criteria.
- The aligned quality indicates the organization possesses incentives to overcome common problems of coordination.
- The co-owned quality indicates the organization encodes proportional ownership to its members.
- The mnemonic quality indicates the organization automatically can produce a public record through its operations.
