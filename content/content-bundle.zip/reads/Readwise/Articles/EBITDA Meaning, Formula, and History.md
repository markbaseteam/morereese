# EBITDA: Meaning, Formula, and History

![rw-book-cover](https://readwise-assets.s3.amazonaws.com/static/images/article2.74d541386bbf.png)

## Metadata
- Author: [[Thomas Brock]]
- Full Title: EBITDA: Meaning, Formula, and History
- Category: #articles
- Document Tags: [[ebitda]] [[investopedia]] 
- URL: https://www.investopedia.com/terms/e/ebitda.asp

## Highlights
- used as an alternative to net income in some circumstances
- Simply put, EBITDA is a measure of profitability.
- EBITDA is essentially net income (or earnings) with interest, taxes, depreciation, and amortization added back.
