# 🌱 My Blog Is a Digital Garden, Not a Blog

![rw-book-cover](https://joelhooks.com/images/logo.png)

## Metadata
- Author: [[joelhooks.com]]
- Full Title: 🌱 My Blog Is a Digital Garden, Not a Blog
- Category: #articles
- URL: https://joelhooks.com/digital-garden

## Highlights
- The phrase "digital garden" is a metaphor for thinking about writing and creating that focuses less on the resulting "showpiece" and more on the process, care, and craft it takes to get there. ([View Highlight](https://read.readwise.io/read/01gs33vbfepvzafrg26pvc6kxs))
    - Tags: [[digital-gardening]] [[definition-of]] 
- Like with real gardens, our digital gardens are a constant ebb and flow towards entropy. ([View Highlight](https://read.readwise.io/read/01gs33w9h39zdanv5pmmr9x5fg))
    - Tags: [[digital-gardening]] 
    - Note: Entropy == the degree of disorder or uncertainty in a system
