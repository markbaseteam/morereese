# Billionaire Sam Bankman-Fried Pushes Back Against Critics of Crypto Derivatives

![rw-book-cover](https://readwise-assets.s3.amazonaws.com/static/images/article3.5c705a01b476.png)

## Metadata
- Author: [[forbes.com]]
- Full Title: Billionaire Sam Bankman-Fried Pushes Back Against Critics of Crypto Derivatives
- Category: #articles
- URL: https://www.forbes.com/sites/stevenehrlich/2021/08/30/billionaire-sam-bankman-fried-pushes-back-against-critics-of-crypto-derivatives/

## Highlights
- I do want to emphasize that overall, I think futures have made crypto substantially more efficient, although there are high profile times where it makes them less efficient.
- I think with Serum, what we saw was a pretty big gap in, you know, in the crypto ecosystem for you know, for a DEX that was going to be scalable, and that we can have an order book instead of AMM
- crypto exchanges are full stack businesses
