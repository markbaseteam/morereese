# Why It’s Too Early to Get Excited About Web3

![rw-book-cover](https://readwise-assets.s3.amazonaws.com/static/images/article0.00998d930354.png)

## Metadata
- Author: [[Tim O]]
- Full Title: Why It’s Too Early to Get Excited About Web3
- Category: #articles
- Document Tags: [[constitution-dao]] [[oreilly]] [[web2]] [[web3]] 
- URL: https://www.oreilly.com/radar/why-its-too-early-to-get-excited-about-web3/

## Highlights
- Blockchain developers believe that this time they’ve found a structural answer to recentralization, but I tend to doubt it. An interesting question to ask is what the next locus for centralization and control might be
- Repeat after me: neither venture capital investment nor easy access to risky, highly inflated assets predicts lasting success and impact for a particular company or technology
- If Web3 is to become a general purpose financial system, or a general system for decentralized trust, it needs to develop robust interfaces with the real world, its legal systems, and the operating economy
- every past major industrial transformation—the first Industrial Revolution; the age of steam power; the age of steel, electricity, and heavy machinery; the age of automobiles, oil, and mass production; and the internet—was accompanied by a financial bubble
- Perez identifies four stages in each of these 50–60-year innovation cycles. In the first stage, there’s foundational investment in new technology. This gives way to speculative frenzy in which financial capital seeks continued outsized returns in a rapidly evolving market that is beginning to consolidate. After the speculative bubble pops, there’s a period of more-sustained consolidation and market correction (including regulation of excess market power), followed by a mature “golden age” of integration of the new technology into society. Eventually, the technology is sufficiently mature that capital moves elsewhere, funding the next nascent technology revolution, and the cycle repeats
- An important conclusion of Perez’s analysis is that a true technology revolution must be accompanied by the development of substantial new infrastructure
- When you see companies go back again and again to investors for funding without ever reaching a profit, they may not really be businesses; they may better be thought of as financial instruments
- Let’s focus on the parts of the Web3 vision that aren’t about easy riches, on solving hard problems in trust, identity, and decentralized finance. And above all, let’s focus on the interface between crypto and the real world that people live in
