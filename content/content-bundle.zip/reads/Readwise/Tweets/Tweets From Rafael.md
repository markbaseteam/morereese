# Tweets From Rafael

![rw-book-cover](https://pbs.twimg.com/profile_images/1560542048528334851/uM4zTO77.jpg)

## Metadata
- Author: [[@rafathebuilder on Twitter]]
- Full Title: Tweets From Rafael
- Category: #tweets
- URL: https://twitter.com/rafathebuilder

## Highlights
- One of the most satisfying realisations I’ve had in the past year was understanding, finally, how to get a diverse and rich stream of quality content exploring the topics I’m interested in. ([View Tweet](https://twitter.com/rafathebuilder/status/1533747015544356865))
