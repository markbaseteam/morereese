# Tweets From Microsolidarity

![rw-book-cover](https://pbs.twimg.com/profile_images/1491105099208433671/a_BHS4pt.png)

## Metadata
- Author: [[@micro_solid on Twitter]]
- Full Title: Tweets From Microsolidarity
- Category: #tweets
- URL: https://twitter.com/micro_solid

## Highlights
- to practice microsolidarity the only piece of theory you really need to grasp is that different-sized groups are good for different things!
  microsolidarity is a community-building practice addressing 5 different scales 
  (thread...) https://t.co/yiXNtDg4fk
  ![](https://pbs.twimg.com/media/FLToG11XoA0pw4m.png) ([View Tweet](https://twitter.com/micro_solid/status/1492072614508077057))
