# Tweets From James | whiteflamingo.eth

![rw-book-cover](https://pbs.twimg.com/profile_images/1606813185289379841/BWckiFQt.jpg)

## Metadata
- Author: [[@WhiteFlamingo88 on Twitter]]
- Full Title: Tweets From James | whiteflamingo.eth
- Category: #tweets
- URL: https://twitter.com/WhiteFlamingo88

## Highlights
- A dazzle of DAOs (suggested collective noun…) I'm part of asking about grants.
  Heard at #ETHDenver repeatedly: how to start/grow DAOs w/o VC 💵
  Spun up & sharing a list of 51 grants for those who recognise there are no problems, only opportunities to be creative. 
  LFG.
  🧵 ([View Tweet](https://twitter.com/WhiteFlamingo88/status/1497902647562625026))
