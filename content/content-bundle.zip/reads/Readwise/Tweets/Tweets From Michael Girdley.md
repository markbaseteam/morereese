# Tweets From Michael Girdley

![rw-book-cover](https://pbs.twimg.com/profile_images/1603790100298694658/kAgG_3sK.jpg)

## Metadata
- Author: [[@girdley on Twitter]]
- Full Title: Tweets From Michael Girdley
- Category: #tweets
- URL: https://twitter.com/girdley

## Highlights
- Have you heard about the Dunning-Kruger effect?
  I've studied it deeply for 45 mins and am now an expert in how it works.
  A thread on everything to know... 
  (1/128) ([View Tweet](https://twitter.com/girdley/status/1494637353318682647))
