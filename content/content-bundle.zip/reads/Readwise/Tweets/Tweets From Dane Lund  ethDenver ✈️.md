# Tweets From Dane Lund | ethDenver ✈️

![rw-book-cover](https://pbs.twimg.com/profile_images/1472953747659649026/V2JDQOs1.jpg)

## Metadata
- Author: [[@lund_dane on Twitter]]
- Full Title: Tweets From Dane Lund | ethDenver ✈️
- Category: #tweets
- URL: https://twitter.com/lund_dane

## Highlights
- I have never been more optimistic about the future of DAOs. 
  The Stanford DAO Workshop brought together a group of the brightest minds working on DAOs to found the field of DAO Science. ([View Tweet](https://twitter.com/lund_dane/status/1565823225912651776))
