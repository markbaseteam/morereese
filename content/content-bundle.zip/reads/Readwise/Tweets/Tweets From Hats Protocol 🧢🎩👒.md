# Tweets From Hats Protocol 🧢🎩👒

![rw-book-cover](https://pbs.twimg.com/profile_images/1582813434701565952/Hr5lTs8P.jpg)

## Metadata
- Author: [[@hatsprotocol on Twitter]]
- Full Title: Tweets From Hats Protocol 🧢🎩👒
- Category: #tweets
- URL: https://twitter.com/hatsprotocol

## Highlights
- “Hats Protocol is going to be one of the key components of NFT governance … and involves the attribution of roles within DAOs via NFT ‘hats’. It is very early in the conceptualization phase of its development, but the ideas and design are truly innovative.”
  💖 https://t.co/1H4eVLRTkE ([View Tweet](https://twitter.com/hatsprotocol/status/1528156956858384386))
