# Tweets From DAO Research Collective

![rw-book-cover](https://pbs.twimg.com/profile_images/1519720826635005952/lBqR0CQg.jpg)

## Metadata
- Author: [[@DAOResearchCo on Twitter]]
- Full Title: Tweets From DAO Research Collective
- Category: #tweets
- URL: https://twitter.com/DAOResearchCo

## Highlights
- In his overview of DAO Legal Entity structures, @DAOResearchCo Head of Research @David_M_Kerr offers a broad refresher on legal wrapper options currently available to DAOs in the U.S.🧵 https://t.co/3XC9WcOari
  ![](https://pbs.twimg.com/media/FaTChlJX0AAxsAN.png) ([View Tweet](https://twitter.com/DAOResearchCo/status/1559586214646349824))
