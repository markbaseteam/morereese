# Tweets from justin vogel 🦁

![rw-book-cover](https://pbs.twimg.com/profile_images/1566564020378689537/uWZpMPlx.jpg)

## Metadata
- Author: [[@jkey_eth on Twitter]]
- Full Title: Tweets from justin vogel 🦁
- Category: #tweets
- URL: https://twitter.com/jkey_eth

## Highlights
- 1/12 Why do DAOs struggle to onboard contributors? 
  Not everyone in your Discord is in your DAO, nor should they be.
  Some want to participate casually, others want to be full-time.
  A summary of Rethinking the DAO contributor Funnel by @singularityhack for @ScribeDAO @SafaryDAO ([View Tweet](https://twitter.com/jkey_eth/status/1494390904005660675))
- 1/12 Everyone starts from square one in web3.
  No one knows what they're doing in their first few months.
  Creators need a reliable web3 guide to jump in.
  Because what they say impacts what people consume.
  Summarizing Web3 Creator Onboarding by @Cooopahtroopa for @ScribeDAO👇 ([View Tweet](https://twitter.com/jkey_eth/status/1491182891493036036))
- 1/10 #DAOs = "X with friends"
  What's your X?
  Building? Investing? Learning? Growing? Impacting the world?
  A thread on finding your friends in #web3👇 ([View Tweet](https://twitter.com/jkey_eth/status/1490717844601913345))
