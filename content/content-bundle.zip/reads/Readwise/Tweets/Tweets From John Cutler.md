# Tweets From John Cutler

![rw-book-cover](https://pbs.twimg.com/profile_images/870169811812106241/z9fdNNjW.jpg)

## Metadata
- Author: [[@johncutlefish on Twitter]]
- Full Title: Tweets From John Cutler
- Category: #tweets
- URL: https://twitter.com/johncutlefish

## Highlights
- 20 Things I've Learned as a Systems (Over) Thinker
  ...an illustrated book for adult over-thinkers
  1/20: Take care of yourself. Your brain is working overtime—all the time. Practice “radical” recovery.
  full post: https://t.co/UCmJ0YosaN ty: @viktorcessan https://t.co/EbjxXKdyhP
  ![](https://pbs.twimg.com/media/Fb5uFrMVEAEUNXd.jpg) ([View Tweet](https://twitter.com/johncutlefish/status/1566815945091231744))
- Touch on this a bit here https://t.co/jUppoDFvNY ([View Tweet](https://twitter.com/johncutlefish/status/1520867559712559105))
