# Tweets From AF

![rw-book-cover](https://pbs.twimg.com/profile_images/1538591056366903298/LFUpmV3l.jpg)

## Metadata
- Author: [[@tismejanie on Twitter]]
- Full Title: Tweets From AF
- Category: #tweets
- URL: https://twitter.com/tismejanie

## Highlights
- anyone doing any web3 salary transparency work these days? ([View Tweet](https://twitter.com/tismejanie/status/1516771102940409856))
