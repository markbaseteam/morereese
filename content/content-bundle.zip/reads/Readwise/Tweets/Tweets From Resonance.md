# Tweets From Resonance

![rw-book-cover](https://pbs.twimg.com/profile_images/1386036466803888128/1FuFnup5.jpg)

## Metadata
- Author: [[@resonancethis on Twitter]]
- Full Title: Tweets From Resonance
- Category: #tweets
- URL: https://twitter.com/resonancethis

## Highlights
- wHaT bEaR mArkEt
  This thread is an assortment of mental models and frameworks I've developed and relied on throughout the span of my trading career, with some personal anecdotes mixed in. 
  I will continue to update this thread as I identify new trading maxims w/ time. https://t.co/sACiG1o9JZ
  ![](https://pbs.twimg.com/media/FKqWdQqUYA4a4lw.jpg) ([View Tweet](https://twitter.com/resonancethis/status/1489168060275564547))
