# Tweets From Tim Roughgarden

![rw-book-cover](https://pbs.twimg.com/profile_images/1244967119726526464/WOHKpM1p.jpg)

## Metadata
- Author: [[@Tim_Roughgarden on Twitter]]
- Full Title: Tweets From Tim Roughgarden
- Category: #tweets
- URL: https://twitter.com/Tim_Roughgarden

## Highlights
- Lecture 1 of my Foundations of Blockchains lecture series is now available: https://t.co/iNXFLW1aaf (Will try to post one new lecture a week for the next 2-3 months.) 
  tl;dr thread below:
  1/12 ([View Tweet](https://twitter.com/Tim_Roughgarden/status/1487075256900673538))
