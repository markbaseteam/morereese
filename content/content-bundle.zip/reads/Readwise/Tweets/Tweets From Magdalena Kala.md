# Tweets From Magdalena Kala

![rw-book-cover](https://pbs.twimg.com/profile_images/1502693195234304002/vE350uvP.jpg)

## Metadata
- Author: [[@magdalenakala on Twitter]]
- Full Title: Tweets From Magdalena Kala
- Category: #tweets
- URL: https://twitter.com/magdalenakala

## Highlights
- Mags’ DAO Curriculum: 80/20 of what u need to know in <2hrs:
  •Intro to DAOs @ljxie https://t.co/HFZkvmhCZZ
  •DAOs in practice @patrickxrivera https://t.co/4mldv5p31S
  •Strategic lens on DAOs @packyM https://t.co/0IMj7tAFR8 
  •DAO landscape @Cooopahtroopa https://t.co/xlfMdQxQGj ([View Tweet](https://twitter.com/magdalenakala/status/1439268884520054798))
