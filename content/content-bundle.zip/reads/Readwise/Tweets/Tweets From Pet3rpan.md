# Tweets From Pet3rpan

![rw-book-cover](https://pbs.twimg.com/profile_images/1494073681483825152/gbNUiUsI.jpg)

## Metadata
- Author: [[@pet3rpan_ on Twitter]]
- Full Title: Tweets From Pet3rpan
- Category: #tweets
- URL: https://twitter.com/pet3rpan_

## Highlights
- DAO History/timeline:
  - The DAO / DAO Hack, MakerDAO
  - Aragon/Daostack's work
  - Moloch DAO's summoning
  - MetaCartel, DAOhaus, Raidguild, MetaFactory, Orochi
  - MetaCartel Ventures DAO, The LAO
  - Compound Finance
  - Karma DAO, Collab land
  - Snapshot, Flamingo DAO https://t.co/r7v33cXsCo
  ![](https://pbs.twimg.com/media/E2u07cGVkAMjIp1.png) ([View Tweet](https://twitter.com/pet3rpan_/status/1399411511869665285))
