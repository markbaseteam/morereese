# Tweets From Sahil Bloom

![rw-book-cover](https://pbs.twimg.com/profile_images/1586859332104343552/V1HRpbP1.jpg)

## Metadata
- Author: [[@SahilBloom on Twitter]]
- Full Title: Tweets From Sahil Bloom
- Category: #tweets
- URL: https://twitter.com/SahilBloom

## Highlights
- “Razors” are rules of thumb that simplify decisions.
  The most valuable razors I’ve discovered: ([View Tweet](https://twitter.com/SahilBloom/status/1487436653790695428))
