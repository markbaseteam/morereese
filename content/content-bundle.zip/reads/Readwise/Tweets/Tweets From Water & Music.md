# Tweets From Water & Music

![rw-book-cover](https://pbs.twimg.com/profile_images/1544273980105924608/tcOvEdob.jpg)

## Metadata
- Author: [[@water_and_music on Twitter]]
- Full Title: Tweets From Water & Music
- Category: #tweets
- URL: https://twitter.com/water_and_music

## Highlights
- ICYMI — two weeks ago, we rolled out our second research mini-series on the state of music and Web3, breaking new ground on legal issues around music NFTs, platform onboarding tactics, music DAO strategies, Web3 sentiment in the music biz and much more.
  a recap 🧵 of 🧵s: ([View Tweet](https://twitter.com/water_and_music/status/1506068862181203977))
