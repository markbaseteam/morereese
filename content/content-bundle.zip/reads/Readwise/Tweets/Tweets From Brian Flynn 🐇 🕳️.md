# Tweets From Brian Flynn 🐇 🕳️

![rw-book-cover](https://pbs.twimg.com/profile_images/1599076785194516491/jzjsD8nJ.jpg)

## Metadata
- Author: [[@Flynnjamm on Twitter]]
- Full Title: Tweets From Brian Flynn 🐇 🕳️
- Category: #tweets
- URL: https://twitter.com/Flynnjamm

## Highlights
- Instead of going to university, join a role-specific DAO:
  Liberal Arts -> @CryptoSocietyS1 
  Developers -> @developer_dao 
  Designers -> @VectorDAO 
  Analytics -> @MetricsDAO 
  Curators -> @scribeDAO 
  DAOs are the new trade schools ([View Tweet](https://twitter.com/Flynnjamm/status/1463232281997422600))
