# Tweets From Coopahtroopa 🔥_🔥

![rw-book-cover](https://pbs.twimg.com/profile_images/1567991595630489600/3zRSMk5h.jpg)

## Metadata
- Author: [[@Cooopahtroopa on Twitter]]
- Full Title: Tweets From Coopahtroopa 🔥_🔥
- Category: #tweets
- URL: https://twitter.com/Cooopahtroopa

## Highlights
- Best Starter DAOs:
  @FWBtweets - Culture
  @forefront__ - DAOs
  @seedclubhq - Community
  @developer_dao - Devs
  @banklessDAO - DeFi
  @songcamp_ - Music
  @KrauseHouseDAO - Sports
  @brtmoments - IRL NFT
  @protein - Brands
  @pub_DAO - Media
  @water_and_music - Research ([View Tweet](https://twitter.com/Cooopahtroopa/status/1463658707984674816))
- Music has a new canvas.
  We’re witnessing an audio movement driven by scarcity, fandom and access.
  This is the Music NFT Landscape. https://t.co/4y71pKBHFk
  ![](https://pbs.twimg.com/media/FJkt1-LVgAAiRnn.jpg) ([View Tweet](https://twitter.com/Cooopahtroopa/status/1484273269729423360))
