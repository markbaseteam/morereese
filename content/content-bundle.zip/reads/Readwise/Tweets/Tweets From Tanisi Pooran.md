# Tweets From Tanisi Pooran

![rw-book-cover](https://pbs.twimg.com/profile_images/1480983742122442759/jSIZjjc1.jpg)

## Metadata
- Author: [[@tanisi_pooran on Twitter]]
- Full Title: Tweets From Tanisi Pooran
- Category: #tweets
- URL: https://twitter.com/tanisi_pooran

## Highlights
- 🧵 - Some thoughts on pay/comp. Compensation - how we pay & provide is a part of the OS Canvas many teams shy away from due to baggage around money, pay & work. Explicit, transparent conversations on Compensation are key to creating the future of work we are striving for. https://t.co/U7JZtYFyHu
  ![](https://pbs.twimg.com/media/FM88v9sXMA8yPM2.jpg) ([View Tweet](https://twitter.com/tanisi_pooran/status/1499489829955977221))
