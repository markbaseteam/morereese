# Tweets From Coinbase

![rw-book-cover](https://pbs.twimg.com/profile_images/1484586799921909764/A9yYenz3.png)

## Metadata
- Author: [[@coinbase on Twitter]]
- Full Title: Tweets From Coinbase
- Category: #tweets
- URL: https://twitter.com/coinbase

## Highlights
- The power of ✨DAOs✨
  Decentralized autonomous organizations have the ability to transform how we organize any manner of economic activity.
  Learn all about the DAO landscape and the hurdles DAOs must overcome in the latest Around The Block!👇
  https://t.co/SCxQ3lbDRs https://t.co/7dO5Y082bC
  ![](https://pbs.twimg.com/media/FHOFBP8VUAIEpK8.jpg) ([View Tweet](https://twitter.com/coinbase/status/1473668601039048704))
