# Tweets from cdixon.eth

![rw-book-cover](https://pbs.twimg.com/profile_images/1433529810681155587/ACs86CsF.png)

## Metadata
- Author: [[@cdixon on Twitter]]
- Full Title: Tweets from cdixon.eth
- Category: #tweets
- URL: https://twitter.com/cdixon

## Highlights
- Some reasons to build your startup in web3 🧵 ([View Tweet](https://twitter.com/cdixon/status/1500505627604443140))
- A key point missed by many web3 critics: 
  Token incentives are temporary, used to overcome the hardest part of creating new networks: getting through the “bootstrap” phase. https://t.co/K9mgqBmk7k
  ![](https://pbs.twimg.com/media/FL-LIwMWUAcnjEf.jpg) ([View Tweet](https://twitter.com/cdixon/status/1495066587187093509))
