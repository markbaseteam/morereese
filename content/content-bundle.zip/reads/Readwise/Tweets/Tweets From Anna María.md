# Tweets From Anna María

![rw-book-cover](https://pbs.twimg.com/profile_images/1558736886700687360/lCNBEJZU.jpg)

## Metadata
- Author: [[@onlyannamaria on Twitter]]
- Full Title: Tweets From Anna María
- Category: #tweets
- URL: https://twitter.com/onlyannamaria

## Highlights
- why aren’t any art nerds writing their thesis on the neo-surrealist movement currently developing on tiktok https://t.co/RIwaukltB6 ([View Tweet](https://twitter.com/onlyannamaria/status/1577783661809831936))
