# Tweets From This Week in DAOs 🌈

![rw-book-cover](https://pbs.twimg.com/profile_images/1477867240963731456/whKoQLem.jpg)

## Metadata
- Author: [[@TWiDAOs on Twitter]]
- Full Title: Tweets From This Week in DAOs 🌈
- Category: #tweets
- URL: https://twitter.com/TWiDAOs

## Highlights
- 📆 This Week in DAOs #012 📆
  👉 First DAO to form a partnership with MLB
  👉 DAO Governance Primer
  👉 How DAOs can diversify their treasury
  👉 SeedClub's latest cohort 
  👉 DAO tool matrix
  👉 Strategic DAO Frameworks
  👉 the ✨DAO mini-series✨
  🧵↓ ([View Tweet](https://twitter.com/TWiDAOs/status/1493314120870813698))
