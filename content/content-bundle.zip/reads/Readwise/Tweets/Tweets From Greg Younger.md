# Tweets From Greg Younger

![rw-book-cover](https://pbs.twimg.com/profile_images/1484567893656416262/aXljuvof.jpg)

## Metadata
- Author: [[@gregyounger on Twitter]]
- Full Title: Tweets From Greg Younger
- Category: #tweets
- URL: https://twitter.com/gregyounger

## Highlights
- Web3 publishers come in all sorts of shapes and sizes.
  It's hard to keep them all straight.
  Here's a not-so-definitive list of all the web3 publishers I know.
  If I missed one let me know.
  👇👇
  Curated Novels
  @bookcoinHQ 
  @book_io 
  Newsletters
  @paragraph_xyz ([View Tweet](https://twitter.com/gregyounger/status/1574775678033092609))
