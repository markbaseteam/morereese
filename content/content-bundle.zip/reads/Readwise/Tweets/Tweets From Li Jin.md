# Tweets From Li Jin

![rw-book-cover](https://pbs.twimg.com/profile_images/1547998399147827202/D_2uvDGj.jpg)

## Metadata
- Author: [[@ljin18 on Twitter]]
- Full Title: Tweets From Li Jin
- Category: #tweets
- URL: https://twitter.com/ljin18

## Highlights
- Hypothesis: Progressive decentralization is an effective playbook for media creation (not just crypto applications).
  In other words, building a creative community should start with great content made by a small team, before layering in community ownership. ([View Tweet](https://twitter.com/ljin18/status/1612523313347149824))
- In Silicon Valley, ownership has long been embraced by startups to align incentives with employees.
  But the vast majority of internet users own exactly 0% of the products they contribute to.
  That's now changing via the ownership economy.
  https://t.co/pjdBsDa34N ([View Tweet](https://twitter.com/ljin18/status/1519691235555958787))
