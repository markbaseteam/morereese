# Tweets From Superdao 🦸

![rw-book-cover](https://pbs.twimg.com/profile_images/1529430343756959745/FQ3PH4Be.jpg)

## Metadata
- Author: [[@superdao_co on Twitter]]
- Full Title: Tweets From Superdao 🦸
- Category: #tweets
- URL: https://twitter.com/superdao_co

## Highlights
- In 2020, DAOs were decentralized and autonomous
  In 2022, most DAOs are centralized and run by humans
  What happened and why it's likely a good thing 🧵👇 ([View Tweet](https://twitter.com/superdao_co/status/1491091137742123008))
