# Tweets From Worms

![rw-book-cover](https://pbs.twimg.com/profile_images/1610687251859574784/B7Cgjd7N.jpg)

## Metadata
- Author: [[@MarcoWorms on Twitter]]
- Full Title: Tweets From Worms
- Category: #tweets
- URL: https://twitter.com/MarcoWorms

## Highlights
- #JoinDAOs
  It's been 1 month since I joined @iearnfinance and in this time I've got some people asking me:
  What is it like joining a DAO?
  What is it like working at Yearn?
  I feel like I can write some initial thoughts on this!
  What are DAOs: my experience in $YFI DAO
  🧵👇 ([View Tweet](https://twitter.com/MarcoWorms/status/1490923070705442819))
