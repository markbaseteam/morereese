# Tweets From dashuo.eth 🦇🔊⭕️

![rw-book-cover](https://pbs.twimg.com/profile_images/1620318477717499905/16H9bKmg.jpg)

## Metadata
- Author: [[@ruyan768 on Twitter]]
- Full Title: Tweets From dashuo.eth 🦇🔊⭕️
- Category: #tweets
- URL: https://twitter.com/ruyan768

## Highlights
- Web3 Investing Principles: Finding Primitives
  [@LensProtocol]
  profile, follow, post, comment, reference(), collect
  [@viamirror]
  post, crowdfund, split, auction, vote
  [@UnlockProtocol]
  unlock, membership 
  [@rss3_ ]
  subscription, push
  [@thepxlportraits]
  queue, task/commission ([View Tweet](https://twitter.com/ruyan768/status/1497450106517598209))
