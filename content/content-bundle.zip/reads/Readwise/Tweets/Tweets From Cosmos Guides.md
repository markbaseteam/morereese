# Tweets From Cosmos Guides

![rw-book-cover](https://pbs.twimg.com/profile_images/1562031604620578818/35SAKWiR.jpg)

## Metadata
- Author: [[@CosmosGuides on Twitter]]
- Full Title: Tweets From Cosmos Guides
- Category: #tweets
- URL: https://twitter.com/CosmosGuides

## Highlights
- 1/ In Cosmos, we like governance. But while casting votes is fun, working for a DAO is better.
  Here’s how to get funded and become a cosmic DAOist 🧵⬇️ ([View Tweet](https://twitter.com/CosmosGuides/status/1566841415816007680))
