# Tweets From Ξwoki GITer of COINs🤖

![rw-book-cover](https://pbs.twimg.com/profile_images/1622592310855757825/RM1jkm1w.jpg)

## Metadata
- Author: [[@owocki on Twitter]]
- Full Title: Tweets From Ξwoki GITer of COINs🤖
- Category: #tweets
- URL: https://twitter.com/owocki

## Highlights
- https://t.co/2cJYESOeMv
  ![](https://pbs.twimg.com/media/FjTnMKMVQAMkGFx.jpg) ([View Tweet](https://twitter.com/owocki/status/1600158366185111552))
