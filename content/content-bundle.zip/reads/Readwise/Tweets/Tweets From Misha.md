# Tweets From Misha

![rw-book-cover](https://pbs.twimg.com/profile_images/1511045842643288071/chojDCx8.jpg)

## Metadata
- Author: [[@mishadavinci on Twitter]]
- Full Title: Tweets From Misha
- Category: #tweets
- URL: https://twitter.com/mishadavinci

## Highlights
- Web3 and NFT Twitter can be confusing.
  Let's change that.
  40 terms that will make you SMARTER—starting today: ([View Tweet](https://twitter.com/mishadavinci/status/1492494910984900611))
