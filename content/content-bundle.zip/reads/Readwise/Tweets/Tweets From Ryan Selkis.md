# Tweets From Ryan Selkis

![rw-book-cover](https://pbs.twimg.com/profile_images/1574392800963174402/mea0sjf2.jpg)

## Metadata
- Author: [[@twobitidiot on Twitter]]
- Full Title: Tweets From Ryan Selkis
- Category: #tweets
- URL: https://twitter.com/twobitidiot

## Highlights
- 1/ For the founders working until the closing bell today, especially the earliest stage founders who are pre-PMF and staring down the barrel of a shorter than expected runway + crypto winter, I've got a story for you.
  👇 ([View Tweet](https://twitter.com/twobitidiot/status/1606376511115870208))
