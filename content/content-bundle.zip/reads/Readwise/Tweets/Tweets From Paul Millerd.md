# Tweets From Paul Millerd

![rw-book-cover](https://pbs.twimg.com/profile_images/1483260165004615681/6X3fq9jD.jpg)

## Metadata
- Author: [[@p_millerd on Twitter]]
- Full Title: Tweets From Paul Millerd
- Category: #tweets
- URL: https://twitter.com/p_millerd

## Highlights
- Been diving into the historical figures on @FoundersPodcast and it's striking how almost all of them have similar thoughtful reflections on work, and finding things that matter to them (including David)
  These seem to be hidden in plain sight secrets. Some that stood out👇 ([View Tweet](https://twitter.com/p_millerd/status/1593276319659266048))
