# Tweets From Bobby

![rw-book-cover](https://pbs.twimg.com/profile_images/1483047633371422723/QEVdSQ1R.jpg)

## Metadata
- Author: [[@bobbybanzai on Twitter]]
- Full Title: Tweets From Bobby
- Category: #tweets
- URL: https://twitter.com/bobbybanzai

## Highlights
- Crypto resources mega thread 📰
  I’ve listed resources that will help you keep up in this space from daily news to podcasts and from analytical tools to substacks.
  If you have any quality sources that I’ve missed, let me know and I’ll add them.
  🧵👇 ([View Tweet](https://twitter.com/bobbybanzai/status/1493939959128113157))
