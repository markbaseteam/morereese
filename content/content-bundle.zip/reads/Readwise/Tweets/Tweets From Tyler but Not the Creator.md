# Tweets From Tyler but Not the Creator

![rw-book-cover](https://pbs.twimg.com/profile_images/1605004669041840131/Rqj87Hqc.jpg)

## Metadata
- Author: [[@tylerangert on Twitter]]
- Full Title: Tweets From Tyler but Not the Creator
- Category: #tweets
- URL: https://twitter.com/tylerangert

## Highlights
- The next big UI framework will not be for humans to use. UIs will be constructed ad hoc for whatever task you need, then thrown away when you don’t need it. The promise of no-code productivity tools (stacking basic UI legos for whatever task) will be mostly automated ([View Tweet](https://twitter.com/tylerangert/status/1624078177034280966))
