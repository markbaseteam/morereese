# Tweets From Balaji S. Srinivasan

![rw-book-cover](https://pbs.twimg.com/profile_images/1406974882919813128/LOUb2m4R.jpg)

## Metadata
- Author: [[@balajis on Twitter]]
- Full Title: Tweets From Balaji S. Srinivasan
- Category: #tweets
- URL: https://twitter.com/balajis

## Highlights
- Three kinds of DAOs
  Autonomous DAO — a group that interacts with a truly self-running smart contract with no admin keys and no CEO
  Bureaucratic DAO — a mess of politics
  CEO DAO — a single clear leader ([View Tweet](https://twitter.com/balajis/status/1494244523983081475))
