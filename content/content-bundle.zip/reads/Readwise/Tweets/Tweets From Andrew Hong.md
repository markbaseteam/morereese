# Tweets From Andrew Hong

![rw-book-cover](https://pbs.twimg.com/profile_images/1436370413173592079/0yuubs2F.jpg)

## Metadata
- Author: [[@andrewhong5297 on Twitter]]
- Full Title: Tweets From Andrew Hong
- Category: #tweets
- URL: https://twitter.com/andrewhong5297

## Highlights
- ✨📊My inaugural guide to web3 data is here!
  In it, I'll walk you through:
  > how and why web3 vs web2 data thinking is different
  > layers and players of the data landscape, and key communities
  > 3 types of data roles with skills mapped out
  https://t.co/gjQorE6utI ([View Tweet](https://twitter.com/andrewhong5297/status/1491061712484806659))
