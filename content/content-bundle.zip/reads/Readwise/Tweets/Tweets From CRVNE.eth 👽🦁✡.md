# Tweets From CRVNE.eth 👽🦁✡

![rw-book-cover](https://pbs.twimg.com/profile_images/1621650359419809793/4hZIBs3t.jpg)

## Metadata
- Author: [[@CRVNE_eth on Twitter]]
- Full Title: Tweets From CRVNE.eth 👽🦁✡
- Category: #tweets
- URL: https://twitter.com/CRVNE_eth

## Highlights
- A lot of people ask me "How do you build a website on #ENSDomains" like https://t.co/ZT7vwb1zlF?
  So, here it is: 5 Simple Steps to Build a Decentralized Website
  🧵👇 ([View Tweet](https://twitter.com/CRVNE_eth/status/1614347828515713024))
