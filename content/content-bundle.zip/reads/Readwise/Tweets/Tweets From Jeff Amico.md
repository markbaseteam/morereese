# Tweets From Jeff Amico

![rw-book-cover](https://pbs.twimg.com/profile_images/1261090018900115457/lwQeqUWP.jpg)

## Metadata
- Author: [[@_jamico on Twitter]]
- Full Title: Tweets From Jeff Amico
- Category: #tweets
- URL: https://twitter.com/_jamico

## Highlights
- Treasury management has emerged as one of the most pressing issues in crypto today
  To help teams navigate the downturn, we’ve created a guide on how to manage cash effectively and emerge stronger on the other side 
  From @meigga @EMinSF @elynch46 & me 
  https://t.co/nnDy1iCwV1 ([View Tweet](https://twitter.com/_jamico/status/1562850429003632641))
