# Tweets From MSP - ✍🏾 TheInternetOfValue.xyz

![rw-book-cover](https://pbs.twimg.com/profile_images/1571131112176635910/eMhynUMC.jpg)

## Metadata
- Author: [[@MosesSamPaul on Twitter]]
- Full Title: Tweets From MSP - ✍🏾 TheInternetOfValue.xyz
- Category: #tweets
- URL: https://twitter.com/MosesSamPaul

## Highlights
- A 🧵 on different theories of #value. 
  At the center of most economic paradigms is a Theory of Value.
  Theories from #AdamSmith #Ricardo #Marx #MarginalTheory #SraffianTheory #LaborTheoryofValue #EconTwitter https://t.co/65VosmRbXl
  ![](https://pbs.twimg.com/media/FK2dbenakAINhr3.jpg) ([View Tweet](https://twitter.com/MosesSamPaul/status/1490040422131179521))
