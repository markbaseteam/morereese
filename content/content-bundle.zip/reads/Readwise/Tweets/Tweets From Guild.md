# Tweets From Guild

![rw-book-cover](https://pbs.twimg.com/profile_images/1617494647307210752/ko1taYSe.jpg)

## Metadata
- Author: [[@guildxyz on Twitter]]
- Full Title: Tweets From Guild
- Category: #tweets
- URL: https://twitter.com/guildxyz

## Highlights
- @ZeughFromCanu Here is my list of new projects, shaping the future of DAOs:
  @withBackdrop for discovery
  @CyberConnectHQ for interconnection
  @lobbyso for knowledge management
  @CommDotApp for crypto-native chat
  @Sismo_eth for private attestations
  alpha: @_nindao turns TG groups into daos 
  😏 ([View Tweet](https://twitter.com/guildxyz/status/1494252418678374401))
