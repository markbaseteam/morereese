# Tweets From Avenue

![rw-book-cover](https://pbs.twimg.com/profile_images/1579884208620699648/R9tiOy6j.jpg)

## Metadata
- Author: [[@avenueplace on Twitter]]
- Full Title: Tweets From Avenue
- Category: #tweets
- URL: https://twitter.com/avenueplace

## Highlights
- Admins have too much control:
  Only admins can set up channels, and since no other collaborative spaces exist, contributors have to ask them for permission or use DMs.
  This slows the process at a vital time, when enthusiasm and creativity around a new idea is at its peak. ([View Tweet](https://twitter.com/avenueplace/status/1561727942379638791))
