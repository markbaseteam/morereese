# Tweets From Packy McCormick

![rw-book-cover](https://pbs.twimg.com/profile_images/1582829894383374341/J2J3rmXw.jpg)

## Metadata
- Author: [[@packyM on Twitter]]
- Full Title: Tweets From Packy McCormick
- Category: #tweets
- URL: https://twitter.com/packyM

## Highlights
- Last week, I asked you: "If I wanted to be top 0.1% at understanding/designing tokenomics, what's one resource you'd recommend?"
  You gave 76 great answers. Here are the most popular, plus a link to the full Tokenomics Resource List: ([View Tweet](https://twitter.com/packyM/status/1493990833397325824))
    - Tags: [[tokenomics]] [[token-design]] 
