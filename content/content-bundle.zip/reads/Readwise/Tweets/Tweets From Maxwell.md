# Tweets From Maxwell

![rw-book-cover](https://pbs.twimg.com/profile_images/1610831990021885953/eCJOsrhk.jpg)

## Metadata
- Author: [[@publicmaxwell on Twitter]]
- Full Title: Tweets From Maxwell
- Category: #tweets
- URL: https://twitter.com/publicmaxwell

## Highlights
- Recently, @ericscottsays and @Anna_Tsh and I have been mapping out the web3 education landscape as part of our @KERNEL0x KB5 adventure. We are happy to share the first version of our web3edu landscape map https://t.co/LyWwfrpgG5
  ![](https://pbs.twimg.com/media/FNk_PJXWQAIElZs.jpg) ([View Tweet](https://twitter.com/publicmaxwell/status/1502302838537527302))
