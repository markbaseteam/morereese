# Tweets From Daniel Schlabach

![rw-book-cover](https://pbs.twimg.com/profile_images/1389551178770436099/9m56TSDl.jpg)

## Metadata
- Author: [[@DMSchlabach on Twitter]]
- Full Title: Tweets From Daniel Schlabach
- Category: #tweets
- URL: https://twitter.com/DMSchlabach

## Highlights
- 1/ In 2012, Valve's Employee Handbook was leaked.
  Turns out they've been running a DAO before DAOs were even a thing... and they managed to generate more profit per employee than Google, Amazon, and Microsoft while doing so.
  https://t.co/e1Dnzs1tJT ([View Tweet](https://twitter.com/DMSchlabach/status/1519298365808205824))
