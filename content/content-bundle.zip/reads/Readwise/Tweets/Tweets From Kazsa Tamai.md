# Tweets From Kazsa Tamai

![rw-book-cover](https://pbs.twimg.com/profile_images/1557535992298369025/-xVz9wO0.jpg)

## Metadata
- Author: [[@kazsatamai on Twitter]]
- Full Title: Tweets From Kazsa Tamai
- Category: #tweets
- URL: https://twitter.com/kazsatamai

## Highlights
- web3 designers are often less talked about.
  Let's change that.
  Here are some must follow Twitter accounts to keep up with web3 designs ([View Tweet](https://twitter.com/kazsatamai/status/1519361262710308866))
