# Tweets From 6529

![rw-book-cover](https://pbs.twimg.com/profile_images/1440017111531855879/A4p6F07H.jpg)

## Metadata
- Author: [[@punk6529 on Twitter]]
- Full Title: Tweets From 6529
- Category: #tweets
- URL: https://twitter.com/punk6529

## Highlights
- 1/ There are no other constitutional rights in substance without freedom to transact
  Being meaning to write this for 6 months, but the Canadian response to the trucker protests is illustrating this so vividly, that today is the day. ([View Tweet](https://twitter.com/punk6529/status/1494444624630403083))
