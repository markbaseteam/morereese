# Tweets From JIMMY

![rw-book-cover](https://pbs.twimg.com/profile_images/1490444268837777411/75Lgokxb.jpg)

## Metadata
- Author: [[@JIMMYEDGAR on Twitter]]
- Full Title: Tweets From JIMMY
- Category: #tweets
- URL: https://twitter.com/JIMMYEDGAR

## Highlights
- zero interested in music nfts until there is a platform that has on-chain stems/samples and the function to mint new creations using those elements (on-chain royalties) ([View Tweet](https://twitter.com/JIMMYEDGAR/status/1504483070266597379))
