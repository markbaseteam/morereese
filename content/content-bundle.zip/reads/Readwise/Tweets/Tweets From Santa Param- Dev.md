# Tweets From Santa Param- Dev

![rw-book-cover](https://pbs.twimg.com/profile_images/1479160943451914242/RUPqd86x.png)

## Metadata
- Author: [[@Param_eth on Twitter]]
- Full Title: Tweets From Santa Param- Dev
- Category: #tweets
- URL: https://twitter.com/Param_eth

## Highlights
- Build your own web3 community ⚡️ 
  Create your own DAO with these Amazing 
  tools 🚀
  A Thread 🧵↓ ([View Tweet](https://twitter.com/Param_eth/status/1506253953343709190))
