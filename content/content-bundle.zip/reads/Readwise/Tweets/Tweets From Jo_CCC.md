# Tweets From Jo_CCC

![rw-book-cover](https://pbs.twimg.com/profile_images/1615796568309002240/c8PFVU8W.jpg)

## Metadata
- Author: [[@luangkittikong on Twitter]]
- Full Title: Tweets From Jo_CCC
- Category: #tweets
- URL: https://twitter.com/luangkittikong

## Highlights
- #DAOs as the future of decentralized learning.
  ๋ีJust join a role-specific DAO:
  Liberal Arts -> @CryptoSocietyS1
  Developers -> @developer_dao
  Designers -> @VectorDAO
  Analytics -> @MetricsDAO
  Curators -> @scribeDAO ([View Tweet](https://twitter.com/luangkittikong/status/1521181803868221440))
