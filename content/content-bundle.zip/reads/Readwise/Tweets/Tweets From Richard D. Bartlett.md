# Tweets From Richard D. Bartlett

![rw-book-cover](https://pbs.twimg.com/profile_images/1622605159728574465/YW9wT7oO.jpg)

## Metadata
- Author: [[@RichDecibels on Twitter]]
- Full Title: Tweets From Richard D. Bartlett
- Category: #tweets
- URL: https://twitter.com/RichDecibels

## Highlights
- I'm going to curate a thread of my favourite educators on youtube
  probably mostly various types of engineering, music, science & DIY stuff
  everyone on this list produces exceptional material ([View Tweet](https://twitter.com/RichDecibels/status/1465009271553282057))
