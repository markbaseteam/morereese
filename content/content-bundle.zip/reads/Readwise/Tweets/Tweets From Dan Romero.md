# Tweets From Dan Romero

![rw-book-cover](https://pbs.twimg.com/profile_images/1518670972559130624/-G9gNsOp.png)

## Metadata
- Author: [[@dwr on Twitter]]
- Full Title: Tweets From Dan Romero
- Category: #tweets
- URL: https://twitter.com/dwr

## Highlights
- https://t.co/GXwHKX9pVC
  https://t.co/bFUDwt2z8Y
  https://t.co/wO1gO2LYms
  https://t.co/PsEiVnKttu
  https://t.co/ER8H3IH9pg ([View Tweet](https://twitter.com/dwr/status/1612499274859745283))
