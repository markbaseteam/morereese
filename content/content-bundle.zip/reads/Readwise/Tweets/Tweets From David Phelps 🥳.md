# Tweets From David Phelps 🥳

![rw-book-cover](https://pbs.twimg.com/profile_images/1496705014177411077/TT3vu4m8.jpg)

## Metadata
- Author: [[@divine_economy on Twitter]]
- Full Title: Tweets From David Phelps 🥳
- Category: #tweets
- URL: https://twitter.com/divine_economy

## Highlights
- 12 WAYS DECENTRALIZED ENCRYPTION WILL UNLOCK WEB3 
  👇 ([View Tweet](https://twitter.com/divine_economy/status/1502366274772471814))
