# Tweets From LucaG

![rw-book-cover](https://pbs.twimg.com/profile_images/1603810450931695623/Q32RmxjL.jpg)

## Metadata
- Author: [[@luca_cloud on Twitter]]
- Full Title: Tweets From LucaG
- Category: #tweets
- URL: https://twitter.com/luca_cloud

## Highlights
- If you're a platform engineer, there are some "trending" conversations you should be aware of:
  * The cognitive (over)load resulting from true #DevOps 
  * Platform as a product
  * Finding the right level of abstraction
  Let's discuss 🧵 ([View Tweet](https://twitter.com/luca_cloud/status/1559470995471228928))
