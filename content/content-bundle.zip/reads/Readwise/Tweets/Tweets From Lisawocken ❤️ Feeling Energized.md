# Tweets From Lisawocken ❤️ Feeling Energized

![rw-book-cover](https://pbs.twimg.com/profile_images/1614496213373538304/dYTvc4CP.jpg)

## Metadata
- Author: [[@LisaWocken on Twitter]]
- Full Title: Tweets From Lisawocken ❤️ Feeling Energized
- Category: #tweets
- URL: https://twitter.com/LisaWocken

## Highlights
- Break. It. Down. It is important to situate #DAOs in a known context for anyone new to Web3. DAOs are another form of organization that is newer than the others (e.g. non-profits, corporations, small businesses) and likely still brand new to most people. ([View Tweet](https://twitter.com/LisaWocken/status/1489810527308193795))
