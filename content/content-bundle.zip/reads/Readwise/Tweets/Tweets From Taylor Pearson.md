# Tweets From Taylor Pearson

![rw-book-cover](https://pbs.twimg.com/profile_images/630002655897776128/BrmsY0Ev.jpg)

## Metadata
- Author: [[@TaylorPearsonMe on Twitter]]
- Full Title: Tweets From Taylor Pearson
- Category: #tweets
- URL: https://twitter.com/TaylorPearsonMe

## Highlights
- 1/ A thread of my most popular threads ([View Tweet](https://twitter.com/TaylorPearsonMe/status/1116126540574543872))
