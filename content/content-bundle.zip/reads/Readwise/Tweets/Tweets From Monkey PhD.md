# Tweets From Monkey PhD

![rw-book-cover](https://pbs.twimg.com/profile_images/1481302455531065362/NOVpKWOZ.jpg)

## Metadata
- Author: [[@monkey_phd on Twitter]]
- Full Title: Tweets From Monkey PhD
- Category: #tweets
- URL: https://twitter.com/monkey_phd

## Highlights
- The Web3 era is brewing, I’m analyzing 9.7k DAOs spaces, 63K proposals and 5.6M votes on a decentralized voting system @SnapshotLabs⚡️📊 See thread 🧵for 5 short descriptive takeaways on DAO governance 👨‍⚖️ https://t.co/CZQQvUpz1p
  ![](https://pbs.twimg.com/media/FbWFGo3XgAMhrvX.jpg)
  ![](https://pbs.twimg.com/media/FbWFGqUX0AAJCct.jpg) ([View Tweet](https://twitter.com/monkey_phd/status/1564303099065409536))
