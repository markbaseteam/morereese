# Tweets From JO7.eth

![rw-book-cover](https://pbs.twimg.com/profile_images/1489281767274168324/Wc_kO9HE.jpg)

## Metadata
- Author: [[@JO7eth on Twitter]]
- Full Title: Tweets From JO7.eth
- Category: #tweets
- URL: https://twitter.com/JO7eth

## Highlights
- With web3 content having reached critical mass, we have a critical need for curation. 
  A deep dive into the projects shaping the curation landscape 🧵 https://t.co/OkaqUy1mqT
  ![](https://pbs.twimg.com/media/FLAYNR5UUAAdij8.jpg) ([View Tweet](https://twitter.com/JO7eth/status/1490718101268094978))
