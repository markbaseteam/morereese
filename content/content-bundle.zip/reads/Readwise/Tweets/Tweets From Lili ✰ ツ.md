# Tweets From Lili ✰ ツ

![rw-book-cover](https://pbs.twimg.com/profile_images/1590585875318312960/wbJ3lK0B.jpg)

## Metadata
- Author: [[@lililashka on Twitter]]
- Full Title: Tweets From Lili ✰ ツ
- Category: #tweets
- URL: https://twitter.com/lililashka

## Highlights
- I have compiled the key use cases for NFT as a new asset class for Q1 2022.
  These range from arts, curation, research, food, social, games, music, defi, wearables, investments & more. Provable ownership of digital assets is the new gold.🪙
  And we are just getting started https://t.co/hcFk2OC9rw
  ![](https://pbs.twimg.com/media/FI_XAbkVcAM2JRi.png) ([View Tweet](https://twitter.com/lililashka/status/1481639448425074694))
