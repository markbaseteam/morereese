# Tweets From Safi

![rw-book-cover](https://pbs.twimg.com/profile_images/1584953702875598850/ZKj2VOmq.jpg)

## Metadata
- Author: [[@s_afiaziz on Twitter]]
- Full Title: Tweets From Safi
- Category: #tweets
- URL: https://twitter.com/s_afiaziz

## Highlights
- In this calendar year you can:
  1. Get a crypto mortgage with @MiloCredit 
  2. Buy a home via NFT with @PropyInc 
  3. Experience your neighborhood with @joinsuperlocal 
  4. Invest in your neighborhood with @parcl 
  5. Go hang at your nearest @maxwellsocial or @LinksDAO 
  IRL > URL ([View Tweet](https://twitter.com/s_afiaziz/status/1491050858200461314))
