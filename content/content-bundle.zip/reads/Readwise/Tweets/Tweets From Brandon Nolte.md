# Tweets From Brandon Nolte

![rw-book-cover](https://pbs.twimg.com/profile_images/1486077272931061769/LB0pa5d-.png)

## Metadata
- Author: [[@brandoncnolte on Twitter]]
- Full Title: Tweets From Brandon Nolte
- Category: #tweets
- URL: https://twitter.com/brandoncnolte

## Highlights
- DAO onboarding is a mess.
  But there's a few DAOs who are really excelling at it.
  Here are the 8 best threads that show how they do it👇 ([View Tweet](https://twitter.com/brandoncnolte/status/1542734752456720384))
