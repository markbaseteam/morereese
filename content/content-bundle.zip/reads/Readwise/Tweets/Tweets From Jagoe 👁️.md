# Tweets From Jagoe 👁️

![rw-book-cover](https://pbs.twimg.com/profile_images/1607763660176252928/49gz1-xr.jpg)

## Metadata
- Author: [[@JagoeCapital on Twitter]]
- Full Title: Tweets From Jagoe 👁️
- Category: #tweets
- URL: https://twitter.com/JagoeCapital

## Highlights
- @SBF_FTX @MIT @carolinecapital @Stanford Here's more information on the shady "Mind the Gap" bundler operation founded by @SBF_FTX's mother, Barbara Fried, and led by @Stanford faculty, funneling millions of dollars from Silicon Valley to the Democrat Party:
  https://t.co/NYDeaX93of https://t.co/YOhvkE3vi8
  ![](https://pbs.twimg.com/media/FhPNN6WXEAA7eBd.png)
  ![](https://pbs.twimg.com/media/FhPNN7nWAAY4qdB.png) ([View Tweet](https://twitter.com/JagoeCapital/status/1590840822916075520))
