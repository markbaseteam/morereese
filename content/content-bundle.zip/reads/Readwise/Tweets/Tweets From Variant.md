# Tweets From Variant

![rw-book-cover](https://pbs.twimg.com/profile_images/1450444257567858691/eoNhUEjk.jpg)

## Metadata
- Author: [[@variantfund on Twitter]]
- Full Title: Tweets From Variant
- Category: #tweets
- URL: https://twitter.com/variantfund

## Highlights
- In case you missed it, we spent an hour unpacking the latest trends and topics in the legal and regulatory landscape in web3 with the incredible @boironattorney, @RebeccaRettig1, and @jessewldn. 
  You can listen back here: https://t.co/Q1Y7ncnVpm ([View Tweet](https://twitter.com/variantfund/status/1562215163666714627))
