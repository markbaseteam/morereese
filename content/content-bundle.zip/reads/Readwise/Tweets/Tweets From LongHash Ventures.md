# Tweets From LongHash Ventures

![rw-book-cover](https://pbs.twimg.com/profile_images/1615699647414272000/y8_L9vdN.jpg)

## Metadata
- Author: [[@LongHashVC on Twitter]]
- Full Title: Tweets From LongHash Ventures
- Category: #tweets
- URL: https://twitter.com/LongHashVC

## Highlights
- An overview of the music NFT landscape
  Our analyst @0xEmerson mapped out some music NFT platforms by type and utility
  Check it out 👇 https://t.co/9XrxrG6AWQ
  ![](https://pbs.twimg.com/media/FRWV4dIVsAEvEu-.jpg) ([View Tweet](https://twitter.com/LongHashVC/status/1519285249221439489))
