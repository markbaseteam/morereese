# Tweets From Vitalik Non-Giver of Ether

![rw-book-cover](https://pbs.twimg.com/profile_images/977496875887558661/L86xyLF4.jpg)

## Metadata
- Author: [[@VitalikButerin on Twitter]]
- Full Title: Tweets From Vitalik Non-Giver of Ether
- Category: #tweets
- URL: https://twitter.com/VitalikButerin

## Highlights
- Explanation 5: we have social media now and social media rewards negativity.
  (If true, I think this is unhealthy and we should just fight it head-on, but less sure *how* to do that) ([View Tweet](https://twitter.com/VitalikButerin/status/1532151215923990528))
