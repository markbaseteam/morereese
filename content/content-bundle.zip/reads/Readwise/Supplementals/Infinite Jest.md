
%%
ID: 23970055
Updated: 2023-02-03
%%

![]( https://images-na.ssl-images-amazon.com/images/I/41U6MeFXOGL._SL500_.jpg)

# About
Title: [[Infinite Jest]]
Authors: [[David Foster Wallace]]
Category: #supplementals
Number of Highlights: ==10==
Readwise URL: https://readwise.io/bookreview/23970055
Date: [[2023-02-03]]
Last Highlighted: **

---

# Highlights

Like most North Americans of his generation, Hal tends to know way less about why he feels certain ways about the objects and pursuits he’s devoted to than he does about the objects and pursuits themselves. It’s hard to say for sure whether this is even exceptionally bad, this tendency. ^468575758

---

You seek to vanquish and transcend the limited self whose limits make the game possible in the first place. It is tragic and sad and chaotic and lovely. All life is the same, as citizens of the human State: the animating limits are within, to be killed and mourned, over and over again. ^468575759

---

This wise old whiskery fish swims up to three young fish and goes, ‘Morning, boys, how’s the water?’ and swims away; and the three young fish watch him swim away and look at each other and go, ‘What the fuck is water?’ and swim away. ^468575760

---

Everyone should get at least one good look at the eyes of a man who finds himself rising toward what he wants to pull down to himself. ^468575761

---

American experience seems to suggest that people are virtually unlimited in their need to give themselves away, on various levels. Some just prefer to do it in secret. ^468575762

---

Good old traditional audio-only phone conversations allowed you to presume that the person on the other end was paying complete attention to you while also permitting you not to have to pay anything even close to complete attention to her. ^468575763

---

The moment he recognized what exactly was on one cartridge he had a strong anxious feeling that there was something more entertaining on another cartridge and that he was potentially missing it. He realized that he would have plenty of time to enjoy all the cartridges, and realized intellectually that the feeling of deprived panic over missing something made no sense. ^468575764

---

That other people can often see things about you that you yourself cannot see, even if those people are stupid. ^468575765

---

That you will become way less concerned with what other people think of you when you realize how seldom they do. ^468575766

---

That, perversely, it is often more fun to want something than to have it. ^468575767

---
