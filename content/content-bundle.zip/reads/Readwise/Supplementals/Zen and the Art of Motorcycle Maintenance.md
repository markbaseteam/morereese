
%%
ID: 23970047
Updated: 2023-02-03
%%

![]( https://images-na.ssl-images-amazon.com/images/I/41F75p2GedL._SL500_.jpg)

# About
Title: [[Zen and the Art of Motorcycle Maintenance]]
Authors: [[Robert M. Pirsig]]
Category: #supplementals
Number of Highlights: ==10==
Readwise URL: https://readwise.io/bookreview/23970047
Date: [[2023-02-03]]
Last Highlighted: **

---

# Highlights

“You look at where you’re going and where you are and it never makes sense, but then you look back at where you’ve been and a pattern seems to emerge. And if you project forward from that pattern, then sometimes you can come up with something. ^468575505

---

When you want to hurry something, that means you no longer care about it and want to get on to other things. ^468575506

---

But to tear down a factory or to revolt against a government or to avoid repair of a motorcycle because it is a system is to attack effects rather than causes; and as long as the attack is upon effects only, no change is possible. ^468575507

---

I argued that physical discomfort is important only when the mood is wrong. Then you fasten on to whatever thing is uncomfortable and call that the cause. But if the mood is right, then physical discomfort doesn’t mean much. ^468575508

---

You are never dedicated to something you have complete confidence in. No one is fanatically shouting that the sun is going to rise tomorrow. They know it’s going to rise tomorrow. When people are fanatically dedicated to political or religious faiths or any other kinds of dogmas or goals, it’s always because these dogmas or goals are in doubt. ^468575509

---

The Buddha, the Godhead, resides quite as comfortably in the circuits of a digital computer or the gears of a cycle transmission as he does at the top of a mountain or in the petals of a flower. To think otherwise is to demean the Buddha—which is to demean oneself. ^468575510

---

The truth knocks on the door and you say, “Go away, I’m looking for the truth,” and so it goes away. ^468575511

---

A classical understanding sees the world primarily as underlying form itself. A romantic understanding sees it primarily in terms of immediate appearance. ^468575512

---

Any effort that has self-glorification as its final endpoint is bound to end in disaster. ^468575513

---

You always suppress momentary anger at something you deeply and permanently hate. ^468575514

---
