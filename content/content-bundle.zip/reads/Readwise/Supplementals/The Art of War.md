
%%
ID: 24004808
Updated: 2023-02-04
%%

![]( https://images-na.ssl-images-amazon.com/images/I/41ED%2Bav59nL._SL500_.jpg)

# About
Title: [[The Art of War]]
Authors: [[Sun Tzu]]
Category: #supplementals
Number of Highlights: ==10==
Readwise URL: https://readwise.io/bookreview/24004808
Date: [[2023-02-04]]
Last Highlighted: **

---

# Highlights

Hence, when able to attack, we must seem unable; when using our forces, we must seem inactive; when we are near, we must make the enemy believe we are far away; when far away, we must make him believe we are near. ^469322154

---

Hence the saying: If you know the enemy and know yourself, you need not fear the result of a hundred battles. If you know yourself but not the enemy, for every victory gained you will also suffer a defeat. ^469322155

---

The MORAL LAW causes the people to be in complete accord with their ruler, so that they will follow him regardless of their lives, undismayed by any danger. ^469322156

---

To secure ourselves against defeat lies in our own hands, but the opportunity of defeating the enemy is provided by the enemy himself. ^469322157

---

If your opponent is of choleric temper, seek to irritate him. Pretend to be weak, that he may grow arrogant. ^469322158

---

Hence to fight and conquer in all your battles is not supreme excellence; supreme excellence consists in breaking the enemy’s resistance without fighting. ^469322159

---

“If words of command are not clear and distinct, if orders are not thoroughly understood, then the general is to blame.” ^469322160

---

He who relies solely on warlike measures shall be exterminated; he who relies solely on peaceful measures shall perish. ^469322161

---

If you know neither the enemy nor yourself, you will succumb in every battle. ^469322162

---

There is no instance of a country having benefited from prolonged warfare. ^469322163

---
