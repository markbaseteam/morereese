
%%
ID: 23970052
Updated: 2023-02-03
%%

![]( https://images-na.ssl-images-amazon.com/images/I/51PRkV8AbDL._SL500_.jpg)

# About
Title: [[public/reads/Readwise/Supplementals/Finite and Infinite Games]]
Authors: [[James Carse]]
Category: #supplementals
Number of Highlights: ==10==
Readwise URL: https://readwise.io/bookreview/23970052
Date: [[2023-02-03]]
Last Highlighted: **

---

# Highlights

It is an invariable principle of all play, finite and infinite, that whoever plays, plays freely. Whoever must play, cannot play. ^468575692

---

Finite players play within boundaries; infinite players play with boundaries. ^468575693

---

To be serious is to press for a specified conclusion. To be playful is to allow for possibility whatever the cost to oneself. ^468575694

---

To be prepared against surprise is to be trained. To be prepared for surprise is to be educated. ^468575695

---

Infinite players cannot say when their game began, nor do they care. They do not care for the reason that their game is not bounded by time. Indeed, the only purpose of the game is to prevent it from coming to an end, to keep everyone in play. ^468575696

---

The joyfulness of infinite play, its laughter, lies in learning to start something we cannot finish. ^468575697

---

Strength is paradoxical. I am not strong because I can force others to do what I wish as a result of my play with them, but because I can allow them to do what they wish in the course of my play with them. ^468575698

---

The issue is whether we are ever willing to drop the veil and openly acknowledge, if only to ourselves, that we have freely chosen to face the world through a mask. ^468575699

---

Only that which can change can continue: this is the principle by which infinite players live. ^468575700

---

It is apparent to infinite players that wealth is not so much possessed as it is performed. ^468575701

---
